"""Independent 2025 direct-source checks using CSV/integer arithmetic only.

This deliberately does not import the analytical processing modules or their
provider-selection helpers. It checks consequential new displayed quantities.
"""
from collections import defaultdict
import csv
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
DATA = Path(os.environ.get("ASESORIAS_DATA_ROOT", "/Volumes/Datos/Asesorias_Data"))
OUT = ROOT / "outputs/rem_neuro_instruments_2026-10-30/report_revision"
FUNCTION = ["P5180100", "P5180200", "P5300510", "P5300100", "P5300200", "P5300520", "P5300530"]


def source_rows(series, codes):
    source = DATA / f"REM/Serie{series}/Serie{series}_2025.csv"
    with source.open(encoding="latin1") as stream:
        header = next(csv.reader(stream, delimiter=";"))
    pattern = r"^(?:[^;]*;){4}(?:" + "|".join(codes) + ");"
    process = subprocess.Popen(["rg", "--text", "--no-heading", "--no-filename", pattern, str(source)],
                               stdout=subprocess.PIPE, text=True, encoding="latin1")
    rows = [row for row in csv.DictReader(process.stdout, fieldnames=header, delimiter=";") if row["Ano"] == "2025"]
    assert process.wait() == 0
    return list({tuple(row.values()): row for row in rows}.values())


def counts(row, length=3):
    raw = [row[f"Col{i:02d}"] for i in range(1, length + 1)]
    if not all(value.isdigit() for value in raw):
        return None
    result = list(map(int, raw))
    if result[0] != result[1] + result[2]:
        return None
    return result


def run():
    groups = defaultdict(lambda: defaultdict(list))
    for row in source_rows("P", FUNCTION):
        if row["Mes"] != "12":
            continue
        groups[(row["IdServicio"], row["IdEstablecimiento"])][row["CodigoPrestacion"]].append(row)
    totals = {"Men": {"n": 0, "N": 0, "providers": 0}, "Women": {"n": 0, "N": 0, "providers": 0}}
    for provider in groups.values():
        if not all(len(provider[code]) == 1 for code in FUNCTION):
            continue
        rows = [provider[code][0] for code in FUNCTION]
        if len({row["IdRegion"] for row in rows}) != 1:
            continue
        values = [counts(row) for row in rows]
        if any(value is None for value in values):
            continue
        for sex, index in [("Men", 1), ("Women", 2)]:
            denominator = sum(value[index] for value in values)
            if denominator:
                totals[sex]["N"] += denominator
                totals[sex]["n"] += sum(value[index] for value in values[2:])
                totals[sex]["providers"] += 1
    assert totals["Women"]["n"] == 176197 and totals["Women"]["N"] == 585129
    assert totals["Men"]["n"] == 93773 and totals["Men"]["N"] == 368430
    a = source_rows("A", ["06906135", "03500361", "03500362"])
    gds = [row for row in a if row["CodigoPrestacion"] == "06906135"]
    complete = []
    for row in gds:
        value = counts(row, 9)
        if value and value[1] == value[3] + value[5] + value[7] and value[2] == value[4] + value[6] + value[8]:
            complete.append(value)
    gds_result = {"source_rows": len(gds), "complete_nine_cell_rows": len(complete),
                  "complete_category_N": sum(value[0] for value in complete),
                  "women_N": sum(value[2] for value in complete), "women_increased_deterioration_n": sum(value[4] for value in complete)}
    assert gds_result["complete_category_N"] == 3531
    assert gds_result["women_N"] == 2315 and gds_result["women_increased_deterioration_n"] == 722
    pairs = defaultdict(lambda: defaultdict(list))
    for row in a:
        if row["CodigoPrestacion"] in ["03500361", "03500362"]:
            pairs[(row["Ano"], row["Mes"], row["IdServicio"], row["IdEstablecimiento"])][row["CodigoPrestacion"]].append(row)
    zarit = {"Men": {"n": 0, "N": 0}, "Women": {"n": 0, "N": 0}}
    for pair in pairs.values():
        if not all(len(pair[code]) == 1 for code in ["03500361", "03500362"]):
            continue
        values = [counts(pair[code][0]) for code in ["03500361", "03500362"]]
        if any(value is None for value in values):
            continue
        for sex, index in [("Men", 1), ("Women", 2)]:
            zarit[sex]["n"] += values[0][index]
            zarit[sex]["N"] += sum(value[index] for value in values)
    assert zarit["Women"] == {"n": 23459, "N": 47244}
    assert zarit["Men"] == {"n": 6399, "N": 13313}
    result = {"status": "PASS", "scope": "Independent direct-original-CSV recomputation, 2025 only", "P5_dependency_risk_or_dependency": totals,
              "GDS_complete_category_subset": gds_result, "Zarit_intense_burden_paired_category_subset": zarit,
              "unit": "Recorded classified populations or evaluation activities, not national prevalence or unique longitudinal people"}
    OUT.mkdir(exist_ok=True)
    (OUT / "independent_2025_source_validation.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result))


if __name__ == "__main__":
    run()
