"""Read-only audit of A06 dementia evaluation aggregates; preserve original values."""
from pathlib import Path
import pandas as pd
import hashlib,json,subprocess,os
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/rem_neuro_instruments_2026-10-30/cognitive_field_search'
OUT.mkdir(parents=True,exist_ok=True)
DATA=Path(os.environ.get('ASESORIAS_DATA_ROOT','/Volumes/Datos/Asesorias_Data'))
PRIVATE=DATA/'derived/Reproductive-hormones-cognitive-decline-women-Chile/rem_neuro_instruments'
CODES=['06906135','06906140','06906145']
COLS=[f'Col{i:02d}' for i in range(1,10)]
KEY=['Ano','Mes','IdServicio','IdEstablecimiento','CodigoPrestacion']
FAC=['Ano','Mes','IdServicio','IdEstablecimiento']
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
profiles=[];parts=[];sources=[]
for year in range(2019,2026):
 p=PRIVATE/f'instrument_selected_A_{year}.csv.gz'
 f=pd.read_csv(p,dtype=str,keep_default_na=False)
 f=f.loc[f.CodigoPrestacion.isin(CODES)].copy()
 n=f[COLS].apply(pd.to_numeric,errors='coerce')
 sources.append({'year':year,'selected_cache_file':p.name,'sha256':digest(p),'rows_in_scope':len(f)})
 for code in CODES:
  q=f.loc[f.CodigoPrestacion.eq(code)];v=n.loc[q.index]
  sex=v[['Col01','Col02','Col03']].notna().all(axis=1)
  all9=v.notna().all(axis=1)
  totalok=v.Col01.eq(v.Col02+v.Col03)
  maleok=v.Col02.eq(v[['Col04','Col06','Col08']].sum(axis=1,min_count=3))
  femaleok=v.Col03.eq(v[['Col05','Col07','Col09']].sum(axis=1,min_count=3))
  # Partial categories supply an observed lower bound only; blanks remain missing.
  catlower=v[COLS[3:]].sum(axis=1,min_count=1)
  profile={'year':year,'code':code,'observed_rows':len(q),'distinct_facilities':q.IdEstablecimiento.nunique(),'months_observed':';'.join(sorted(q.Mes.unique(),key=int)),
  'raw_duplicate_key_rows':int(q.duplicated(KEY,keep=False).sum()),'rows_with_blank_mapped_cells':int(q[COLS].eq('').any(axis=1).sum()),'rows_all9_numeric':int(all9.sum()),
  'rows_sex_evaluable':int(sex.sum()),'rows_sex_reconciled':int((sex&totalok).sum()),'rows_sex_mismatch':int((sex&~totalok).sum()),
  'rows_all9_all3_checks_reconciled':int((all9&totalok&maleok&femaleok).sum()),'rows_all9_any_check_mismatch':int((all9&~(totalok&maleok&femaleok)).sum()),
  'rows_observed_change_sum_exceeds_total':int((v.Col01.notna()&catlower.gt(v.Col01)).sum()),
  'sum_observed_col01':float(v.Col01.sum()),'sum_observed_col02_men':float(v.Col02.sum()),'sum_observed_col03_women':float(v.Col03.sum()),'max_observed_col01':float(v.Col01.max()) if len(q) else None}
  profiles.append(profile)
 f['selected_year']=year;parts.append(f)
f=pd.concat(parts,ignore_index=True)
num=f[COLS].apply(pd.to_numeric,errors='coerce')
pattern=(num.notna().all(axis=1)&num.Col01.gt(0)&num.Col01.eq(num.Col02+num.Col03)&num.Col02.eq(3*num.Col04)&num.Col03.eq(3*num.Col05)&num.Col04.eq(num.Col06)&num.Col04.eq(num.Col08)&num.Col05.eq(num.Col07)&num.Col05.eq(num.Col09))
candidates=[];flagged=[]
for key,q in f.loc[pattern].groupby(FAC,dropna=False):
 if set(q.CodigoPrestacion)==set(CODES) and len(q)==3 and len(q[COLS].drop_duplicates())==1:
  candidates.append({'year':int(key[0]),'month':int(key[1]),'service':key[2],'facility':key[3],'rows':len(q),'col01_each_code':int(q.iloc[0].Col01),'identical_9cell_vector_between_three_codes':True,'all_outcome_categories_exactly_one_third_sex_total':True})
  flagged.append(q)
flag=pd.concat(flagged,ignore_index=True) if flagged else f.iloc[:0]
flag.to_csv(PRIVATE/'anomaly_identical_uniform_three_codes_rows.csv',index=False)
flag2021=flag.loc[flag.Ano.eq('2021')]
# Confirm every flagged 2021 row is already present verbatim in the canonical source.
source=DATA/'REM/SerieA/SerieA_2021.csv'
pat=r'^1;16;2021;(?:116305|116343|200232|116780);(?:06906135|06906140|06906145);'
r=subprocess.run(['rg','--text','--no-filename','--no-line-number',pat,str(source)],capture_output=True,check=False)
assert r.returncode==0
rawlines=r.stdout.decode('latin1').splitlines()
expected=[';'.join(row) for row in flag2021.drop(columns='selected_year').itertuples(index=False,name=None)]
assert sorted(rawlines)==sorted(expected),'Selected-cache rows differ from canonical raw source'
cluster=[]
for (year,month,service),q in pd.DataFrame(candidates).groupby(['year','month','service']):
 cluster.append({'year':int(year),'month':int(month),'service':str(service),'facilities':len(q),'three_code_rows':int(q.rows.sum()),'col01_sum_per_code':int(q.col01_each_code.sum()),'max_col01_per_facility':int(q.col01_each_code.max())})
residual=[]
for code in CODES:
 q=f.loc[(f.Ano=='2021')&(f.CodigoPrestacion==code)]
 z=flag2021.loc[flag2021.CodigoPrestacion.eq(code)]
 total=pd.to_numeric(q.Col01,errors='coerce').sum();susp=pd.to_numeric(z.Col01,errors='coerce').sum()
 residual.append({'year':2021,'code':code,'raw_col01_sum':float(total),'flagged_cluster_col01_sum':float(susp),'raw_sum_outside_flagged_cluster':float(total-susp),'flagged_share_percent':float(100*susp/total),'qualification':'Diagnostic contrast only: original values retained; exclusion is not adopted as the definitive estimate.'})
report={'purpose':'Investigate the exceptional 2021 A06 three-code spike and independently audit arithmetic reconciliation without imputing blank cells or deleting rows.',
 'scope':{'years':list(range(2019,2026)),'codes':CODES,'columns':COLS,'raw_duplicate_rows_retained':True,'blank_cells':'Preserved as missing; exact equations are evaluated only when all required cells are numeric.'},
 'selected_source_files':sources,'reconciliation_profiles':profiles,'identical_uniform_vector_clusters':cluster,'2021_diagnostic_contrast':residual,
 'canonical_source_confirmation':{'file':source.name,'verified_rows':len(rawlines),'cache_rows_match_canonical_source_exactly':True,'sorted_flagged_raw_lines_sha256':hashlib.sha256('\n'.join(sorted(rawlines)).encode('latin1')).hexdigest()},
 'assessment':{'severity':'High','finding':'A January 2021 cluster of four facilities carries the same exceptionally large nine-cell vector in all three distinct constructs. Each sex-specific outcome category is exactly one third of its sex total. Simple total/sex/category arithmetic checks pass despite this suspicious replication.',
 'provenance':'The vectors are present in the canonical raw source, not introduced by this selected-cache extraction. The source alone does not identify their cause.',
 'identifier_like_values':'No literal identifier-to-count substitution was established. Systematic identical vectors and equal thirds are observed; transcription, test data or upstream processing are hypotheses, not proven causes.',
 'usability':'Do not present the unqualified 2021 total or a pooled 2019–2025 trend for these three A06 measures as a credible programme-volume result. Retain raw records and flag the cluster. Seek source correction/confirmation; present explicit sensitivity contrasts if the measures are developed further. Arithmetic consistency does not resolve construct validity.',
 'other_years':'Multi-year arithmetic profiles are descriptive quality checks, not complete validation. Duplicate keys remain unresolved in this audit and are handled by the parent workflow.'}}
(OUT/'anomaly_a06_three_code_audit.json').write_text(json.dumps(report,indent=2))
pd.DataFrame(profiles).to_csv(OUT/'anomaly_a06_annual_reconciliation.csv',index=False)
pd.DataFrame(cluster).to_csv(OUT/'anomaly_a06_identical_vector_clusters.csv',index=False)
pd.DataFrame(residual).to_csv(OUT/'anomaly_a06_2021_diagnostic_contrast.csv',index=False)
print(json.dumps({'clusters':cluster,'2021_contrast':residual,'reconciliation':profiles},indent=2))
