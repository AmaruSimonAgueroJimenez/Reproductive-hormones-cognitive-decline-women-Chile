"""Shared, source-backed REM instrument extension for the three reports.

The display bundle is an analysis product, not a scientific source. Institutional
manuals, annual coded templates and the aggregate source tables are identified
separately. Rendering reads portable aggregate evidence and never substitutes an
absent row or a blank cell with zero.
"""
from __future__ import annotations

import hashlib
import html
import json
from pathlib import Path
import re

import pandas as pd

BUNDLE_RELATIVE = Path("outputs/rem_neuro_instruments_2026-10-30/report_bundle.json")
CONTEXT = {
    "descriptive": (
        "The additional REM analyses extend the descriptive burden account with "
        "functional status, fall-risk classifications, dementia programme "
        "reassessments and caregiver measures. They describe the people or "
        "activities recorded in each programme. Their denominators remain "
        "specific to the instrument and are not national disease-prevalence denominators."
    ),
    "connected": (
        "The additional REM analyses make the care context more explicit by "
        "describing functional status, fall-risk classifications, dementia "
        "programme reassessments and caregiver measures. These observations "
        "supply complementary service and outcome context for the reproductive "
        "analyses. They do not link an individual's menopause care to later "
        "cognitive or neurodegenerative change."
    ),
    "access": (
        "The additional REM analyses extend the diagnostic-recording account "
        "from caseload visibility to functional classifications, dementia "
        "programme reassessment and caregiver measures. Recorded assessment "
        "and programme change are distinct from clinical diagnostic sensitivity, "
        "unmet need and access to appropriate care. The data-quality decisions "
        "and the denominator for each instrument remain part of the result."
    ),
}

OFFICIAL_SOURCES = [
    (
        "DEIS annual REM files and coded dictionaries",
        "https://deis.minsal.cl/#datosabiertos",
    ),
    (
        "DEIS REM 2025–2026 Series A manual version 1.3",
        "https://repositoriodeis.minsal.cl/ContenidoSitioWeb2020/REM/2025/SERIE/Manual_Series_REM_2025_2026_SERIE_A_BS_BM_D_V1.3.pdf",
    ),
    (
        "DEIS REM 2025–2026 Series P manual version 1.1",
        "https://repositoriodeis.minsal.cl/ContenidoSitioWeb2020/REM/2025/SERIE/MANUAL_REM_P_2025_V1.1.pdf",
    ),
]


def file_sha(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def content_hash(data: dict) -> str:
    payload = {key: value for key, value in data.items() if key != "content_sha256"}
    return hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def checked_path(project: Path, relative: str) -> Path:
    relative_path = Path(str(relative))
    if relative_path.is_absolute() or ".." in relative_path.parts:
        raise ValueError(f"Instrument evidence paths must be project-relative: {relative}")
    result = project / relative_path
    if not result.is_file():
        raise FileNotFoundError(result)
    return result


def source_paths(item: dict) -> list[str]:
    value = item.get("source_csv", [])
    if not value:
        return []
    return [value] if isinstance(value, str) else list(value)


def load_instrument_bundle(project: Path) -> dict:
    project = Path(project)
    path = checked_path(project, str(BUNDLE_RELATIVE))
    bundle = json.loads(path.read_text(encoding="utf-8"))
    for key in ["methods", "results", "tables", "figures"]:
        if not isinstance(bundle.get(key), list):
            raise ValueError(f"Missing instrument bundle list: {key}")
    identifiers = [str(item["id"]) for key in ["tables", "figures"] for item in bundle[key]]
    if len(identifiers) != len(set(identifiers)):
        raise ValueError("Instrument table and figure identifiers must be unique")
    table_ids = {str(item["id"]) for item in bundle["tables"]}
    figure_ids = {str(item["id"]) for item in bundle["figures"]}
    for section in [*bundle["methods"], *bundle["results"]]:
        if not section.get("title") or not isinstance(section.get("paragraphs"), list):
            raise ValueError("Each instrument section needs a title and paragraph list")
        if not set(map(str, section.get("table_ids", []))).issubset(table_ids):
            raise ValueError(f"Unknown instrument table reference: {section['title']}")
        if not set(map(str, section.get("figure_ids", []))).issubset(figure_ids):
            raise ValueError(f"Unknown instrument figure reference: {section['title']}")
    for table in bundle["tables"]:
        if not table.get("columns") or not isinstance(table.get("rows"), list):
            raise ValueError(f"Malformed instrument table: {table['id']}")
        if any(len(row) != len(table["columns"]) for row in table["rows"]):
            raise ValueError(f"Instrument table row length mismatch: {table['id']}")
        for source in source_paths(table):
            checked_path(project, source)
    for figure in bundle["figures"]:
        for key in ["path_png", "path_pdf", "path_svg"]:
            checked_path(project, figure[key])
        if not figure.get("caption") or not figure.get("alt"):
            raise ValueError(f"Caption and accessible description required: {figure['id']}")
        for source in source_paths(figure):
            checked_path(project, source)
    for record in bundle.get("file_hashes", []):
        path = checked_path(project, record["path"])
        if file_sha(path) != record["sha256"]:
            raise ValueError(f"Instrument evidence file changed: {record['path']}")
    calculated = content_hash(bundle)
    if bundle.get("content_sha256") and bundle["content_sha256"] != calculated:
        raise ValueError("The instrument content hash differs from its saved evidence")
    bundle["content_sha256"] = calculated
    return bundle


def validate_arithmetic_checks(project: Path, bundle: dict) -> list[dict]:
    """Recalculate explicitly declared aggregate checks instead of trusting prose.

    Optional checks name a CSV and its count columns. More specialised analytical
    checks remain in the component analysis scripts and saved validation records.
    A missing/blank count is an error for a declared complete-case check.
    """
    result = []
    for check in bundle.get("arithmetic_checks", []):
        frame = pd.read_csv(checked_path(project, check["source_csv"]))
        for name, value in check.get("where", {}).items():
            frame = frame[frame[name].astype(str) == str(value)]
        if frame.empty:
            raise ValueError(f"An instrument aggregate check selected no rows: {check['id']}")
        tolerance = float(check.get("absolute_tolerance", 1e-8))
        if check.get("type") == "grouped_category_sum":
            group_columns = check["group_columns"]
            required = [check["count_column"], check["denominator_column"]]
            for column in required:
                frame[column] = pd.to_numeric(frame[column], errors="coerce")
            if frame[required].isna().any().any() or frame[group_columns].isna().any().any():
                raise ValueError(f"A grouped complete-case check contains missing data: {check['id']}")
            percent_column = check.get("percent_column")
            if percent_column:
                percent_was_missing = frame[percent_column].isna() | frame[percent_column].astype(str).str.strip().eq("")
                frame[percent_column] = pd.to_numeric(frame[percent_column], errors="coerce")
            if (frame[check["count_column"]] < 0).any() or (frame[check["denominator_column"]] < 0).any():
                raise ValueError(f"Invalid count or nonpositive analytic denominator: {check['id']}")
            if not check.get("allow_zero_denominator", False) and (frame[check["denominator_column"]] == 0).any():
                raise ValueError(f"Nonpositive analytic denominator: {check['id']}")
            groups, zero_groups, percentage_rows = 0, 0, 0
            for _, group in frame.groupby(group_columns, dropna=False, sort=False):
                denominator = group[check["denominator_column"]]
                if denominator.max() - denominator.min() > tolerance:
                    raise ValueError(f"One group has multiple denominators: {check['id']}")
                total = float(denominator.iloc[0])
                if abs(float(group[check["count_column"]].sum()) - total) > tolerance:
                    raise ValueError(f"Category counts do not sum to their denominator: {check['id']}")
                if total == 0:
                    # Zero eligible complete-case observations do not establish
                    # zero prevalence or zero change. The percentage stays NA.
                    if not group[check["count_column"]].eq(0).all():
                        raise ValueError(f"A zero denominator has nonzero counts: {check['id']}")
                    if percent_column and not percent_was_missing.loc[group.index].all():
                        raise ValueError(f"A zero denominator must retain missing percentages: {check['id']}")
                    zero_groups += 1
                elif percent_column:
                    if group[percent_column].isna().any():
                        raise ValueError(f"Positive denominators require numeric category percentages: {check['id']}")
                    expected = 100 * group[check["count_column"]] / denominator
                    percent_tolerance = float(check.get("percent_absolute_tolerance", tolerance))
                    if not ((expected - group[percent_column]).abs() <= percent_tolerance).all():
                        raise ValueError(f"Stored category percentages differ from counts: {check['id']}")
                    percentage_rows += len(group)
                groups += 1
            result.append({"id": check["id"], "type": "grouped_category_sum",
                           "rows_recalculated": len(frame), "groups_recalculated": groups,
                           "zero_denominator_groups_retained_as_missing": zero_groups,
                           "percentage_rows_recalculated": percentage_rows,
                           "status": "PASS"})
            continue
        total = pd.to_numeric(frame[check["total_column"]], errors="coerce")
        parts = frame[check["part_columns"]].apply(pd.to_numeric, errors="coerce")
        if total.isna().any() or parts.isna().any().any():
            raise ValueError(f"A declared complete aggregate check contains missing values: {check['id']}")
        if not ((total - parts.sum(axis=1)).abs() <= tolerance).all():
            raise ValueError(f"Aggregate instrument arithmetic failed: {check['id']}")
        result.append({"id": check["id"], "rows_recalculated": len(frame), "status": "PASS"})
    return result


class InstrumentRenderer:
    def __init__(self, project: Path, bundle: dict):
        from IPython.display import HTML, Markdown, display
        self.project, self.bundle = Path(project), bundle
        self.display, self.HTML, self.Markdown = display, HTML, Markdown
        self.tables = {str(item["id"]): item for item in bundle["tables"]}
        self.figures = {str(item["id"]): item for item in bundle["figures"]}

    def md(self, value):
        self.display(self.Markdown("\n\n" + str(value) + "\n\n"))

    def raw(self, value):
        self.display(self.HTML("\n\n" + str(value) + "\n\n"))

    def methods(self):
        for section in self.bundle["methods"]:
            self.md("#### " + section["title"])
            for paragraph in section["paragraphs"]:
                self.md(paragraph)

    def table(self, identifier):
        item = self.tables[str(identifier)]
        # Preserve the same explicit cell strings consumed by the Word writer;
        # Pandas' default float formatting must not change table precision.
        rows = [["Not available" if value is None else str(value) for value in row]
                for row in item["rows"]]
        frame = pd.DataFrame(rows, columns=item["columns"])
        body = frame.to_html(index=False, escape=True, classes="instrument-table", na_rep="Not available")
        self.md("#### Table " + item["id"] + " " + item["title"])
        self.raw('<div class="table-responsive instrument-table-container" data-instrument-table="'
                 + html.escape(item["id"], quote=True) + '">' + body + '</div>')
        self.md(item.get("note", ""))
        for index, source in enumerate(source_paths(item), 1):
            label = "Download aggregate source table" if len(source_paths(item)) == 1 else f"Download aggregate source table {index}"
            self.md(f"[{label}](../{source})")

    def figure(self, identifier):
        item = self.figures[str(identifier)]
        self.md("#### Figure " + item["id"] + " " + item.get("title", ""))
        self.raw('<img class="paper-figure instrument-figure" data-instrument-figure="'
                 + html.escape(item["id"], quote=True) + '" src="../'
                 + html.escape(item["path_png"], quote=True) + '" alt="'
                 + html.escape(item["alt"], quote=True)
                 + '" style="display:block;max-width:100%;height:auto;margin:1.4rem auto">')
        self.md(item["caption"])
        links = [f'[Vector PDF](../{item["path_pdf"]})', f'[Editable SVG](../{item["path_svg"]})',
                 f'[600 dpi PNG](../{item["path_png"]})']
        for index, source in enumerate(source_paths(item), 1):
            label = "Plotted aggregate data" if len(source_paths(item)) == 1 else f"Plotted aggregate data {index}"
            links.append(f"[{label}](../{source})")
        self.md(" · ".join(links))

    def results(self, context="descriptive"):
        self.md(CONTEXT[context])
        seen_tables, seen_figures = set(), set()
        for section in self.bundle["results"]:
            self.md("### " + section["title"])
            for paragraph in section["paragraphs"]:
                self.md(paragraph)
            for key in map(str, section.get("figure_ids", [])):
                if key not in seen_figures:
                    self.figure(key)
                    seen_figures.add(key)
            for key in map(str, section.get("table_ids", [])):
                if key not in seen_tables:
                    self.table(key)
                    seen_tables.add(key)
        remaining_tables = set(self.tables) - seen_tables
        remaining_figures = set(self.figures) - seen_figures
        if remaining_tables or remaining_figures:
            self.md("### Additional instrument tables and figures")
            for key in self.figures:
                if key in remaining_figures:
                    self.figure(key)
            for key in self.tables:
                if key in remaining_tables:
                    self.table(key)
        self.md("### Instrument definitions and aggregate evidence")
        self.md("Scientific definitions come from the DEIS annual coded dictionaries and REM manuals. "
                "The display bundle and computational records document the analysis; they are not "
                "substitute scientific sources. The source tables linked above retain the exact "
                "aggregate data used for each new table and panel figure.")
        for title, url in OFFICIAL_SOURCES:
            self.md(f"[{title}]({url})")
        self.raw('<details class="provenance instrument-provenance" data-instrument-evidence="'
                 + self.bundle["content_sha256"] + '"><summary>Inspect the instrument reproducibility record</summary>'
                 + '<p>Aggregate evidence identifier: <code>' + self.bundle["content_sha256"]
                 + '</code>. All paths are relative to the project and figure images are shared with the Word reports.</p></details>')


def normalize(text):
    text = str(text).translate(str.maketrans({"‘": "'", "’": "'", "“": '"', "”": '"'}))
    text = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", text)
    text = re.sub(r"\s+", " ", text).strip()
    return re.sub(r"\s+([.,;:!?])", r"\1", text)


def validate_instrument_html(project: Path, html_path: Path) -> dict:
    """Check exact extension prose, table cells, figure bytes and visible sources."""
    import base64
    from bs4 import BeautifulSoup
    project, html_path = Path(project), Path(html_path)
    bundle = load_instrument_bundle(project)
    soup = BeautifulSoup(html_path.read_text(), "html.parser")
    main = soup.find("main") or soup
    text = normalize(main.get_text(" ", strip=True))
    assert soup.html.get("lang") == "en"
    # Quarto reserves a rem- chunk prefix for automatically numbered remarks.
    # Instrument code cells must remain ordinary folded analysis cells.
    assert not main.select(".quarto-remark, .theorem.remark, .theorem[id*='instrument']"), "Unexpected automatic remark/theorem wrapper"
    for section in [*bundle["methods"], *bundle["results"]]:
        for paragraph in section["paragraphs"]:
            assert normalize(paragraph) in text, section["title"]
    figures = main.select("img.instrument-figure")
    assert len(figures) == len(bundle["figures"])
    actual_figure_ids = [item.get("data-instrument-figure") for item in figures]
    assert len(actual_figure_ids) == len(set(actual_figure_ids))
    for expected in bundle["figures"]:
        image = next(item for item in figures if item.get("data-instrument-figure") == expected["id"])
        uri = image["src"]
        expected_hash = file_sha(project / expected["path_png"])
        if uri.startswith("data:image/png;base64,"):
            actual_hash = hashlib.sha256(base64.b64decode(uri.split(",", 1)[1])).hexdigest()
        else:
            from urllib.parse import urlsplit, unquote
            actual_path = (html_path.parent / unquote(urlsplit(uri).path)).resolve()
            actual_hash = file_sha(actual_path)
        assert actual_hash == expected_hash, expected["id"]
        assert normalize(expected["caption"]) in text, expected["id"]
    containers = main.select("[data-instrument-table]")
    assert len(containers) == len(bundle["tables"])
    checked_cells = 0
    for expected in bundle["tables"]:
        container = next(item for item in containers if item.get("data-instrument-table") == expected["id"])
        rows = [[normalize(cell.get_text(" ", strip=True)) for cell in row.find_all(["th", "td"])]
                for row in container.find_all("tr")]
        expected_rows = [[normalize(value) for value in expected["columns"]],
                         *[[normalize(value) if value is not None else "Not available" for value in row] for row in expected["rows"]]]
        assert rows == expected_rows, expected["id"]
        checked_cells += sum(map(len, rows))
    assert bundle["content_sha256"] in text
    assert len(main.select("details.code-fold")) >= 3
    return {"status": "PASS", "report": str(html_path.relative_to(project)),
            "instrument_content_sha256": bundle["content_sha256"],
            "instrument_figures": len(figures), "instrument_tables": len(containers),
            "verified_instrument_table_cells": checked_cells,
            "all_instrument_paragraphs_present": True, "exact_figure_images": True,
            "no_instrument_auto_theorem_wrappers": True,
            "arithmetic_checks": validate_arithmetic_checks(project, bundle)}
