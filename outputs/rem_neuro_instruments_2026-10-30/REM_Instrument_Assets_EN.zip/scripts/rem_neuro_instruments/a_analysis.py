"""Analyse selected REM A instrument aggregates without imputing missing cells.

No patient-level outcomes, raw instrument scores, national prevalence or causal
effects are inferred. Exact source duplicates are collapsed; conflicting keys
are quarantined. The contaminated 2021 A06 year is withheld from primary series.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
DATA = Path(os.environ.get("ASESORIAS_DATA_ROOT", "/Volumes/Datos/Asesorias_Data"))
PRIVATE = DATA / "derived/Reproductive-hormones-cognitive-decline-women-Chile/rem_neuro_instruments"
OUT = ROOT / "outputs/rem_neuro_instruments_2026-10-30/analysis_a"
FAC = ["Ano", "Mes", "IdServicio", "IdEstablecimiento"]
KEY = FAC + ["CodigoPrestacion"]
CORE = ["Col01", "Col02", "Col03"]
NINE = [f"Col{i:02d}" for i in range(1, 10)]
A06 = {"06906135": "GDS-Reisberg", "06906140": "Dementia caregiver burden", "06906145": "Dementia caregiver satisfaction"}
TOOLS = {
    "Timed Up and Go": ["03500350", "03500351", "03500352"],
    "Functionality questionnaire": ["03500353", "03500354", "03500355"],
    "Hospital Barthel change": ["03500356", "03500357", "03500358"],
}
ZARIT = ["03500361", "03500362"]
YESAVAGE = {"09600226": "Yesavage GDS-15 applications"}
USED = set(A06) | set(ZARIT) | set(YESAVAGE) | {c for codes in TOOLS.values() for c in codes}
SEX = {"Both sexes": "Col01", "Men": "Col02", "Women": "Col03"}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def rel(path):
    return str(Path(path).resolve().relative_to(ROOT))


def number(v):
    return f"{int(v):,}" if pd.notna(v) else "NA"


def pct(n, d):
    return 100 * n / d if d > 0 else np.nan


def npercent(n, d):
    return f"{number(n)} ({100*n/d:.1f}%)" if d > 0 else f"{number(n)} (NA)"


def numeric(frame, cols):
    return frame[cols].apply(pd.to_numeric, errors="coerce")


def coherent_core(frame):
    v = numeric(frame, CORE)
    return v.notna().all(axis=1) & v.ge(0).all(axis=1) & v.eq(v.round()).all(axis=1) & v.Col01.eq(v.Col02 + v.Col03)


def complete_a06(frame):
    v = numeric(frame, NINE)
    return (v.notna().all(axis=1) & v.ge(0).all(axis=1) & v.eq(v.round()).all(axis=1)
            & v.Col01.eq(v.Col02 + v.Col03)
            & v.Col02.eq(v[["Col04", "Col06", "Col08"]].sum(axis=1, min_count=3))
            & v.Col03.eq(v[["Col05", "Col07", "Col09"]].sum(axis=1, min_count=3)))


def save_data(frame, name):
    path = OUT / "source_data" / name
    frame.to_csv(path, index=False)
    return rel(path)


def load_clean():
    mapping_path = ROOT / "outputs/rem_neuro_instruments_2026-10-30/a_dictionary_audit/annual_code_inventory.csv"
    mapping = pd.read_csv(mapping_path, dtype=str, keep_default_na=False)
    logs, sources, parts, quarantines = [], [], [], []
    for year in range(2019, 2026):
        path = PRIVATE / f"instrument_selected_A_{year}.csv.gz"
        raw = pd.read_csv(path, dtype=str, keep_default_na=False)
        raw = raw.loc[raw.CodigoPrestacion.isin(USED)].copy()
        source_n = len(raw)
        d = raw.drop_duplicates().copy()
        dup_removed = source_n - len(d)
        conflict = d.duplicated(KEY, keep=False)
        q = d.loc[conflict].copy()
        q["quarantine_reason"] = "Conflicting records at one facility-month-code key; no authoritative order"
        quarantines.append(q)
        d = d.loc[~conflict].copy()
        annual = mapping.loc[mapping.year.eq(str(year)) & mapping.code.isin(USED)]
        codes = set(annual.code)
        unmapped = int((~d.CodigoPrestacion.isin(codes)).sum())
        d = d.loc[d.CodigoPrestacion.isin(codes)].copy()
        assert not d.duplicated(KEY).any()
        blanks = zeros = 0
        for code, m in annual.groupby("code"):
            active = m.iloc[0].coded_columns.split(";")
            z = d.loc[d.CodigoPrestacion.eq(code), active]
            blanks += int(z.eq("").sum().sum())
            zeros += int(z.apply(pd.to_numeric, errors="coerce").eq(0).sum().sum())
        logs.append({"year": year, "selected_source_rows": source_n, "exact_duplicates_removed": dup_removed,
                     "conflicting_keys_quarantined": int(q[KEY].drop_duplicates().shape[0]), "conflicting_rows_quarantined": len(q),
                     "unmapped_rows_not_interpreted": unmapped, "retained_rows": len(d),
                     "retained_mapped_blank_cells": blanks, "retained_mapped_explicit_zero_cells": zeros,
                     "A06_rows_withheld_from_primary_2021": int(d.CodigoPrestacion.isin(A06).sum()) if year == 2021 else 0})
        sources.append({"year": year, "selected_cache_file": path.name, "sha256": sha(path), "mapping_sha256": sha(mapping_path)})
        parts.append(d)
    pd.concat(quarantines, ignore_index=True).to_csv(PRIVATE / "a_analysis_conflicting_key_quarantine.csv", index=False)
    frame = pd.concat(parts, ignore_index=True)
    frame["year"] = pd.to_numeric(frame.Ano).astype(int)
    return frame, pd.DataFrame(logs), sources


def a06_analysis(frame):
    annual, changes = [], []
    for (year, code), q in frame.loc[frame.CodigoPrestacion.isin(A06)].groupby(["year", "CodigoPrestacion"]):
        core_ok = coherent_core(q)
        good = complete_a06(q)
        qcore, qgood = q.loc[core_ok], q.loc[good]
        vcore = numeric(qcore, CORE)
        vg = numeric(qgood, NINE)
        allnine = numeric(q, NINE).notna().all(axis=1)
        status = "Withheld: unresolved source anomaly" if year == 2021 else "Primary descriptive series"
        item = {"year": int(year), "code": code, "measure": A06[code], "primary_status": status,
                "observed_rows": len(q), "coherent_total_rows": int(core_ok.sum()),
                "excluded_invalid_total_rows": int((~core_ok).sum()), "complete9_rows": int(good.sum()),
                "excluded_missing9_rows": int((~allnine).sum()), "excluded_invalid9_complete_rows": int((allnine & ~good).sum()),
                "facilities_with_rows": int(q.IdEstablecimiento.nunique()), "facilities_complete9": int(qgood.IdEstablecimiento.nunique()),
                "complete9_row_percent": pct(int(good.sum()), len(q)),
                "observed_events_diagnostic": float(vcore.Col01.sum()), "observed_men_diagnostic": float(vcore.Col02.sum()), "observed_women_diagnostic": float(vcore.Col03.sum()),
                "complete9_events_diagnostic": float(vg.Col01.sum()),
                "primary_events": float(vcore.Col01.sum()) if year != 2021 else np.nan,
                "primary_men": float(vcore.Col02.sum()) if year != 2021 else np.nan,
                "primary_women": float(vcore.Col03.sum()) if year != 2021 else np.nan,
                "primary_facilities": int(q.IdEstablecimiento.nunique()) if year != 2021 else np.nan}
        annual.append(item)
        if year == 2021:
            continue
        for sex, col in SEX.items():
            if sex == "Both sexes":
                counts = [vg[["Col04", "Col05"]].sum().sum(), vg[["Col06", "Col07"]].sum().sum(), vg[["Col08", "Col09"]].sum().sum()]
            else:
                cols = ["Col04", "Col06", "Col08"] if sex == "Men" else ["Col05", "Col07", "Col09"]
                counts = [vg[c].sum() for c in cols]
            den = vg[col].sum()
            assert sum(counts) == den
            for direction, n in zip(["Increase", "Maintained", "Decrease"], counts):
                changes.append({"year": int(year), "code": code, "measure": A06[code], "sex": sex, "direction": direction,
                                "recorded_evaluations": float(n), "denominator": float(den), "percent": pct(n, den),
                                "eligible_facility_month_rows": len(qgood), "candidate_facility_month_rows": len(q),
                                "eligible_facilities": qgood.IdEstablecimiento.nunique(), "unit": "Recorded evaluations in complete, coherent nine-cell rows"})
    return pd.DataFrame(annual), pd.DataFrame(changes)


def categorical_sets(frame, label, codes, directions):
    rows, selection = [], []
    for year in range(2019, 2026):
        q = frame.loc[frame.year.eq(year) & frame.CodigoPrestacion.isin(codes)].copy()
        q["core_ok"] = coherent_core(q)
        flags = q.groupby(FAC, dropna=False).agg(ncodes=("CodigoPrestacion", "nunique"), valid=("core_ok", "all"))
        keep = flags.loc[flags.ncodes.eq(len(codes)) & flags.valid].reset_index()[FAC]
        valid = q.merge(keep, on=FAC, how="inner", validate="many_to_one")
        if len(valid):
            assert valid.groupby(FAC).CodigoPrestacion.nunique().eq(len(codes)).all()
            assert coherent_core(valid).all()
        selection.append({"year": year, "measure": label, "candidate_facility_month_sets": len(flags), "eligible_facility_month_sets": len(keep),
                          "excluded_incomplete_category_sets": int(flags.ncodes.lt(len(codes)).sum()),
                          "excluded_complete_invalid_sets": int((flags.ncodes.eq(len(codes)) & ~flags.valid).sum()),
                          "eligible_set_percent": pct(len(keep), len(flags)), "eligible_facilities": int(valid.IdEstablecimiento.nunique()),
                          "observed_facilities": int(q.IdEstablecimiento.nunique()), "candidate_category_rows": len(q),
                          "eligible_category_rows": len(valid)})
        for sex, col in SEX.items():
            nums = numeric(valid, [col])[col]
            den = nums.sum()
            for direction, code in zip(directions, codes):
                n = pd.to_numeric(valid.loc[valid.CodigoPrestacion.eq(code), col], errors="coerce").sum()
                rows.append({"year": year, "measure": label, "sex": sex, "direction": direction, "recorded_evaluations": float(n),
                             "denominator": float(den), "percent": pct(n, den), "eligible_facility_month_sets": len(keep),
                             "candidate_facility_month_sets": len(flags), "eligible_facilities": int(valid.IdEstablecimiento.nunique()),
                             "unit": "Recorded evaluations in complete, coherent category sets"})
    return pd.DataFrame(rows), pd.DataFrame(selection)


def yesavage_analysis(frame):
    records = []
    for year in range(2023, 2026):
        for code, label in YESAVAGE.items():
            q = frame.loc[frame.year.eq(year) & frame.CodigoPrestacion.eq(code)]
            ok = coherent_core(q)
            v = numeric(q.loc[ok], CORE)
            records.append({"year": year, "code": code, "activity": label, "recorded_events": float(v.Col01.sum()),
                            "men": float(v.Col02.sum()), "women": float(v.Col03.sum()), "facilities_with_coherent_rows": q.loc[ok, "IdEstablecimiento"].nunique(),
                            "observed_rows": len(q), "coherent_rows": int(ok.sum()), "excluded_invalid_total_rows": int((~ok).sum()),
                            "unit": "Recorded activity; pathways may overlap and are not an instrument-specific risk denominator"})
    return pd.DataFrame(records)


def make_table(id, title, columns, rows, note):
    path = OUT / "tables" / f"{id}.csv"
    pd.DataFrame(rows, columns=columns).to_csv(path, index=False)
    return {"id": id, "title": title, "columns": columns, "rows": rows, "note": note, "source_csv": rel(path)}


def write_bundle(annual, changes, zarit, zsel, funcs, fsel, yes, cleaning, sources):
    tables = []
    short = {"GDS-Reisberg": "GDS-Reisberg", "Dementia caregiver burden": "Caregiver burden", "Dementia caregiver satisfaction": "Caregiver satisfaction"}
    rows = []
    for r in annual.sort_values(["measure", "year"]).itertuples():
        withheld = r.year == 2021
        rows.append([str(r.year), short[r.measure], "Withheld" if withheld else number(r.primary_events),
                     "Withheld" if withheld else number(r.primary_women), "Withheld" if withheld else number(r.primary_men),
                     "Withheld" if withheld else number(r.primary_facilities), f"{r.complete9_rows}/{r.observed_rows}",
                     "Source anomaly" if withheld else "Retained"])
    tables.append(make_table("NI-A-T1", "Recorded dementia programme evaluations and complete-field availability, 2019–2025", ["Year", "Measure", "Recorded events", "Women", "Men", "Facilities", "Complete 9-cell rows / observed", "Primary status"], rows,
        "Monthly records may include repeated evaluations of the same person. All 2021 values for these three measures are withheld from primary interpretation because an unresolved January cluster dominates the source. Complete-field availability is an audit of observed rows, not national reporting completeness. Sex refers to the person evaluated: the patient for GDS-Reisberg and the caregiver for caregiver measures."))
    rows=[]
    for (measure, sex), q in changes.loc[changes.year.eq(2025)&changes.sex.ne("Both sexes")].groupby(["measure","sex"]):
        z=q.set_index("direction");den=z.denominator.iloc[0]
        rows.append([short[measure],sex,number(den)]+[npercent(z.loc[d,"recorded_evaluations"],den) for d in ["Increase","Maintained","Decrease"]]+[number(z.eligible_facility_month_rows.iloc[0]),number(z.candidate_facility_month_rows.iloc[0])])
    tables.append(make_table("NI-A-T2", "Sex-specific change categories in complete dementia evaluation rows, 2025",["Measure","Sex of evaluated person","Recorded evaluations N","Increase n (%)","Maintained n (%)","Decrease n (%)","Eligible rows","Observed rows"], rows,
        "Eligibility requires all nine mapped cells numeric, non-negative integers, total=men+women, and sex totals=sum of the three change categories. Missing cells are not replaced by zero. Increase in global deterioration or caregiver burden is adverse; increase in satisfaction has a different interpretation. These are aggregate change categories, not raw scores or longitudinal treatment effects."))
    anomaly=pd.read_csv(OUT/'source_data/a06_2021_diagnostic_contrast.csv',dtype={"code":str})
    rows=[[short[A06[r.code]],number(r.raw_col01_sum),number(r.flagged_cluster_col01_sum),f"{r.flagged_share_percent:.2f}%",number(r.raw_sum_outside_flagged_cluster)] for r in anomaly.itertuples()]
    tables.append(make_table("NI-A-T3","Unresolved 2021 A06 source anomaly: diagnostic sensitivity contrast",["Measure","All source records","Flagged January cluster","Cluster share","Records outside cluster"],rows,
        "The cluster consists of four facilities and 12 original source rows. All three distinct measures repeat identical nine-cell vectors, and each change category equals one third of its sex total. The source rows were confirmed verbatim. Values outside the cluster are a diagnostic sensitivity contrast, not adopted corrections. The entire 2021 year is withheld from primary analyses for these measures."))
    rows=[]
    for r in zarit.loc[zarit.sex.ne("Both sexes")&zarit.direction.eq("Intense burden")].sort_values(["year","sex"]).itertuples():
        sel=zsel.loc[zsel.year.eq(r.year)].iloc[0]
        rows.append([str(r.year),r.sex,number(r.recorded_evaluations),number(r.denominator),f"{r.percent:.1f}%",number(r.eligible_facility_month_sets),number(r.candidate_facility_month_sets),number(r.eligible_facilities)])
    tables.append(make_table("NI-A-T4","Intense caregiver burden in paired Zarit category records, 2019–2025",["Year","Caregiver sex","Intense burden n","Paired-category N","Intense burden (%)","Eligible facility-month sets","Observed facility-month sets","Eligible facilities"],rows,
        "The denominator sums the intense and non-intense burden categories only in facility-months with both rows present, numeric total/sex cells and coherent sex totals. Explicit zero is retained; an absent row or blank is not zero. Caregivers of people with severe dependency are not a dementia-specific cohort, and repeated evaluations may recur. Percentages are not population prevalence."))
    rows=[]
    for (measure,sex),q in funcs.loc[funcs.year.eq(2025)&funcs.sex.ne("Both sexes")].groupby(["measure","sex"]):
        z=q.set_index("direction");den=z.denominator.iloc[0]
        rows.append([measure,sex,number(den)]+[npercent(z.loc[d,"recorded_evaluations"],den) for d in ["Improved","Maintained","Declined"]]+[f"{number(z.eligible_facility_month_sets.iloc[0])}/{number(z.candidate_facility_month_sets.iloc[0])}"])
    tables.append(make_table("NI-A-T5","Functional change categories in complete programme or hospital records, 2025",["Instrument / setting","Sex","Recorded evaluations N","Improved n (%)","Maintained n (%)","Declined n (%)","Eligible / observed facility-month sets"],rows,
        "All three category rows must be present with non-negative integer total/sex counts and total=men+women. TUG and the functionality questionnaire describe discharge from Más Adultos Mayores Autovalentes (age 60+); hospital Barthel describes admission-to-discharge change (age 65+). These are distinct selected settings and are not dementia-specific. No individual pairing or causal intervention benefit is established."))
    rows=[]
    for (year,measure),q in funcs.loc[funcs.sex.eq("Both sexes")].groupby(["year","measure"]):
        z=q.set_index("direction");sel=fsel.loc[fsel.year.eq(year)&fsel.measure.eq(measure)].iloc[0];den=z.denominator.iloc[0]
        rows.append([str(year),measure,number(den),f"{z.loc['Improved','percent']:.1f}%",f"{z.loc['Maintained','percent']:.1f}%",f"{z.loc['Declined','percent']:.1f}%",f"{int(sel.eligible_facility_month_sets):,}/{int(sel.candidate_facility_month_sets):,}",f"{sel.eligible_set_percent:.1f}%"])
    tables.append(make_table("NI-A-T6","Annual complete-set functional change results and selection, 2019–2025",["Year","Instrument / setting","Recorded evaluations N","Improved","Maintained","Declined","Eligible / observed sets","Eligible sets (%)"],rows,
        "Each instrument retains its own eligible facility-month sample. Percentages sum recorded category counts over complete sets; sample composition changes by year. Missing categories are not imputed. Different setting/age scopes prevent direct pooling into a neurodegenerative outcome. Values describe repeated administrative evaluations."))
    rows=[[str(r.year),r.activity,number(r.recorded_events),number(r.women),number(r.men),number(r.facilities_with_coherent_rows),f"{r.coherent_rows}/{r.observed_rows}"] for r in yes.itertuples()]
    tables.append(make_table("NI-A-T7","Recorded Yesavage GDS-15 applications, 2023–2025",["Year","Activity","Recorded events","Women","Men","Facilities","Coherent / observed rows"],rows,
        "Yesavage GDS-15 concerns depressive symptoms, not GDS-Reisberg global dementia deterioration. Only the unambiguous A03 application row is analysed. A27 follow-up activities were not harmonised: the official 2023 template repeats COL11 for an age field and men, and sex columns change in later years. Shared mental-health risk-result rows are not Yesavage-specific and were not used to estimate a depression-risk proportion."))
    rows=[[str(r.year),number(r.selected_source_rows),number(r.exact_duplicates_removed),number(r.conflicting_keys_quarantined),number(r.conflicting_rows_quarantined),number(r.retained_rows),number(r.A06_rows_withheld_from_primary_2021)] for r in cleaning.itertuples()]
    tables.append(make_table("NI-A-T8","Source-record cleaning for the Series A instrument analyses",["Year","Selected source rows","Exact duplicate rows removed","Conflicting keys quarantined","Conflicting rows quarantined","Retained rows","A06 primary rows withheld"],rows,
        "Scope is the 15 codes used in this analysis. Exact duplicates were collapsed across all source fields; every remaining conflicting key was quarantined rather than arbitrarily selecting a version. Keys contain year, month, health service, facility and code. Blank and explicit-zero mapped cells remain distinct. Subsequent complete-case restrictions are additional and instrument-specific. No source file was changed."))
    a25=annual.loc[annual.year.eq(2025)&annual.code.eq('06906135')].iloc[0]
    g=changes.loc[changes.year.eq(2025)&changes.code.eq('06906135')&changes.sex.eq('Women')&changes.direction.eq('Increase')].iloc[0]
    zm=zarit.loc[zarit.year.eq(2025)&zarit.sex.eq('Men')&zarit.direction.eq('Intense burden')].iloc[0]
    zw=zarit.loc[zarit.year.eq(2025)&zarit.sex.eq('Women')&zarit.direction.eq('Intense burden')].iloc[0]
    y25=yes.loc[yes.year.eq(2025)&yes.code.eq('09600226')].iloc[0]
    female_function=[]
    for measure in TOOLS:
        r=funcs.loc[funcs.year.eq(2025)&funcs.measure.eq(measure)&funcs.sex.eq('Women')&funcs.direction.eq('Improved')].iloc[0]
        s=fsel.loc[fsel.year.eq(2025)&fsel.measure.eq(measure)].iloc[0]
        female_function.append(f"{measure}: {number(r.recorded_evaluations)}/{number(r.denominator)} ({r.percent:.1f}%), retaining {number(s.eligible_facility_month_sets)}/{number(s.candidate_facility_month_sets)} observed sets ({s.eligible_set_percent:.1f}%)")
    methods=[{"title":"REM instruments, units of analysis and source quality", "paragraphs":[
        "We extended the descriptive administrative analysis using annually audited REM Series A coded templates and source CSV files for 2019–2025. GDS-Reisberg global-deterioration reevaluation, dementia caregiver burden reevaluation and caregiver satisfaction were taken from the A06 dementia programme evaluation block using stable codes and annually checked layouts. Zarit abbreviated caregiver burden, programme TUG/functionality change and hospital Barthel change came from A03. Yesavage GDS-15 activity was analysed separately for 2023–2025. These sources contain aggregate recording counts, not individual scores, uniquely identified patients or observed patient trajectories. Caregiver sex is distinct from patient sex.",
        "Exact duplicate source rows were collapsed. After this step, all records at a conflicting year–month–health-service–facility–code key were quarantined. Blank cells and absent category rows were preserved as missing; explicit numeric zero was retained. A January 2021 source cluster repeated exceptionally large identical vectors in all three A06 measures. Because its cause remains unresolved, the entire 2021 year was withheld from their primary series. An all-record versus outside-cluster comparison was retained only as a diagnostic sensitivity analysis."]},
        {"title":"Complete-case category denominators and interpretation", "paragraphs":[
        "A06 change-category proportions required nine numeric, non-negative integer fields, reconciliation of total with men plus women, and reconciliation of each sex total with its increased, maintained and decreased categories. For Zarit, both intense and non-intense burden rows had to be present in the same facility-month, with coherent numeric total/sex fields. For TUG, the functionality questionnaire and hospital Barthel, all three change-category rows had to be present and coherent within each instrument's own facility-month set. Proportions were calculated by dividing summed category recordings by summed eligible category recordings. We reported the eligible/observed sets and exclusions rather than substituting zero for missing rows.",
        "TUG and the functionality questionnaire describe the programme discharge setting (age 60+), whereas hospital Barthel refers to admission-to-discharge change (age 65+). Zarit concerns caregivers of people with severe dependency and is not dementia-specific. Increasing deterioration, increasing burden and increasing satisfaction represent different constructs; the categories were not pooled into a common favourable-response estimate. Yesavage context was restricted to A03 application counts. A27 follow-up activity was not harmonised because the official 2023 template repeats COL11 for both an age field and men, with different sex columns in subsequent years. Shared mental-health risk-result rows were not treated as Yesavage-specific. No causal benefit, treatment effect, population prevalence or clinical diagnostic accuracy was estimated."]}]
    results=[{"title":"Dementia programme evaluations: recorded activity and selected change categories", "paragraphs":[
        f"In 2025, the GDS-Reisberg source contained {number(a25.primary_events)} recorded reevaluations ({number(a25.primary_women)} in women and {number(a25.primary_men)} in men) from {number(a25.facilities_with_rows)} facilities. All nine mapped cells were complete and coherent in {number(a25.complete9_rows)} of {number(a25.observed_rows)} observed facility-month rows. In the eligible female subset, increased global deterioration represented {number(g.recorded_evaluations)}/{number(g.denominator)} recordings ({g.percent:.1f}%). The complete-case denominator is narrower than all reported activity and should not be interpreted as all women with dementia in Chile.",
        "The 2021 raw A06 spike was dominated by 12 original rows from four facilities in January. The cluster contributed 107,160 to each of the three distinct measures, with identical nine-cell vectors and equal thirds in the change categories. Arithmetic equations for all three measures can be satisfied by this pattern; source reconciliation alone therefore did not establish plausibility. The unresolved year appears as a gap in primary trends, while its raw-versus-outside-cluster counts remain explicitly diagnostic."], "table_ids":["NI-A-T1","NI-A-T2","NI-A-T3","NI-A-T8"],"figure_ids":["NI-A-F1","NI-A-F2"]},
        {"title":"Caregiver burden and functional change in their own reporting settings", "paragraphs":[
        f"Within 2025 paired-category Zarit records, intense caregiver burden was {number(zw.recorded_evaluations)}/{number(zw.denominator)} ({zw.percent:.1f}%) among female caregiver recordings and {number(zm.recorded_evaluations)}/{number(zm.denominator)} ({zm.percent:.1f}%) among male caregiver recordings. These proportions describe selected evaluations of caregivers of people with severe dependency. They do not identify a dementia-only caregiver cohort, unique caregivers or population prevalence.",
        "The 2025 improved-category results among female recordings in each separate setting were " + "; ".join(female_function) + ". These selected denominators, especially the small complete-set fraction for programme TUG, limit generalisation. The instrument, programme/hospital setting, age scope and changing reporting sample prevent pooling or causal comparison across tools."],"table_ids":["NI-A-T4","NI-A-T5","NI-A-T6"],"figure_ids":["NI-A-F3"]},
        {"title":"Depression-screening activity as contextual evidence", "paragraphs":[
        f"The 2025 Yesavage GDS-15 application row contained {number(y25.recorded_events)} coherent activity recordings ({number(y25.women)} in women and {number(y25.men)} in men). These are screening-activity counts; shared mental-health risk rows cannot establish Yesavage-specific positivity, and A27 follow-up fields were not harmonised. This depression-screening context remains conceptually separate from GDS-Reisberg dementia deterioration."],"table_ids":["NI-A-T7"],"figure_ids":["NI-A-F3"]}]
    bundle={"title":"REM neurodegeneration-related instruments: descriptive administrative analyses", "language":"English", "scope":"Series A 2019–2025; unresolved 2021 A06 source anomaly withheld from primary results", "methods":methods,"results":results,"tables":tables,"figures":[],"provenance":{"selected_sources":sources,"analysis_script":rel(Path(__file__)),"unit":"Repeated administrative recording events; not unique individuals", "uncertainty":"No sampling confidence intervals: descriptive counts in selected administrative reporting sets"}}
    (OUT/'analysis_bundle.json').write_text(json.dumps(bundle,ensure_ascii=False,indent=2,allow_nan=False))
    return bundle


def run(refresh_raw=False):
    for folder in ['source_data','tables','figures']:(OUT/folder).mkdir(parents=True,exist_ok=True)
    if refresh_raw:
        frame,cleaning,sources=load_clean()
        annual,changes=a06_analysis(frame)
        zarit,zsel=categorical_sets(frame,'Zarit abbreviated',ZARIT,['Intense burden','No intense burden'])
        fp=[];sp=[]
        for name,codes in TOOLS.items():
            f,s=categorical_sets(frame,name,codes,['Improved','Maintained','Declined']);fp.append(f);sp.append(s)
        funcs=pd.concat(fp,ignore_index=True);fsel=pd.concat(sp,ignore_index=True)
        yes=yesavage_analysis(frame)
        for f,name in [(annual,'a06_annual.csv'),(changes,'a06_change_categories.csv'),(zarit,'zarit_categories.csv'),(zsel,'zarit_selection.csv'),(funcs,'functional_change_categories.csv'),(fsel,'functional_selection.csv'),(yes,'yesavage_context.csv'),(cleaning,'cleaning_audit.csv')]:save_data(f,name)
        anomaly=pd.read_csv(ROOT/'outputs/rem_neuro_instruments_2026-10-30/cognitive_field_search/anomaly_a06_2021_diagnostic_contrast.csv',dtype={'code':str})
        save_data(anomaly,'a06_2021_diagnostic_contrast.csv')
        (OUT/'source_data/provenance.json').write_text(json.dumps(sources,indent=2))
    else:
        def read(name):return pd.read_csv(OUT/'source_data'/name,dtype={'code':str})
        annual,changes=read('a06_annual.csv'),read('a06_change_categories.csv')
        zarit,zsel=read('zarit_categories.csv'),read('zarit_selection.csv')
        funcs,fsel=read('functional_change_categories.csv'),read('functional_selection.csv')
        yes,cleaning=read('yesavage_context.csv'),read('cleaning_audit.csv')
        sources=json.loads((OUT/'source_data/provenance.json').read_text())
    bundle=write_bundle(annual,changes,zarit,zsel,funcs,fsel,yes,cleaning,sources)
    validation={"status":"PASS", "checks":{"year_2021_A06_primary_values_all_missing":bool(annual.loc[annual.year.eq(2021),['primary_events','primary_men','primary_women','primary_facilities']].isna().all().all()),
        "year_2021_not_in_A06_change_estimates":bool(not changes.year.eq(2021).any()),
        "all_category_percentages_sum_100_when_denominator_positive":bool(all(np.allclose(f.loc[f.denominator.gt(0)].groupby(['year','measure','sex']).percent.sum(),100) for f in [changes,zarit,funcs])),
        "all_change_recordings_reconcile_denominator":bool(all((f.groupby(['year','measure','sex']).recorded_evaluations.sum().values==f.groupby(['year','measure','sex']).denominator.first().values).all() for f in [changes,zarit,funcs])),
        "four_conflicting_keys_quarantined":int(cleaning.conflicting_keys_quarantined.sum())==4,
        "eight_curated_tables":len(bundle['tables'])==8},
        "software":{"pandas":pd.__version__,"numpy":np.__version__},"table_cells":sum(len(t['columns'])*len(t['rows']) for t in bundle['tables'])}
    assert all(validation['checks'].values()),validation
    (OUT/'analysis_validation.json').write_text(json.dumps(validation,indent=2))
    print(json.dumps({'tables':len(bundle['tables']),'validation':validation,'2025_zarit':zarit.loc[zarit.year.eq(2025)&zarit.direction.eq('Intense burden')].to_dict('records')},indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    mode=parser.add_mutually_exclusive_group()
    mode.add_argument('--from-aggregates',action='store_true',help='Rebuild tables and narrative from frozen aggregate inputs (default).')
    mode.add_argument('--refresh-raw',action='store_true',help='Refresh aggregates from private source-derived caches on the external disk.')
    run(refresh_raw=parser.parse_args().refresh_raw)
