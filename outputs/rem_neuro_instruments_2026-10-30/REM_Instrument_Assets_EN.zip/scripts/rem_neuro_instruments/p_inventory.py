"""Read annual coded templates and profile selected Series P source rows.

No blank-to-zero replacement is used. The lossless selected-row cache remains
on the external source volume. This is an availability audit, not prevalence.
"""
from pathlib import Path
import csv, gzip, hashlib, io, json, re, subprocess
from collections import Counter
import openpyxl
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
DATA = Path('/Volumes/Datos/Asesorias_Data')
OUT = ROOT / 'outputs/rem_neuro_instruments_2026-10-30/p_series_audit'
PRIVATE = DATA / 'derived/Reproductive-hormones-cognitive-decline-women-Chile/rem_neuro_instruments'
GROUPS = {
    'EFAM functional categories': ['P5180100','P5180200','P5300510'],
    'Barthel dependency categories': ['P5300100','P5300200','P5300520','P5300530'],
    'More Autonomous Older Adults programme functional categories': ['P5300570','P5300580','P5300590'],
    'Timed Up and Go fall risk categories': ['P5300540','P5300550','P5300560'],
    'Single-leg stance balance categories': ['P5400100','P5400200'],
    'Parkinson caseload': ['P3140200'],
    'Severe dependency homecare': ['P3160800','P3171613'],
    'Caregivers of severe dependency patients': ['P5300600'],
    'Primary care dementia stage': ['P6222300','P6230100','P6230200'],
    'Specialty dementia stage': ['P6223310','P6230400','P6230500'],
}
CODE_GROUP = {c:g for g,codes in GROUPS.items() for c in codes}
TERMS = re.compile(r'EFAM|Barthel|Pfeffer|Folstein|MMSE|MoCA|Reisberg|Yesavage|Zarit|TUG|Timed.?up|unipodal|UPDRS|Hoehn|PDQ|mini.?mental|Montreal', re.I)

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()

def clean(value):
    return ' '.join(str(value).split())

def run():
    OUT.mkdir(parents=True, exist_ok=True)
    PRIVATE.mkdir(parents=True, exist_ok=True)
    inventory=[]; proof=[]; mentions=[]; source_files=[]; profiles=[]; cell_profiles=[]
    for year in range(2019,2026):
        path=next(p for p in (DATA/f'REM/SerieP/diccionarios/{year}').glob('*') if p.suffix in ['.xlsm','.xlsx'])
        source_files.append({'year':year,'type':'coded_template','source':str(path.relative_to(DATA)),'sha256':sha(path),'bytes':path.stat().st_size})
        book=openpyxl.load_workbook(path,read_only=True,data_only=True)
        mapped={}
        for sn in book.sheetnames:
            ws=book[sn]; rows=list(ws.iter_rows())
            section=''
            for i,row in enumerate(rows):
                vals=[c.value for c in row]
                texts=[clean(v) for v in vals if isinstance(v,str)]
                section_text=next((v for v in texts[:4] if re.search(r'^SECCI[OÓ]N',v,re.I)),None)
                if section_text: section=section_text
                short=' | '.join(clean(v) for v in vals[:3] if v is not None)
                if TERMS.search(short):
                    mentions.append({'year':year,'sheet':sn,'row':i+1,'code':str(vals[0] or ''),'text':short,'section':section,'coded_row':any(isinstance(v,str) and re.fullmatch(r'COL\d{2}',v) for v in vals)})
                code=str(vals[0] or '').strip()
                if code not in CODE_GROUP: continue
                col_cells=[{'cell':c.coordinate,'column':c.value,'locked':c.protection.locked} for c in row if isinstance(c.value,str) and re.fullmatch(r'COL\d{2}',c.value)]
                if not col_cells: continue
                mapped[code]=[x['column'].title() for x in col_cells]
                preceding=[]
                for k in range(max(0,i-7),i):
                    if any(isinstance(c.value,str) and re.fullmatch(r'COL\d{2}',c.value) for c in rows[k]):continue
                    cells=[{'cell':c.coordinate,'value':clean(c.value)} for c in rows[k][:55] if c.value is not None]
                    if cells:preceding.append(cells)
                proof.append({'year':year,'sheet':sn,'row':i+1,'code':code,'group':CODE_GROUP[code],'section':section,'label':short,'columns':col_cells,'preceding_headers':preceding})
                inventory.append({'year':year,'sheet':sn,'row':i+1,'code':code,'group':CODE_GROUP[code],'section':section,'source_label':short,'coded_columns':';'.join(mapped[code]),'source_template':path.name})
        book.close()
        source=DATA/f'REM/SerieP/SerieP_{year}.csv'
        with source.open(encoding='latin1') as f: header=f.readline().strip().split(';')
        assert header[:7]==['Mes','IdServicio','Ano','IdEstablecimiento','CodigoPrestacion','IdRegion','IdComuna']
        pattern=r'^(?:[^;]*;){4}(?:'+'|'.join(CODE_GROUP)+');'
        scan=subprocess.run(['rg','--text','--no-heading','--no-filename','--no-line-number',pattern,str(source)],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        assert scan.returncode in [0,1],scan.stderr
        selected=PRIVATE/f'p_instrument_selected_{year}.csv.gz'
        with gzip.open(selected,'wb') as f: f.write((';'.join(header)+'\n').encode('latin1')+scan.stdout)
        frame=pd.read_csv(io.BytesIO(scan.stdout),sep=';',names=header,header=None,dtype=str,keep_default_na=False,encoding='latin1')
        stat=source.stat()
        source_files.append({'year':year,'type':'annual_data','source':str(source.relative_to(DATA)),'bytes':stat.st_size,'mtime_ns':stat.st_mtime_ns,'selected_rows':len(frame),'cache':str(selected.relative_to(DATA)),'selected_cache_sha256':sha(selected)})
        for code,group in CODE_GROUP.items():
            subset=frame[frame.CodigoPrestacion.eq(code)]
            december=subset[subset.Mes.eq('12')]
            cols=mapped.get(code,[])
            key=['Mes','IdServicio','Ano','IdEstablecimiento','CodigoPrestacion']
            item={'year':year,'code':code,'group':group,'template_coded_row_present':code in mapped,'source_rows':len(subset),'months_observed':';'.join(sorted(subset.Mes.unique(),key=lambda s:int(s))), 'december_source_rows':len(december),'december_distinct_facilities':december.IdEstablecimiento.nunique(),'duplicate_key_rows_all_months':int(subset.duplicated(key,keep=False).sum()),'duplicate_full_rows_all_months':int(subset.duplicated(keep=False).sum()),'december_exact_extra_rows':int(len(december)-len(december.drop_duplicates())),'rows_with_unexpected_year':int(subset.Ano.ne(str(year)).sum())}
            for col in ['Col01','Col02','Col03']:
                raw=december[col]; val=pd.to_numeric(raw,errors='coerce')
                item[col+'_december_positive_rows']=int(val.gt(0).sum())
                item[col+'_december_zero_rows']=int(val.eq(0).sum())
                item[col+'_december_blank_rows']=int(raw.eq('').sum())
                item[col+'_december_negative_rows']=int(val.lt(0).sum())
                item[col+'_december_numeric_sum']=float(val.sum()) if val.notna().any() else None
            item['sex_totals_mapped_to_Col02_Col03'] = bool(cols) and not (code == 'P5300600' and year < 2023)
            if item['sex_totals_mapped_to_Col02_Col03']:
                v=december[['Col01','Col02','Col03']].apply(pd.to_numeric,errors='coerce')
                complete=v.notna().all(axis=1)
                item['december_sex_reconciliation_eligible_rows']=int(complete.sum())
                item['december_total_not_equal_to_men_plus_women']=int((complete & v.Col01.ne(v.Col02+v.Col03)).sum())
            profiles.append(item)
            for col in cols:
                raw=december[col];val=pd.to_numeric(raw,errors='coerce')
                cell_profiles.append({'year':year,'code':code,'column':col,'december_rows':len(december),'positive_cells':int(val.gt(0).sum()),'explicit_zero_cells':int(val.eq(0).sum()),'blank_cells':int(raw.eq('').sum()),'negative_cells':int(val.lt(0).sum()),'nonblank_nonnumeric_cells':int((raw.ne('')&val.isna()).sum())})
        print(year, 'rows', len(frame), 'codes', frame.CodigoPrestacion.nunique(), 'December',frame.Mes.eq('12').sum(),flush=True)
    for name,values in [('annual_template_inventory',inventory),('instrument_name_mentions',mentions),('annual_source_presence',profiles),('december_mapped_cell_states',cell_profiles)]:
        pd.DataFrame(values).to_csv(OUT/f'{name}.csv',index=False)
    summary_columns=['year','code','group','template_coded_row_present','source_rows','months_observed','december_source_rows','december_distinct_facilities','Col01_december_positive_rows','Col01_december_zero_rows','Col01_december_blank_rows','december_exact_extra_rows']
    pd.DataFrame(profiles)[summary_columns].to_csv(OUT/'availability_summary.csv',index=False)
    (OUT/'template_mapping_proof.json').write_text(json.dumps(proof,indent=2,ensure_ascii=False))
    (OUT/'source_manifest.json').write_text(json.dumps(source_files,indent=2))
    return profiles

if __name__=='__main__':run()
