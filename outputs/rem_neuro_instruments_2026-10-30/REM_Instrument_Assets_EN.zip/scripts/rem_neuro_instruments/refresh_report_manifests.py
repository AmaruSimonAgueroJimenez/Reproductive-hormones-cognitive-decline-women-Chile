"""Refresh delivery metadata only after proving frozen evidence is unchanged.

This does not render, recalculate scientific analyses or edit documents. Changed
data/figure files outside the explicitly reviewed new extension cause failure.
Before --write, finalise Word/HTML content and retain the historical manifests.
--include-final-package records the final instrument archive after packaging.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import zipfile
from xml.etree import ElementTree as etree

from report_render import load_instrument_bundle

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/rem_neuro_instruments_2026-10-30"
REVISION = OUT / "report_revision"
REPRODUCIBILITY = [
    "outputs/paper/revision_descriptiva_2026-10-28/reproducibility_manifest.json",
    "outputs/publication_programme_2026-10-28/reproducibility_manifest.json",
    "outputs/access_diagnostic_extension_2026-10-29/reproducibility_manifest.json",
]
DOCX_MANIFESTS = {
    "descriptive": "manuscript/revision_descriptiva_2026-10-28/docx_build_manifest.json",
    "connected": "manuscript/publication_programme_2026-10-28/connected_docx_build_manifest.json",
    "access": "manuscript/access_diagnostic_extension_2026-10-29/docx_build_manifest.json",
}
BUNDLES = {
    "outputs/paper/revision_descriptiva_2026-10-28/review_bundle.json": "71e7fad9e23d958a0103e6f8191aa7f5d28cbdf36d4c7b68514bced88adeff24",
    "outputs/paper/revision_descriptiva_2026-10-28/bank/candidate_bundle.json": "889d6a7e6ae62ae71686fe96c9219b7b863c4e1743091968ac6612ae89ff4f88",
    "outputs/publication_programme_2026-10-28/integrated_evidence.json": "beb7fa884ff66327fc99831e0a40168e0893695e1e02d112b8ce1382a10e504b",
    "outputs/access_diagnostic_extension_2026-10-29/review_bundle.json": "456834826130abb8eded31bc21b7ce997d48505d44586790cda2a7868a036f88",
    "outputs/access_diagnostic_extension_2026-10-29/access_evidence.json": "456834826130abb8eded31bc21b7ce997d48505d44586790cda2a7868a036f88",
}
ALLOWED_DELIVERY_UPDATES = {
    "_quarto.yml", "index.qmd", "index.html",
    "scripts/build_descriptive_docx.py", "scripts/build_descriptive_qmd.py",
    "scripts/run_descriptive_review.py", "scripts/run_reproductive_life_course.py",
    "scripts/run_access_diagnostic_extension.py", "scripts/stage_research_site.py",
    "scripts/access_extension/access_report.py", "scripts/access_extension/build_access_docx.py",
    "scripts/publication_programme/build_integrated_docx.py",
    "scripts/research_publication/audit_site_dependencies.py",
    "outputs/paper/revision_descriptiva_2026-10-28/document_content_validation.json",
    "outputs/paper/revision_descriptiva_2026-10-28/html_content_validation.json",
    "outputs/publication_programme_2026-10-28/word_validation.json",
    "outputs/publication_programme_2026-10-28/html_validation.json",
    "outputs/access_diagnostic_extension_2026-10-29/word_content_validation.json",
    "outputs/access_diagnostic_extension_2026-10-29/html_validation.json",
}
for name in ["descriptive_methods_results", "reproductive_life_course", "access_diagnostic_recording_extension"]:
    ALLOWED_DELIVERY_UPDATES.update(f"docs/{name}{suffix}" for suffix in [".html", ".qmd", "_source.txt"])
ALLOWED_DELIVERY_UPDATES.update(DOCX_MANIFESTS.values())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def relative(path):
    return str(Path(path).relative_to(ROOT))


def metadata_update_allowed(path):
    return (path in ALLOWED_DELIVERY_UPDATES or path.startswith("scripts/rem_neuro_instruments/")
            or path == "scripts/run_rem_instrument_extension.py"
            or path.startswith("outputs/rem_neuro_instruments_2026-10-30/report_revision/"))


def identity(path):
    return {"path": relative(path), "sha256": sha(path), "bytes": path.stat().st_size}


def run(*, write=False, include_final_package=False):
    bundle = load_instrument_bundle(ROOT)
    content_validation = json.loads((REVISION / "content_validation.json").read_text())
    assert bundle["content_sha256"] == content_validation["instrument_content_sha256"]
    frozen = []
    for path, expected in BUNDLES.items():
        data = json.loads((ROOT / path).read_text())
        assert data["content_sha256"] == expected, path
        frozen.append({"path": path, "content_sha256": expected, "file_sha256": sha(ROOT / path)})
    words = {row["report"]: row for row in json.loads((REVISION / "word_extension_manifest.json").read_text())}
    validated_words = {row["path"]: row for row in content_validation["word"]}
    ALLOWED_DELIVERY_UPDATES.update(row["path"] for row in words.values())
    manifests = {path: json.loads((ROOT / path).read_text()) for path in REPRODUCIBILITY}
    original_file_rows = [row for manifest in manifests.values() for row in manifest["files"]]
    unexpected, permitted_changes, preserved = [], [], 0
    for row in original_file_rows:
        path = ROOT / row["path"]
        actual = sha(path) if path.is_file() else None
        if actual == row["sha256"]:
            preserved += 1
        elif metadata_update_allowed(row["path"]):
            permitted_changes.append({"path": row["path"], "previous_sha256": row["sha256"], "current_sha256": actual})
        else:
            unexpected.append({"path": row["path"], "expected_sha256": row["sha256"], "current_sha256": actual})
    if unexpected:
        raise AssertionError("Unapproved scientific/input changes; metadata was not refreshed: " + json.dumps(unexpected))
    original_pngs = json.loads((OUT / "publication_original_png_baseline.json").read_text())["png_hash_to_path"]
    assert len(original_pngs) == 48
    for expected, path in original_pngs.items():
        assert sha(ROOT / path) == expected, path

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    history = REVISION / "manifest_history" / stamp
    docx_plans = {}
    for report, manifest_path in DOCX_MANIFESTS.items():
        word = words[report]
        path = ROOT / word["path"]
        assert sha(path) == word["sha256"] == validated_words[word["path"]]["sha256"], word["path"]
        source = json.loads((ROOT / manifest_path).read_text())
        data = copy.deepcopy(source)
        record = data["outputs"][0] if report == "descriptive" else data
        previous_extension = record.get("instrument_extension", {})
        base_figures = record.get("original_figures_before_instrument_extension", record["figures"])
        expected_base_hash = previous_extension.get("original_word_sha256", record["sha256"])
        assert expected_base_hash == word["original_sha256"], report
        assert len(word["additional_figures"]) == len(bundle["figures"])
        with zipfile.ZipFile(path) as archive:
            tree = etree.fromstring(archive.read("word/document.xml"))
            namespaces = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
            assert len(tree.findall(".//w:tbl", namespaces)) == word["original_tables"] + len(bundle["tables"])
            assert len(tree.findall(".//w:drawing", namespaces)) == len(base_figures) + len(bundle["figures"])
        record["original_figures_before_instrument_extension"] = copy.deepcopy(base_figures)
        record["sha256"] = sha(path)
        record["figures"] = copy.deepcopy(base_figures) + copy.deepcopy(word["additional_figures"])
        record["tables"] = word["original_tables"] + len(bundle["tables"])
        record["instrument_extension"] = {
            "bundle": relative(OUT / "report_bundle.json"), "bundle_content_sha256": bundle["content_sha256"],
            "original_word_sha256": word["original_sha256"], "original_word_backup": word["original_path"],
            "original_tables": word["original_tables"], "original_figures": len(base_figures),
            "additional_tables": len(bundle["tables"]), "additional_figures": len(bundle["figures"]),
            "original_media_preserved_exactly": True, "continuous_line_numbering": True,
            "content_validation": relative(REVISION / "content_validation.json"),
            "scope": "Existing original bundle identity is retained; the new instrument account has a separate evidence identity.",
        }
        if report == "descriptive":
            data["instrument_extension"] = copy.deepcopy(record["instrument_extension"])
        docx_plans[manifest_path] = data

    if write:
        for path in [*REPRODUCIBILITY, *DOCX_MANIFESTS.values()]:
            destination = history / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ROOT / path, destination)
        for path, data in docx_plans.items():
            (ROOT / path).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")

    # Explicit new evidence and analysis paths; never walk raw-source directories
    # or include manuscript page PNGs, private caches or arbitrary QA histories.
    additions = {OUT / "report_bundle.json", OUT / "SCIENTIFIC_ENVIRONMENT_EN.json",
                 OUT / "requirements-scientific.txt", OUT / "INSTRUMENT_REBUILD_EN.txt",
                 ROOT / "scripts/run_rem_instrument_extension.py"}
    additions.update(ROOT / row["path"] for row in bundle["file_hashes"])
    additions.update((ROOT / "scripts/rem_neuro_instruments").glob("*.py"))
    for component in ["analysis_a", "analysis_p"]:
        additions.update((OUT / component).glob("*.csv"))
        additions.update((OUT / component / "source_data").glob("*.csv"))
        additions.update((OUT / component / "tables").glob("*.csv"))
        additions.add(OUT / component / "analysis_bundle.json")
    additions.update(REVISION / name for name in ["content_validation.json", "word_extension_manifest.json", "html_content_validation.json", "restored_original_scientific_vectors.json"])
    if include_final_package:
        additions.add(OUT / "REM_Instrument_Assets_EN.zip")
    additions = {path for path in additions if path.is_file()}
    reports = []
    for manifest_path, data in manifests.items():
        previous_sha = sha(ROOT / manifest_path)
        changed = []
        for row in data["files"]:
            path = ROOT / row["path"]
            actual = sha(path)
            if actual != row["sha256"]:
                changed.append({"path": row["path"], "previous_sha256": row["sha256"], "current_sha256": actual})
                row["sha256"] = actual
                row["bytes"] = path.stat().st_size
        existing = {row["path"] for row in data["files"]}
        added = [identity(path) for path in sorted(additions) if relative(path) not in existing]
        data["files"] += added
        data["files"].sort(key=lambda row: row["path"])
        extension = {"revision_date": "2026-10-30", "bundle": relative(OUT / "report_bundle.json"),
                     "content_sha256": bundle["content_sha256"], "additional_tables_per_report": len(bundle["tables"]),
                     "additional_figures_per_report": len(bundle["figures"]), "original_bundles_unchanged": frozen,
                     "prior_48_original_pngs_unchanged": True, "source_record_refresh_performed_by_this_step": False}
        data["instrument_extension"] = extension
        if changed or added:
            data.setdefault("instrument_extension_history", []).append({
                "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
                "purpose": "Record the authorised REM instrument report additions and current delivery artifacts without changing frozen original analyses.",
                "previous_manifest_sha256": previous_sha, "backup": relative(history / manifest_path) if write else None,
                "changed_records": changed, "added_records": [row["path"] for row in added],
                "unchanged_scientific_inputs_verified_before_refresh": True})
        if write:
            (ROOT / manifest_path).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
        reports.append({"path": manifest_path, "changed_records": changed, "added_records": len(added),
                        "total_records": len(data["files"]), "original_analysis_identity_preserved": True})
    receipt = {"status": "PASS", "write": write, "instrument_content_sha256": bundle["content_sha256"],
               "original_record_checks": len(original_file_rows), "original_records_already_matching": preserved,
               "original_frozen_bundle_ids": frozen, "unapproved_scientific_changes": [],
               "docx_manifests": [{"path": path, "figures": len((data["outputs"][0] if "outputs" in data else data)["figures"]),
                                    "tables": (data["outputs"][0] if "outputs" in data else data)["tables"]} for path, data in docx_plans.items()],
               "reproducibility_manifests": reports,
               "final_instrument_package_recorded": include_final_package,
               "metadata_backup_root": relative(history) if write else None}
    if write:
        (REVISION / "manifest_refresh_validation.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))
    return receipt


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true")
    parser.add_argument("--include-final-package", action="store_true")
    args = parser.parse_args()
    run(write=args.write, include_final_package=args.include_final_package)
