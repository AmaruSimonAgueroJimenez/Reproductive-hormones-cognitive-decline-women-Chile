"""Source-state-preserving analysis of REM P5 functional and mobility categories.

This module performs a new selected-provider descriptive analysis. It does not
change the original REM analyses and never turns an absent or blank value into 0.
"""
from pathlib import Path
import argparse, hashlib, json, platform, shutil, sys
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'outputs/rem_neuro_instruments_2026-10-30'
OUT=BASE/'analysis_p'
PRIVATE=Path('/Volumes/Datos/Asesorias_Data/derived/Reproductive-hormones-cognitive-decline-women-Chile/rem_neuro_instruments')
YEARS=list(range(2019,2026))
SEXES=['Women','Men']
CATEGORIES={
 'functional': [('P5180100','Autonomous without risk'),('P5180200','Autonomous with risk'),('P5300510','Dependency risk'),('P5300100','Mild dependency'),('P5300200','Moderate dependency'),('P5300520','Severe dependency'),('P5300530','Total dependency')],
 'tug':[('P5300540','Normal'),('P5300550','Mild fall risk'),('P5300560','High fall risk')],
 'balance':[('P5400100','Normal'),('P5400200','Altered')],
}
LABELS={'functional':'Functional classification','tug':'Timed Up and Go','balance':'Single-leg stance'}
FOCUS={'functional':['Dependency risk','Mild dependency','Moderate dependency','Severe dependency','Total dependency'],'tug':['Mild fall risk','High fall risk'],'balance':['Altered']}
FOCUS_LABELS={'functional':'Dependency risk or dependency','tug':'Mild or high fall risk','balance':'Altered balance'}
AGE_BANDS=['65–69','70–74','75–79','80+']
REGIONS={15:'Arica y Parinacota',1:'Tarapacá',2:'Antofagasta',3:'Atacama',4:'Coquimbo',5:'Valparaíso',13:'Metropolitana',6:"O’Higgins",7:'Maule',16:'Ñuble',8:'Biobío',9:'La Araucanía',14:'Los Ríos',10:'Los Lagos',11:'Aysén',12:'Magallanes'}

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()

def save(d,name):
 p=OUT/name;d.to_csv(p,index=False);return str(p.relative_to(ROOT))

def count_states(a):
 n=pd.to_numeric(a,errors='coerce')
 return {'blank':int(a.eq('').sum()),'zero':int(n.eq(0).sum()),'positive':int(n.gt(0).sum()),'negative':int(n.lt(0).sum()),'invalid':int((a.ne('')&n.isna()).sum())}

def load_clean():
 codes=[c for v in CATEGORIES.values() for c,_ in v]
 rows=[];qc=[];quarantine=[];private_manifest=[]
 for y in YEARS:
  p=PRIVATE/f'p_instrument_selected_{y}.csv.gz'
  d=pd.read_csv(p,sep=';',dtype=str,keep_default_na=False)
  d=d[d.Mes.eq('12')&d.CodigoPrestacion.isin(codes)].copy()
  raw_n=len(d);d=d.drop_duplicates().copy();extra=raw_n-len(d)
  # One reporting establishment/code/snapshot is the intended unit. A second
  # service record with different values is quarantined, not silently summed.
  key=['IdEstablecimiento','CodigoPrestacion']
  conflict=d.duplicated(key,keep=False)
  nconf=int(conflict.sum())
  if nconf:quarantine.extend(d.loc[conflict,['IdEstablecimiento','CodigoPrestacion']].assign(year=y,reason='Conflicting establishment-code snapshot').to_dict('records'))
  d=d[~conflict].copy()
  raw=d[['Col01','Col02','Col03']]
  n=raw.apply(pd.to_numeric,errors='coerce')
  nonnumeric=(raw.ne('')&n.isna()).any(axis=1)
  negative=n.lt(0).any(axis=1)
  noninteger=((n.notna())&n.mod(1).ne(0)).any(axis=1)
  sex_bad=n.notna().all(axis=1)&n.Col01.ne(n.Col02+n.Col03)
  invalid=nonnumeric|negative|noninteger|sex_bad
  for idx in d.index[invalid]:
   reason='Sex-total inconsistency' if sex_bad.loc[idx] else 'Invalid numeric count'
   quarantine.append({'year':y,'IdEstablecimiento':d.loc[idx,'IdEstablecimiento'],'CodigoPrestacion':d.loc[idx,'CodigoPrestacion'],'reason':reason})
  info={'year':y,'raw_december_rows':raw_n,'exact_extra_rows_removed':extra,'conflicting_snapshot_rows_quarantined':nconf,'sex_total_error_rows_quarantined':int(sex_bad.sum()),'invalid_count_rows_quarantined':int((nonnumeric|negative|noninteger).sum()),'blank_sex_total_cells':int(raw.eq('').sum().sum()),'retained_rows':int((~invalid).sum())}
  qc.append(info)
  d=d[~invalid].copy()
  for col in [f'Col{i:02d}' for i in range(1,51)]:d[col]=pd.to_numeric(d[col].where(d[col].ne('')),errors='coerce')
  d['year']=y;d['estab']=pd.to_numeric(d.IdEstablecimiento,errors='coerce').astype('Int64');d['region']=pd.to_numeric(d.IdRegion,errors='coerce').astype('Int64')
  d=d.rename(columns={'CodigoPrestacion':'code'})
  assert d.estab.notna().all() and not d.duplicated(['year','estab','code']).any()
  rows.append(d)
  private_manifest.append({'year':y,'cache_filename':p.name,'sha256':sha(p),'source_rows_selected':raw_n})
 raw=pd.concat(rows,ignore_index=True)
 # Private quarantine retains original source identifiers; public outputs
 # expose only aggregated reasons and counts.
 pd.DataFrame(quarantine).to_csv(PRIVATE/'p5_quarantined_row_keys.csv',index=False)
 (OUT/'input_manifest.json').write_text(json.dumps({'inputs':private_manifest,'python':platform.python_version(),'pandas':pd.__version__,'numpy':np.__version__},indent=2))
 save(pd.DataFrame(qc),'quality_control_by_year.csv')
 return raw,pd.DataFrame(qc)

def completeness(raw):
 complete=[];flow=[];age=[];age_flow=[]
 for instrument,items in CATEGORIES.items():
  codes=[c for c,_ in items]; cat=dict(items)
  for y in YEARS:
   d=raw[(raw.year==y)&raw.code.isin(codes)].copy()
   any_ids=set(d.estab)
   present=d.groupby('estab').code.nunique();all_rows=set(present[present.eq(len(codes))].index)
   numeric=d[['Col01','Col02','Col03']].notna().all(axis=1)
   valid=d[numeric].groupby('estab').code.nunique();all_numeric=set(valid[valid.eq(len(codes))].index)
   # Whole-instrument completeness is evaluated before extracting each sex.
   good=d[d.estab.isin(all_numeric)].copy()
   regions=good.groupby('estab').region.nunique(dropna=False)
   region_conflicts=set(regions[regions.ne(1)].index)
   good=good[~good.estab.isin(region_conflicts)]
   eligible=set(good.estab)
   for sex,col in [('Women','Col03'),('Men','Col02')]:
    z=good[['year','estab','region','code',col]].rename(columns={col:'n'}).copy()
    z['instrument']=instrument;z['sex']=sex;z['category']=z.code.map(cat)
    den=z.groupby('estab').n.sum();positive=set(den[den.gt(0)].index)
    z=z[z.estab.isin(positive)];complete.append(z)
   flow.append({'year':y,'instrument':instrument,'required_categories':len(codes),'any_represented_facilities':len(any_ids),'all_category_rows_facilities':len(all_rows),'all_category_numeric_totals_facilities':len(all_numeric),'region_conflict_facilities':len(region_conflicts),'complete_facilities':len(eligible),'absent_category_facilities':len(any_ids-all_rows),'blank_total_facilities':len(all_rows-all_numeric)})
   # Harmonise older ages; no blank age cell is replaced by zero. Every
   # age/sex component must be numeric, nonnegative and reconcile to sex total.
   bands=['65–69','70–74','75–79','80+'] if y<2023 else ['65–69','70–74','75–79','80–84','85–89','90–94','95–99','100+']
   colmap={sex:[f'Col{i:02d}' for i in range(start,4+2*len(bands),2)] for sex,start in [('Men',4),('Women',5)]}
   age_cols=colmap['Men']+colmap['Women']
   num=good[age_cols]
   present_age=num.notna().all(axis=1)
   age_bad=(num.lt(0)|(num.notna()&num.mod(1).ne(0))).any(axis=1)
   reconciles=pd.Series(True,index=good.index)
   for sex,cols in colmap.items():
    sex_col='Col03' if sex=='Women' else 'Col02'
    reconciles &= num[cols].sum(axis=1,min_count=len(cols)).eq(good[sex_col])
   age_ok=present_age&~age_bad&reconciles
   count=good[age_ok].groupby('estab').code.nunique();age_ids=set(count[count.eq(len(codes))].index)
   age_flow.append({'year':y,'instrument':instrument,'complete_total_facilities':len(eligible),'complete_age_reconciled_facilities':len(age_ids),'rows_blank_age_component':int((~present_age).sum()),'rows_complete_age_sum_disagrees':int((present_age&~reconciles).sum()),'rows_invalid_age_component':int(age_bad.sum())})
   for sex,cols in colmap.items():
    gg=good[good.estab.isin(age_ids)]
    for band in AGE_BANDS:
     target=[c for b,c in zip(bands,cols) if b==band or (band=='80+' and b not in AGE_BANDS[:3])]
     z=gg[['year','estab','region','code']].copy();z['n']=gg[target].sum(axis=1,min_count=len(target))
     z['instrument']=instrument;z['sex']=sex;z['age']=band;z['category']=z.code.map(cat)
     den=z.groupby('estab').n.sum();positive=set(den[den.gt(0)].index)
     age.append(z[z.estab.isin(positive)])
 long=pd.concat(complete,ignore_index=True);ages=pd.concat(age,ignore_index=True)
 for z in [long,ages]:
  z['n']=z.n.astype('int64');z['region']=z.region.astype(int);z['estab']=z.estab.astype(int)
 save(pd.DataFrame(flow),'instrument_completeness_by_year.csv');save(pd.DataFrame(age_flow),'age_completeness_by_year.csv')
 long.to_csv(PRIVATE/'p5_complete_facility_category_counts.csv.gz',index=False)
 ages.to_csv(PRIVATE/'p5_harmonised_facility_age_category_counts.csv.gz',index=False)
 return long,ages,pd.DataFrame(flow),pd.DataFrame(age_flow)

def composition(long,keys):
 # The same selected providers contribute every category within each stratum.
 z=long.groupby(keys+['category'],dropna=False).agg(n=('n','sum'),facilities=('estab','nunique')).reset_index()
 denom=z.groupby(keys).n.transform('sum');z['classified_n']=denom;z['percent']=100*z.n/denom
 return z

def metrics(long,keys):
 z=long.copy();z['focus_n']=np.where([c in FOCUS[i] for i,c in zip(z.instrument,z.category)],z.n,0)
 out=z.groupby(keys,dropna=False).agg(numerator=('focus_n','sum'),denominator=('n','sum'),facilities=('estab','nunique')).reset_index()
 out['percent']=100*out.numerator/out.denominator
 out['measure']=out.instrument.map(FOCUS_LABELS)
 return out

def num(v):return f'{int(v):,}'
def pct(v):return f'{float(v):.2f}'
def table(id,title,d,cols,source,note):
 source_original=source
 source=save(pd.DataFrame(d.to_numpy(),columns=cols),f'{id}_table.csv')
 return {'id':id,'title':title,'underlying_source_csv':source_original,'columns':cols,'rows':[[None if pd.isna(v) else (v.item() if hasattr(v,'item') else v) for v in row] for row in d.itertuples(index=False,name=None)],'note':note,'source_csv':source}

def standardisation(ages):
 z=ages[ages.year.eq(2025)].copy()
 ra=metrics(z,['year','instrument','sex','region','age'])
 weights=z.groupby(['instrument','age']).n.sum().rename('classified_n').reset_index()
 weights['weight']=weights.classified_n/weights.groupby('instrument').classified_n.transform('sum')
 ra=ra.merge(weights[['instrument','age','weight']],on=['instrument','age'],validate='many_to_one')
 ra['weighted_share']=ra.weight*ra.percent
 std=ra.groupby(['year','instrument','sex','region']).agg(standardised_percent=('weighted_share','sum'),age_bands=('age','nunique'),numerator=('numerator','sum'),denominator=('denominator','sum')).reset_index()
 std.loc[std.age_bands.ne(4),'standardised_percent']=np.nan
 std['crude_percent']=100*std.numerator/std.denominator
 fs=z.groupby(['year','instrument','sex','region']).estab.nunique().rename('facilities').reset_index()
 std=std.merge(fs,on=['year','instrument','sex','region'],validate='one_to_one');std['region_name']=std.region.map(REGIONS)
 save(weights,'2025_standard_age_weights.csv');save(ra,'2025_region_age_standardisation_components.csv');save(std,'2025_region_standardised_shares.csv')
 return weights,ra,std

def prepare_boundaries():
 import geopandas as gpd
 from shapely.geometry import box
 src=ROOT.parent/'Autism-spectrum-disorder-Chile/data/Regional.shp'
 d=gpd.read_file(src).to_crs(4326)
 d=d[d.codregion.isin(REGIONS)].copy()
 invalid=int((~d.geometry.is_valid).sum())
 d.geometry=d.geometry.make_valid()
 d.geometry=d.geometry.intersection(box(-76,-56.5,-66,-17));d=d[~d.geometry.is_empty]
 d=d[['codregion','Region','geometry']].to_crs(32719)
 d.geometry=d.geometry.simplify(300,preserve_topology=True)
 dest=OUT/'source_data/chile_regions_mainland_utm19s.geojson'
 dest.parent.mkdir(exist_ok=True)
 d.to_file(dest,driver='GeoJSON')
 manifest={'source':'BCN Mapoteca regional boundaries, project Regional.shp','source_shapefile_sha256':sha(src),'invalid_source_geometries_repaired':invalid,'geometry_repair':'GEOS make_valid before clipping; no statistical counts changed','crs':'EPSG:32719 WGS84 / UTM zone 19S','clip_wgs84':[-76,-56.5,-66,-17],'simplification_metres':300,'oceanic_and_antarctic_territories':'omitted','retained_region_codes':sorted(d.codregion.astype(int).tolist()),'derived_geojson_sha256':sha(dest)}
 (OUT/'source_data/geographic_provenance.json').write_text(json.dumps(manifest,indent=2))

def run():
 OUT.mkdir(parents=True,exist_ok=True);(OUT/'figures').mkdir(exist_ok=True)
 raw,qc=load_clean();long,ages,flow,age_flow=completeness(raw)
 annual=composition(long,['year','instrument','sex'])
 annual_metrics=metrics(long,['year','instrument','sex'])
 balanced=[];balanced_ids={}
 for instrument in CATEGORIES:
  sets=[set(long[(long.instrument==instrument)&(long.year==y)].estab) for y in YEARS]
  ids=set.intersection(*sets);balanced_ids[instrument]=sorted(ids)
  balanced.append(long[(long.instrument==instrument)&long.estab.isin(ids)].copy())
 balanced=pd.concat(balanced,ignore_index=True)
 bm=metrics(balanced,['year','instrument','sex']);bm['sample']='Balanced providers, 2019–2025'
 am=annual_metrics.copy();am['sample']='Annual complete providers'
 comparisons=pd.concat([am,bm],ignore_index=True)
 latest=annual_metrics[annual_metrics.year.eq(2025)].copy()
 agecomp=composition(ages[ages.year.eq(2025)],['year','instrument','sex','age'])
 agemetric=metrics(ages[ages.year.eq(2025)],['year','instrument','sex','age'])
 region=metrics(long[long.year.eq(2025)],['year','instrument','sex','region'])
 region['region_name']=region.region.map(REGIONS)
 weights,region_age,std=standardisation(ages)
 # Establishment coordinates come from the same frozen public catalogue used
 # by the project. Source administrative region is retained for aggregation.
 ctx=pd.read_csv(ROOT/'outputs/multifuente/tables/centers_context.csv')
 assert not ctx.estab.duplicated().any()
 facility=metrics(long[long.year.eq(2025)],['year','instrument','sex','estab','region'])
 facility=facility.merge(ctx[['estab','lat','lon','comuna','type_group']],on='estab',how='left',validate='many_to_one')
 facility['mapped']=facility.lat.between(-56.5,-17)&facility.lon.between(-76,-66)
 geo_counts=facility.groupby(['instrument','sex']).agg(selected_facilities=('estab','nunique'),mapped_facilities=('mapped','sum')).reset_index()
 save(annual,'annual_category_composition.csv');save(annual_metrics,'annual_focus_metrics.csv');save(comparisons,'annual_balanced_comparison.csv');save(agecomp,'2025_age_category_composition.csv');save(agemetric,'2025_age_focus_metrics.csv');save(region,'2025_region_focus_metrics.csv');facility.to_csv(PRIVATE/'p5_2025_facility_focus_maps.csv',index=False);save(geo_counts,'2025_map_inclusion.csv')
 # Independent aggregate reconciliations: partitions, denominator identity,
 # age collapse, region aggregation and fixed balanced-provider membership.
 assertions={}
 assertions['category_percent_sum_100']=bool(annual.groupby(['year','instrument','sex']).percent.sum().sub(100).abs().lt(1e-8).all())
 assertions['age_category_percent_sum_100']=bool(agecomp.groupby(['year','instrument','sex','age']).percent.sum().sub(100).abs().lt(1e-8).all())
 focus_sum=long[long.apply(lambda r:r.category in FOCUS[r.instrument],axis=1)].groupby(['year','instrument','sex']).n.sum()
 met=annual_metrics.set_index(['year','instrument','sex'])
 assertions['focus_numerators_independently_reconciled']=bool(focus_sum.eq(met.numerator).all())
 regcheck=region.groupby(['instrument','sex'])[['numerator','denominator']].sum().sort_index()
 latcheck=latest.set_index(['instrument','sex'])[['numerator','denominator']].sort_index()
 assertions['regions_reconcile_to_annual_complete_sample']=bool(regcheck.equals(latcheck))
 assertions['standard_age_weights_sum_1']=bool(weights.groupby('instrument').weight.sum().sub(1).abs().lt(1e-10).all())
 assertions['every_region_sex_has_all_four_age_bands']=bool(std.age_bands.eq(4).all())
 for instrument in CATEGORIES:
  b=balanced[balanced.instrument.eq(instrument)]
  assertions[f'{instrument}_balanced_membership_constant']=bool(b.groupby('year').estab.nunique().eq(len(balanced_ids[instrument])).all())
 assert all(assertions.values()),assertions
 validation={'status':'PASS','assertions':assertions,'balanced_provider_counts':{k:len(v) for k,v in balanced_ids.items()},'quality_control':qc.to_dict('records'),'map_inclusion':geo_counts.to_dict('records'),'source_classification':'Administrative recorded classifications among selected complete reporting providers; no population prevalence or causal inference','confidence_intervals':'Not added; the selected administrative records are counted directly. Reporting, selection and measurement uncertainty are not quantified.'}
 (OUT/'validation.json').write_text(json.dumps(validation,indent=2))
 prepare_boundaries()
 for p in OUT.glob('*.csv'):
  if p.name not in ['complete_facility_category_counts.csv','harmonised_facility_age_category_counts.csv','2025_facility_focus_maps.csv'] and not p.name.startswith('NI-P-'):
   shutil.copy2(p,OUT/'source_data'/p.name)
 shutil.copy2(OUT/'validation.json',OUT/'source_data/raw_processing_validation.json')
 shutil.copy2(OUT/'input_manifest.json',OUT/'source_data/input_manifest.json')
 for name in ['complete_facility_category_counts.csv','harmonised_facility_age_category_counts.csv','2025_facility_focus_maps.csv']:
  for obsolete in [OUT/name,OUT/'source_data'/name]:
   if obsolete.exists():obsolete.unlink()
 return build_bundle(annual,annual_metrics,comparisons,latest,agecomp,agemetric,region,geo_counts,flow,age_flow,qc,validation,std)

def build_bundle(annual,annual_metrics,comparisons,latest,agecomp,agemetric,region,geo_counts,flow,age_flow,qc,validation,std):
 balanced_counts=validation['balanced_provider_counts']
 tables=[]
 f=flow.merge(age_flow[['year','instrument','complete_age_reconciled_facilities']],on=['year','instrument'])
 f=f.assign(instrument=f.instrument.map(LABELS))
 t=f[['year','instrument','any_represented_facilities','all_category_rows_facilities','complete_facilities','complete_age_reconciled_facilities']].copy()
 tables.append(table('NI-P-T1','Annual reporting and complete classification samples, December 2019–2025',t,['Year','Instrument','Any category present: facilities','All category rows: facilities','Complete numeric totals: facilities','Complete age and sex: facilities'],'outputs/rem_neuro_instruments_2026-10-30/analysis_p/instrument_completeness_by_year.csv','Each instrument has a separate denominator. Completeness requires every category row and nonblank, nonnegative, integer counts, with total equal to men plus women. Blank and absent source fields remain unobserved. Age analysis additionally requires all mapped age components and equality to sex totals. Providers can recur between years.'))
 for tid,instruments,title in [('NI-P-T2',['functional'],'Recorded functional classifications by sex, December 2019–2025'),('NI-P-T3',['tug','balance'],'Recorded fall-risk and balance classifications by sex, December 2019–2025')]:
  d=annual[annual.instrument.isin(instruments)].copy();d['Instrument']=d.instrument.map(LABELS)
  d['n']=d.n.map(num);d['classified_n']=d.classified_n.map(num);d['percent']=d.percent.map(pct)
  cols=['year','sex','category','n','classified_n','percent'] if len(instruments)==1 else ['year','Instrument','sex','category','n','classified_n','percent']
  hdr=['Year','Sex','Category','Recorded n','Classified N','Share (%)'] if len(instruments)==1 else ['Year','Instrument','Sex','Category','Recorded n','Classified N','Share (%)']
  tables.append(table(tid,title,d[cols],hdr,'outputs/rem_neuro_instruments_2026-10-30/analysis_p/annual_category_composition.csv','Shares use the sum of all categories from the same complete selected providers and sex. Functional classifications concern adults aged 65 years or older under control; mobility instruments concern their separately classified under-control populations. These are recorded category distributions, not population prevalence. Exact duplicate source rows are removed; conflicting or inconsistent rows are quarantined.'))
 d=comparisons.copy();d['Instrument']=d.instrument.map(LABELS);d['numerator']=d.numerator.map(num);d['denominator']=d.denominator.map(num);d['percent']=d.percent.map(pct)
 tables.append(table('NI-P-T4','Annual and balanced-provider sensitivity for adverse functional or mobility classifications',d[['year','Instrument','sex','sample','facilities','numerator','denominator','percent']],['Year','Instrument','Sex','Provider sample','Facilities','Adverse n','Classified N','Share (%)'],'outputs/rem_neuro_instruments_2026-10-30/analysis_p/annual_balanced_comparison.csv','Adverse classification means dependency risk or any Barthel dependency; mild/high TUG fall risk; or altered single-leg stance, respectively. Balanced samples retain providers with complete instrument totals in every December 2019–2025. Balance of providers does not imply that the same people were observed.'))
 d=agecomp.copy();d['Instrument']=d.instrument.map(LABELS);d['n']=d.n.map(num);d['classified_n']=d.classified_n.map(num);d['percent']=d.percent.map(pct)
 tables.append(table('NI-P-T5','Age-specific functional and mobility classifications in December 2025',d[['Instrument','sex','age','category','n','classified_n','percent']],['Instrument','Sex','Age (years)','Category','Recorded n','Classified N','Share (%)'],'outputs/rem_neuro_instruments_2026-10-30/analysis_p/2025_age_category_composition.csv','Only providers with all numeric age and sex components reconciling to instrument sex totals are included. Detailed 80–84 through 100+ source categories are collapsed to 80+, permitting comparison with the pre-2023 age structure. Each age/sex/instrument denominator contains the same providers across all of its categories; zero-denominator provider strata are omitted.'))
 d=std.copy();d['Instrument']=d.instrument.map(LABELS);d['numerator']=d.numerator.map(num);d['denominator']=d.denominator.map(num);d['crude_percent']=d.crude_percent.map(pct);d['standardised_percent']=d.standardised_percent.map(pct)
 tables.append(table('NI-P-T6','Regional crude and directly age-standardised adverse-classification shares, December 2025',d[['region_name','Instrument','sex','facilities','denominator','crude_percent','standardised_percent']],['Source region','Instrument','Sex','Age-complete providers','Classified N','Crude share (%)','Age-standardised share (%)'],'outputs/rem_neuro_instruments_2026-10-30/analysis_p/2025_region_standardised_shares.csv','The same age-reconciled provider sample underlies crude and standardised shares. Direct standardisation uses four common age bands (65–69, 70–74, 75–79, 80+) and instrument-specific weights from the pooled national female and male classified population in those samples. All 16 regions have positive denominators in all four age bands for both sexes. Aysén functional classifications come from one age-complete provider (18 female and 14 male classified records), and Arica y Parinacota from four. The map hatches and uses open markers for fewer than five providers as a display flag only; all values remain in the analysis. These selected under-control classification shares are not population prevalence, access measures or disease risks.'))
 d=latest.merge(geo_counts,on=['instrument','sex']);d['Instrument']=d.instrument.map(LABELS);d['numerator']=d.numerator.map(num);d['denominator']=d.denominator.map(num);d['percent']=d.percent.map(pct)
 tables.append(table('NI-P-T7','Latest complete-snapshot summary and public-catalogue coverage, December 2025',d[['Instrument','sex','facilities','mapped_facilities','measure','numerator','denominator','percent']],['Instrument','Sex','Complete providers','Mapped providers','Adverse classification','Adverse n','Classified N','Share (%)'],'outputs/rem_neuro_instruments_2026-10-30/analysis_p/annual_focus_metrics.csv','Catalogue coverage requires usable mainland coordinates; regional choropleth maps use source-region age-reconciled aggregates instead. Mapped counts can differ between sexes when an instrument denominator is zero. Classification denominators are source-defined selected under-control populations, not resident or enrolled population denominators.'))
 tables.append(table('NI-P-T8','Source exclusions and missing numeric sex-total fields for P5 analysis',qc[['year','raw_december_rows','exact_extra_rows_removed','conflicting_snapshot_rows_quarantined','sex_total_error_rows_quarantined','invalid_count_rows_quarantined','blank_sex_total_cells']],['Year','Source rows','Exact extra rows removed','Conflicting rows excluded','Sex-total errors excluded','Invalid-count rows excluded','Blank total/sex cells'],'outputs/rem_neuro_instruments_2026-10-30/analysis_p/quality_control_by_year.csv','The row universe contains the twelve functional, TUG and single-leg stance category codes only. Blank total/sex cells are counted among deduplicated, nonconflicting rows before complete-provider selection. Missing category rows and blank cells are different exclusion mechanisms. The new analysis does not alter frozen earlier project estimates.'))
 bundle={'methods':[{'title':'REM P5 functional and mobility classifications','paragraphs':['We analysed the original December REM Series P snapshots from 2019 through 2025, validating each code and column against its corresponding annual coded official workbook. The unit of analysis was the reporting establishment, classification category and December snapshot. EFAM categories (autonomous without risk, autonomous with risk and dependency risk) and four Barthel dependency categories formed a seven-category functional distribution for adults aged 65 years or older under control. Timed Up and Go (normal, mild fall risk, high fall risk) and single-leg stance (normal, altered) were analysed as separate instruments with separate classified-population denominators. These administrative category counts do not contain individual test scores or person-linked trajectories.','Exact duplicate rows were removed once. Nonidentical records for the same establishment, category and snapshot were quarantined, as were negative, noninteger or nonnumeric observed counts and complete total/sex triplets that did not satisfy total = men + women. An establishment entered an instrument-specific analysis only when every required category row had numeric total, male and female counts and a consistent source region. Blank cells, explicit zeros and absent rows were retained as distinct source states; no unobserved count was imputed as zero. The denominator for a category share was the sum of all classifications for the same instrument, establishment sample, sex and snapshot. Positive denominators were required.','Age-specific analyses additionally required all source age components to be numeric and nonnegative and to reconcile to the corresponding sex total in every instrument category. We harmonised 65–69, 70–74, 75–79 and 80+ years; the detailed 80–84 through 100+ bands introduced in 2023 were summed to 80+. The latest complete snapshot, December 2025, was examined by sex, age and source region. We report crude regional shares and, within the same stricter age-reconciled provider samples, directly age-standardised shares; neither estimates resident-population prevalence. A balanced-provider sensitivity retained establishments satisfying instrument completeness in every year from 2019 through 2025. Repeated snapshots were not summed as unique people.','For geography, we directly age-standardised regional adverse-classification shares using four common age bands and, separately for each instrument, the pooled national female and male age distribution in the 2025 age-reconciled classified sample as the common standard. Each regional sex-specific proportion was weighted by this same instrument-specific distribution. All four regional age denominators had to be positive. Region was the source administrative region of the reporting provider. Choropleth maps use project Biblioteca del Congreso Nacional de Chile Mapoteca regional boundaries, clipped to mainland Chile and projected to WGS84 / UTM zone 19S (EPSG:32719); a 250-km projected scale bar is shown. Regions with fewer than five age-complete providers are hatched and shown with open comparison markers as a display flag only; no values are suppressed. Oceanic and Antarctic territories are omitted. Standardised shares remain selected under-control recording measures rather than resident-population prevalence, clinical disease risk, travel time, unmet need or access. No sampling confidence intervals were added to these direct administrative counts; reporting, selection and measurement uncertainty remain unquantified.']}], 'results':[], 'tables':tables,'figures':[],'validation_path':str((OUT/'validation.json').relative_to(ROOT))}
 def metric(y,i,s,sample='Annual complete providers'):
  return comparisons[(comparisons.year==y)&(comparisons.instrument==i)&(comparisons.sex==s)&(comparisons['sample']==sample)].iloc[0]
 n19=flow[(flow.year==2019)&flow.instrument.eq('functional')].iloc[0]
 n25=flow[(flow.year==2025)&flow.instrument.eq('functional')].iloc[0]
 bundle['results'].append({'title':'Recorded functional classifications and completeness','paragraphs':[f'The seven-category functional sample included {num(n19.complete_facilities)} of {num(n19.any_represented_facilities)} establishments with at least one retained functional category in December 2019 and {num(n25.complete_facilities)} of {num(n25.any_represented_facilities)} in December 2025. Complete-provider selection therefore changes the population represented by these estimates. Across the twelve P5 category codes, {num(qc.exact_extra_rows_removed.sum())} exact extra source rows were removed, {num(qc.sex_total_error_rows_quarantined.sum())} sex-total errors were quarantined and {num(qc.conflicting_snapshot_rows_quarantined.sum())} nonidentical establishment-category snapshots required quarantine.',* [f'Among {s.lower()} in the annual complete-provider functional sample, dependency risk or any Barthel dependency accounted for {pct(metric(2019,"functional",s).percent)}% ({num(metric(2019,"functional",s).numerator)}/{num(metric(2019,"functional",s).denominator)}) in 2019 and {pct(metric(2025,"functional",s).percent)}% ({num(metric(2025,"functional",s).numerator)}/{num(metric(2025,"functional",s).denominator)}) in 2025. These percentages describe the classified under-control sample and cannot be interpreted as population dependency prevalence.' for s in SEXES]],'table_ids':['NI-P-T1','NI-P-T2','NI-P-T8'],'figure_ids':['NI-P-F1']})
 bundle['results'].append({'title':'Separate mobility classifications and age structure','paragraphs':[*[f'In December 2025, {s.lower()} had {pct(metric(2025,"tug",s).percent)}% mild or high TUG fall-risk classifications ({num(metric(2025,"tug",s).numerator)}/{num(metric(2025,"tug",s).denominator)}; {num(metric(2025,"tug",s).facilities)} providers) and {pct(metric(2025,"balance",s).percent)}% altered single-leg stance classifications ({num(metric(2025,"balance",s).numerator)}/{num(metric(2025,"balance",s).denominator)}; {num(metric(2025,"balance",s).facilities)} providers). The two instrument denominators are distinct.' for s in SEXES],f'The December 2025 age-reconciled samples contained '+', '.join(f'{num(age_flow[(age_flow.year==2025)&age_flow.instrument.eq(i)].complete_age_reconciled_facilities.iloc[0])} providers for {LABELS[i].lower()}' for i in CATEGORIES)+'. Age-specific distributions use these stricter samples, and older source age bands were collapsed to the common 80+ category.'],'table_ids':['NI-P-T3','NI-P-T5','NI-P-T7'],'figure_ids':['NI-P-F2']})
 bundle['results'].append({'title':'Provider selection sensitivity and regional recording','paragraphs':[f'The balanced-provider samples comprised {num(balanced_counts["functional"])} functional-classification, {num(balanced_counts["tug"])} TUG and {num(balanced_counts["balance"])} single-leg stance establishments with complete data in every December from 2019 through 2025. This sensitivity fixes provider membership but does not track the same individuals or remove selection, case-mix or measurement differences.',* [f'For {s.lower()}, dependency risk or dependency in the balanced functional sample changed from {pct(metric(2019,"functional",s,"Balanced providers, 2019–2025").percent)}% to {pct(metric(2025,"functional",s,"Balanced providers, 2019–2025").percent)}% between 2019 and 2025; the corresponding annual complete-provider shares were {pct(metric(2019,"functional",s).percent)}% and {pct(metric(2025,"functional",s).percent)}%.' for s in SEXES],'All 16 source regions had positive classified denominators in the four common age bands for both sexes and all three instruments, permitting direct age standardisation in the stricter age-reconciled samples. Regional tables compare crude and standardised shares within those same selected samples, and national choropleth maps display standardised values on common scales. Age standardisation adjusts the observed age distribution but cannot remove provider selection, differences in case mix within age bands or recording differences. These geographic results do not establish resident-population disease prevalence, delayed diagnosis or clinical access.'],'table_ids':['NI-P-T4','NI-P-T6','NI-P-T7'],'figure_ids':['NI-P-F1','NI-P-F3']})
 bundle['results'][-1]['paragraphs'].append('Sparse provider participation limits some regional comparisons: functional classifications in Aysén came from only one age-complete provider, with 18 female and 14 male classified records; Arica y Parinacota had four age-complete functional providers. We retained all 16 regional values and flagged fewer than five providers with map hatching and open comparison markers. This display flag does not quantify statistical precision or remove selection bias. Regional low/high rankings should not be interpreted as population gradients.')
 (OUT/'analysis_bundle.json').write_text(json.dumps(bundle,indent=2,ensure_ascii=False))
 print(json.dumps({'complete_2025':flow[flow.year.eq(2025)].to_dict('records'),'balanced':balanced_counts,'tables':len(tables),'bundle':str((OUT/'analysis_bundle.json').relative_to(ROOT))},indent=2))
 return bundle

def from_aggregates():
 source=OUT/'source_data'
 names={'annual':'annual_category_composition.csv','annual_metrics':'annual_focus_metrics.csv','comparisons':'annual_balanced_comparison.csv','agecomp':'2025_age_category_composition.csv','agemetric':'2025_age_focus_metrics.csv','region':'2025_region_focus_metrics.csv','geo_counts':'2025_map_inclusion.csv','flow':'instrument_completeness_by_year.csv','age_flow':'age_completeness_by_year.csv','qc':'quality_control_by_year.csv','std':'2025_region_standardised_shares.csv'}
 d={k:pd.read_csv(source/v) for k,v in names.items()}
 for name in names.values():shutil.copy2(source/name,OUT/name)
 for name in ['2025_standard_age_weights.csv','2025_region_age_standardisation_components.csv']:shutil.copy2(source/name,OUT/name)
 validation=json.loads((source/'raw_processing_validation.json').read_text())
 # Recompute consequential identities from retained sufficient statistics.
 annual=d['annual'];std=d['std'];weights=pd.read_csv(source/'2025_standard_age_weights.csv');ra=pd.read_csv(source/'2025_region_age_standardisation_components.csv')
 checks={'category_shares_recomputed':bool((100*annual.n/annual.classified_n-annual.percent).abs().lt(1e-8).all()),'category_percent_sum_100':bool(annual.groupby(['year','instrument','sex']).percent.sum().sub(100).abs().lt(1e-8).all()),'standard_weights_sum_1':bool(weights.groupby('instrument').weight.sum().sub(1).abs().lt(1e-10).all()),'regional_crude_shares_recomputed':bool((100*std.numerator/std.denominator-std.crude_percent).abs().lt(1e-8).all())}
 recalculated=ra.assign(weighted=ra.percent*ra.weight).groupby(['year','instrument','sex','region']).weighted.sum().sort_index()
 expected=std.set_index(['year','instrument','sex','region']).standardised_percent.sort_index()
 checks['regional_standardised_shares_recomputed']=bool(recalculated.sub(expected).abs().lt(1e-8).all())
 assert all(checks.values()),checks
 (OUT/'offline_aggregate_validation.json').write_text(json.dumps({'status':'PASS','checks':checks,'requires_external_volume':False},indent=2))
 (OUT/'validation.json').write_text(json.dumps(validation,indent=2))
 d['latest']=d['annual_metrics'][d['annual_metrics'].year.eq(2025)].copy();d['validation']=validation
 return build_bundle(**d)

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--from-aggregates',action='store_true');parser.add_argument('--refresh-raw',action='store_true');a=parser.parse_args()
 if a.refresh_raw:run()
 elif a.from_aggregates or (OUT/'source_data/annual_category_composition.csv').exists():from_aggregates()
 else:run()

