"""Idempotently bind the shared instrument extension into existing report QMDs."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re

import yaml

ROOT = Path(__file__).resolve().parents[2]
REPORTS = {
    "descriptive": "docs/descriptive_methods_results.qmd",
    "connected": "docs/reproductive_life_course.qmd",
    "access": "docs/access_diagnostic_recording_extension.qmd",
}
MARKERS = ["LOAD", "METHODS", "RESULTS"]

LOAD = '''<!-- BEGIN REM INSTRUMENT LOAD -->
```{python}
#| label: load-rem-instrument-evidence
#| output: asis
# Rendering uses portable aggregate evidence; it does not read the external disk.
sys.path.insert(0, str(PROJECT / 'scripts/rem_neuro_instruments'))
from report_render import (load_instrument_bundle, validate_arithmetic_checks,
                           InstrumentRenderer)
instrument_evidence = load_instrument_bundle(PROJECT)
instrument_arithmetic_checks = validate_arithmetic_checks(PROJECT, instrument_evidence)
instrument_report = InstrumentRenderer(PROJECT, instrument_evidence)
```
<!-- END REM INSTRUMENT LOAD -->

'''

METHODS = '''<!-- BEGIN REM INSTRUMENT METHODS -->
### Additional REM functional and dementia instrument methods

```{python}
#| label: ni-instrument-methods
#| output: asis
instrument_report.methods()
```
<!-- END REM INSTRUMENT METHODS -->

'''

RESULTS = '''<!-- BEGIN REM INSTRUMENT RESULTS -->
## Additional REM instrument results

```{{python}}
#| label: ni-instrument-results
#| output: asis
instrument_report.results(context='{context}')
```

### Reproducing the instrument analyses

The instrument figures, table cells and scientific Methods and Results text are
shared with the Word reports. This page verifies the saved evidence files and
recalculates the explicitly declared aggregate checks at render time. Source
record extraction and original analytical processing are separate operations;
they are not silently repeated when a reader renders this page. The aggregate
inputs and analysis code allow the instrument outputs to be reconstructed
without the external data volume. Original-source refresh additionally requires
the same authorised REM releases and annual coded templates.

The commands below are displayed for inspection and are not executed during
rendering. Use the scientific and document environments recorded by the runner.

```{{python}}
#| label: ni-instrument-explicit-rebuild-commands
#| eval: false
#| code-fold: true
import subprocess

# Rebuild the new instrument evidence and its matching Word and HTML reports
# from retained aggregate inputs.
subprocess.run(['python3', 'scripts/run_rem_instrument_extension.py', '--word', '--html'],
               cwd=PROJECT, check=True)

# Refresh source-record extraction only with the authorised data volume mounted.
subprocess.run(['python3', 'scripts/run_rem_instrument_extension.py', '--refresh-raw',
                '--word', '--html'], cwd=PROJECT, check=True)
```

[Download the instrument aggregate data and reproducible sources](../outputs/rem_neuro_instruments_2026-10-30/REM_Instrument_Assets_EN.zip)
· <a href="{source_name}" download="{qmd_name}">Download this executable report source</a>
<!-- END REM INSTRUMENT RESULTS -->

'''


def inject_text(text: str, context: str, qmd_name: str) -> str:
    for name in MARKERS:
        pattern = rf"<!-- BEGIN REM INSTRUMENT {name} -->.*?<!-- END REM INSTRUMENT {name} -->\s*"
        text = re.sub(pattern, "", text, flags=re.S)
    if text.count("## Methods\n") != 1 or text.count("## Results\n") != 1:
        raise ValueError("Expected one explicit Methods and Results heading")
    text = text.replace("## Methods\n", LOAD + "## Methods\n", 1)
    text = text.replace("## Results\n", METHODS + "## Results\n", 1)
    anchors = {
        "descriptive": "## Reproducibility and data access",
        "connected": "## Reproducibility and original data sources",
        "access": "## Original data and classification sources",
    }
    anchor = anchors[context]
    if text.count(anchor) != 1:
        raise ValueError(f"Expected report-specific insertion anchor: {anchor}")
    source_name = Path(qmd_name).with_suffix("").name + "_source.txt"
    extension = RESULTS.format(context=context, source_name=source_name, qmd_name=qmd_name)
    text = text.replace(anchor, extension + anchor, 1)
    if re.search(r"^date-modified:", text, flags=re.M):
        text = re.sub(r"^date-modified:.*$", "date-modified: 2026-10-30", text, count=1, flags=re.M)
    else:
        text = re.sub(r"^lang: en$", "lang: en\ndate-modified: 2026-10-30", text, count=1, flags=re.M)
    return text


def install_qmd(path: Path, context: str) -> bool:
    path = Path(path)
    before = path.read_text(encoding="utf-8")
    after = inject_text(before, context, path.name)
    if after != before:
        path.write_text(after, encoding="utf-8")
    mirror = path.with_name(path.stem + "_source.txt")
    if not mirror.exists() or mirror.read_bytes() != path.read_bytes():
        mirror.write_bytes(path.read_bytes())
    return after != before


def install_resources(project: Path = ROOT):
    path = Path(project) / "_quarto.yml"
    config = yaml.safe_load(path.read_text())
    resources = config["project"].setdefault("resources", [])
    broad = {f"outputs/rem_neuro_instruments_2026-10-30/**/*.{extension}" for extension in ["csv", "png", "svg", "pdf"]}
    resources[:] = [value for value in resources if value not in broad]
    additions = [
        "outputs/rem_neuro_instruments_2026-10-30/report_bundle.json",
        "outputs/rem_neuro_instruments_2026-10-30/analysis_a/**/*.csv",
        "outputs/rem_neuro_instruments_2026-10-30/analysis_a/figures/*.png",
        "outputs/rem_neuro_instruments_2026-10-30/analysis_a/figures/*.svg",
        "outputs/rem_neuro_instruments_2026-10-30/analysis_a/figures/*.pdf",
        "outputs/rem_neuro_instruments_2026-10-30/analysis_p/**/*.csv",
        "outputs/rem_neuro_instruments_2026-10-30/analysis_p/figures/*.png",
        "outputs/rem_neuro_instruments_2026-10-30/analysis_p/figures/*.svg",
        "outputs/rem_neuro_instruments_2026-10-30/analysis_p/figures/*.pdf",
        "outputs/rem_neuro_instruments_2026-10-30/REM_Instrument_Assets_EN.zip",
        "scripts/rem_neuro_instruments/*.py",
        "scripts/run_rem_instrument_extension.py",
    ]
    additions += [str(Path(relative).with_name(Path(relative).stem + "_source.txt")) for relative in REPORTS.values()]
    for item in additions:
        if item not in resources:
            resources.append(item)
    path.write_text(yaml.safe_dump(config, sort_keys=False, allow_unicode=True), encoding="utf-8")


def install_all(project: Path = ROOT):
    project = Path(project)
    changed = {context: install_qmd(project / relative, context) for context, relative in REPORTS.items()}
    install_resources(project)
    refresh_index_counts(project)
    return changed


def refresh_index_counts(project: Path = ROOT):
    """Derive homepage totals from the final shared extension, never a draft count."""
    project = Path(project)
    bundle_path = project / "outputs/rem_neuro_instruments_2026-10-30/report_bundle.json"
    if not bundle_path.is_file():
        return False
    bundle = json.loads(bundle_path.read_text())
    figure_count, table_count = len(bundle["figures"]), len(bundle["tables"])
    path = project / "index.qmd"
    before = path.read_text()
    after = before
    originals = {"descriptive": (24, 24), "connected": (14, 26), "access": (10, 26)}
    descriptions = {
        "descriptive": "including the extended selection bank and new REM instrument analyses",
        "connected": "including the survey surgery care and new REM instrument analyses",
        "access": "including new REM instrument panels and quality and denominator checks",
    }
    for context, (base_figures, base_tables) in originals.items():
        pattern = rf'(<p class="research-counts" data-report-context="{context}">).*?(</p>)'
        body = (f'{base_figures + figure_count} figures · {base_tables + table_count} tables '
                f'<span>{descriptions[context]}</span>')
        after, replacements = re.subn(pattern, lambda match: match[1] + body + match[2], after, flags=re.S)
        if replacements != 1:
            raise ValueError(f"Expected one homepage count card for {context}")
    if after != before:
        path.write_text(after)
    return after != before


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", choices=list(REPORTS))
    args = parser.parse_args()
    if args.report:
        print({args.report: install_qmd(ROOT / REPORTS[args.report], args.report)})
        install_resources()
    else:
        print(install_all())
