"""Execute the delivered aggregate package with external-source access denied."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/rem_neuro_instruments_2026-10-30"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run():
    archive = OUT / "REM_Instrument_Assets_EN.zip"
    expected = json.loads((OUT / "report_bundle.json").read_text())
    with tempfile.TemporaryDirectory(prefix="rem_instrument_rebuild_", dir="/private/tmp") as directory:
        temporary = Path(directory)
        project = temporary / "project"
        with zipfile.ZipFile(archive) as source:
            source.extractall(project)
        guard = temporary / "guard"
        guard.mkdir()
        attempts = temporary / "denied_attempts.jsonl"
        guard.joinpath("sitecustomize.py").write_text('''import builtins, io, os, socket
_open = builtins.open
def denied(kind, value):
    with _open(os.environ['REM_DENIED_LOG'], 'a') as f: f.write(kind+' '+str(value)+'\\n')
    raise RuntimeError('External data or network access is forbidden during aggregate-only validation')
def outside(value):
    try: return os.fsdecode(value).startswith('/Volumes/')
    except TypeError: return False
def wrap(function, kind):
    def checked(path, *args, **kwargs):
        if outside(path): denied(kind, path)
        return function(path, *args, **kwargs)
    return checked
builtins.open = wrap(builtins.open, 'open')
io.open = wrap(io.open, 'io.open')
for name in ['stat','lstat','listdir','scandir']:
    setattr(os, name, wrap(getattr(os,name), name))
socket.socket.connect = lambda self, address: denied('network', address)
socket.create_connection = lambda *args, **kwargs: denied('network', args)
socket.getaddrinfo = lambda *args, **kwargs: denied('dns', args)
''')
        env = os.environ.copy()
        env.update({"PYTHONPATH": str(guard), "REM_DENIED_LOG": str(attempts), "ASESORIAS_DATA_ROOT": "/Volumes/REPRODUCTION_MUST_NOT_READ_OR_EXIST"})
        result = subprocess.run([sys.executable, "scripts/run_rem_instrument_extension.py"], cwd=project, env=env, capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError(result.stdout[-2000:] + result.stderr[-4000:])
        assert not attempts.exists() or not attempts.read_text().strip()
        copied = json.loads((project / "outputs/rem_neuro_instruments_2026-10-30/report_bundle.json").read_text())
        assert copied["content_sha256"] == expected["content_sha256"]
        checked = []
        for item in expected["file_hashes"]:
            assert digest(project / item["path"]) == item["sha256"], item["path"]
            checked.append(item["path"])
        for component in ["analysis_a", "analysis_p"]:
            for path in (OUT / component / "tables").glob("*.csv"):
                relative = path.relative_to(ROOT)
                assert digest(project / relative) == digest(path), str(relative)
                checked.append(str(relative))
        receipt = {"status": "PASS", "package_sha256": digest(archive), "instrument_content_sha256": expected["content_sha256"],
                   "external_volume_or_network_attempts": 0, "isolated_parent_project_absent": True,
                   "full_aggregate_runner_succeeded": True, "byte_identical_files_checked": len(set(checked)),
                   "files": sorted(set(checked)), "scope": "New instrument tables, figures and display evidence only; existing historical reports require the parent project"}
    (OUT / "report_revision/offline_package_validation.json").write_text(json.dumps(receipt, indent=2))
    print(json.dumps({key: value for key, value in receipt.items() if key != "files"}))


if __name__ == "__main__":
    run()
