"""Offline paper figures from retained aggregate REM instrument source tables."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager, ticker
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
from PIL import Image

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/rem_neuro_instruments_2026-10-30/analysis_a'
SRC=OUT/'source_data'
COL={'Increase':'#9F3F37','Maintained':'#687480','Decrease':'#247B69','Improved':'#247B69','Declined':'#9F3F37'}
HATCH={'Increase':'///','Maintained':'','Decrease':'..','Improved':'..','Declined':'///'}
SEXCOL={'Women':'#8B3E69','Men':'#286787'}
MEASURES={'GDS-Reisberg':('#222D3A','o'),'Dementia caregiver burden':('#6F4C83','s'),'Dementia caregiver satisfaction':('#28746C','^')}
SHORT={'GDS-Reisberg':'GDS-Reisberg','Dementia caregiver burden':'Caregiver burden','Dementia caregiver satisfaction':'Caregiver satisfaction'}
STYLE={'font.family':'Arial','font.size':8,'axes.labelsize':8,'axes.titlesize':9,'xtick.labelsize':7.5,'ytick.labelsize':8,
       'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.55,'lines.linewidth':1.25,
       'savefig.facecolor':'white','figure.facecolor':'white','axes.facecolor':'white','pdf.fonttype':42,'ps.fonttype':42,
       'svg.fonttype':'none','svg.hashsalt':'rem-neuro-instruments-a-2026-10-30','hatch.linewidth':.35,'text.color':'#20262D','axes.labelcolor':'#20262D',
       'xtick.color':'#20262D','ytick.color':'#20262D'}

def read(name):return pd.read_csv(SRC/name,dtype={'code':str})
def rel(p):return str(Path(p).relative_to(ROOT))
def fmt(n):return f'{int(n):,}'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def source_file(data,name):
    path=SRC/name;data.to_csv(path,index=False);return rel(path)

def panel(ax,letter,title):
    ax.set_title(f'{letter}  {title}',loc='left',weight='bold',pad=11)

def decorate(ax):
    ax.set_axisbelow(True);ax.grid(axis='y',color='#E2E6E9',lw=.5)
    ax.tick_params(length=3,width=.55)

def years(ax):
    ax.set_xticks(list(range(2019,2026)),[str(x)[2:] for x in range(2019,2026)])
    ax.set_xlim(2018.65,2025.55);ax.set_xlabel('Year (2019–2025)')

def withheld(ax):
    ax.axvspan(2020.72,2021.28,facecolor='#F0F1F2',hatch='///',edgecolor='#D6D9DC',lw=0,zorder=0)
    ax.text(2021,.97,'2021 withheld',ha='center',va='top',rotation=90,fontsize=7,transform=ax.get_xaxis_transform(),color='#626C74')

def stack_sexes(ax,data,directions,subtitle=''):
    ax.spines[['left','right','top']].set_visible(False)
    ax.set_xlim(0,121);ax.set_ylim(1.82,-.72)
    labels=[]
    for y,sex in enumerate(['Women','Men']):
        q=data.loc[data.sex.eq(sex)].set_index('direction')
        den=q.denominator.iloc[0]
        labels.append(f'{sex}\nN = {fmt(den)}')
        left=0
        for direction in directions:
            value=q.loc[direction,'percent']
            ax.barh(y,value,left=left,height=.48,color=COL[direction],edgecolor='white',lw=.65,hatch=HATCH[direction],zorder=2)
            if value>=8:
                ax.text(left+value/2,y,f'{value:.1f}',color='white',ha='center',va='center',fontsize=8,weight='bold')
            else:
                ax.annotate(f'{value:.1f}',xy=(left+value/2,y),xytext=(105,y),ha='left',va='center',fontsize=8,
                            arrowprops={'arrowstyle':'-','color':'#626C74','lw':.55},annotation_clip=False)
            left+=value
        assert np.isclose(left,100)
    ax.set_yticks([0,1],labels);ax.tick_params(axis='y',length=0,pad=4)
    ax.set_xticks([0,25,50,75,100]);ax.set_xlabel('Share of eligible evaluations (%)')
    ax.grid(axis='x',color='#E2E6E9',lw=.5,zorder=0);ax.set_axisbelow(True)
    if subtitle:ax.text(0,1.025,subtitle,transform=ax.transAxes,fontsize=7.2,va='bottom')

def export(fig,name,source,caption,title,alt,id):
    prefix=OUT/'figures'/name
    paths={}
    for ext in ['png','svg','pdf']:
        metadata={'Software':'REM neurological instrument analysis'} if ext=='png' else ({'Date':None,'Creator':'REM neurological instrument analysis'} if ext=='svg' else {'CreationDate':None,'ModDate':None,'Creator':'REM neurological instrument analysis'})
        p=prefix.with_suffix('.'+ext);fig.savefig(p,dpi=600,facecolor='white',transparent=False,metadata=metadata);paths[ext]=rel(p)
    plt.close(fig)
    with Image.open(ROOT/paths['png']) as im:
        meta={'pixels':list(im.size),'dpi':list(im.info.get('dpi',[])),'mode':im.mode}
    meta.update({'id':id,'width_mm':180,'height_mm':round(fig.get_figheight()*25.4,2),'sha256':{e:digest(ROOT/p) for e,p in paths.items()},
                 'source_csv':source,'source_sha256':digest(ROOT/source),'font_path':font_manager.findfont('Arial'),
                 'purpose':'Provisional general manuscript figure; no journal-specific compliance claimed','visual_review':'Pending agent inspection'})
    return {'id':id,'title':title,'caption':caption,'path_png':paths['png'],'path_pdf':paths['pdf'],'path_svg':paths['svg'],'source_csv':source,'alt':alt},meta

def figure1(annual,changes):
    fig,axes=plt.subplots(3,2,figsize=(180/25.4,194/25.4),gridspec_kw={'width_ratios':[1.08,1]},layout='constrained')
    fig.set_constrained_layout_pads(w_pad=.05,h_pad=.07,wspace=.07,hspace=.13)
    measures=list(MEASURES)
    for i,measure in enumerate(measures):
        q=changes.loc[changes.year.eq(2025)&changes.measure.eq(measure)&changes.sex.ne('Both sexes')]
        panel(axes[i,0],chr(65+2*i),f'{SHORT[measure]}: 2025 change')
        r=annual.loc[annual.year.eq(2025)&annual.measure.eq(measure)].iloc[0]
        stack_sexes(axes[i,0],q,['Increase','Maintained','Decrease'],f'Complete rows: {fmt(r.complete9_rows)} / {fmt(r.observed_rows)} observed')
        ax=axes[i,1];panel(ax,chr(66+2*i),'Recorded evaluations by sex')
        s=annual.loc[annual.measure.eq(measure)].sort_values('year')
        for sex,col,marker in [('Women','primary_women','o'),('Men','primary_men','s')]:
            ax.plot(s.year,s[col],color=SEXCOL[sex],marker=marker,ms=3.6,label=sex)
        ax.set_ylim(bottom=0);years(ax);decorate(ax);withheld(ax)
        ax.set_ylabel('Recorded evaluations')
        if i==0:ax.legend(frameon=False,fontsize=7.5,loc='upper left')
        if i==0:
            axes[i,0].legend(handles=[Patch(facecolor=COL[d],hatch=HATCH[d],edgecolor='white',label=d) for d in ['Increase','Maintained','Decrease']],
                             loc='lower left',bbox_to_anchor=(-.05,1.32),ncol=3,frameon=False,fontsize=7.2,handlelength=1.2,columnspacing=.8)
    source=pd.concat([changes.loc[changes.year.eq(2025)&changes.sex.ne('Both sexes')].assign(panel_record='2025 change categories'),annual.assign(panel_record='Annual activity; 2021 primary values missing')],ignore_index=True)
    src=source_file(source,'NI-A-F1_source.csv')
    return export(fig,'NI-A-F1_dementia_evaluation_changes',src,
        'Panels A, C and E show sex-specific increased, maintained and decreased categories in 2025 complete, coherent nine-cell A06 rows; denominators and observed/eligible rows are displayed. Panels B, D and F show recorded activity by sex in observed facilities, with the entire unresolved 2021 year withheld as a visible gap. Monthly recordings may repeat people. Sex refers to patients for GDS-Reisberg and caregivers for caregiver measures. Increase in deterioration/burden and increase in satisfaction have different meanings. No raw score, treatment effect or national prevalence is implied. Missing cells were not replaced by zero.',
        'Dementia programme reevaluation categories and recorded activity',
        'Six panels show 2025 GDS-Reisberg, caregiver burden and caregiver satisfaction change distributions by sex beside annual activity; 2021 is withheld because of an unresolved source anomaly.', 'NI-A-F1')

def figure2(annual):
    fig,axes=plt.subplots(2,2,figsize=(180/25.4,162/25.4))
    fig.subplots_adjust(left=.115,right=.98,bottom=.09,top=.875,wspace=.52,hspace=.62)
    for measure,(color,marker) in MEASURES.items():
        q=annual.loc[annual.measure.eq(measure)].sort_values('year')
        axes[0,0].plot(q.year,q.primary_facilities,color=color,marker=marker,ms=3.5,label=SHORT[measure])
        pc=q.complete9_row_percent.where(q.year.ne(2021))
        axes[0,1].plot(q.year,pc,color=color,marker=marker,ms=3.5)
    panel(axes[0,0],'A','A06: observed reporting facilities')
    panel(axes[0,1],'B','Nine-cell completeness')
    for ax in axes[0]:years(ax);decorate(ax);withheld(ax)
    axes[0,0].set(ylabel='Observed facilities',ylim=(0,130));axes[0,1].set(ylabel='Eligible / observed rows (%)',ylim=(0,100))
    handles,labels=axes[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,frameon=False,fontsize=7.2,loc='upper left',bbox_to_anchor=(.105,.985),handlelength=1.3,ncol=3,columnspacing=1.2)
    ax=axes[1,0];panel(ax,'C','2025 complete-case selection')
    for i,measure in enumerate(MEASURES):
        r=annual.loc[annual.year.eq(2025)&annual.measure.eq(measure)].iloc[0]
        p=r.complete9_row_percent
        ax.barh(i,p,color='#28746C',height=.5,edgecolor='white')
        ax.barh(i,100-p,left=p,color='#EEF0F2',height=.5,edgecolor='#737D86',hatch='///',lw=.35)
        ax.text(p/2,i,f'{p:.1f}%',color='white',ha='center',va='center',fontsize=8,weight='bold')
        ax.text(102,i,f'{fmt(r.complete9_rows)}/{fmt(r.observed_rows)}',ha='left',va='center',fontsize=7.4)
    ax.set_yticks(range(3),['GDS','Burden','Satisfaction']);ax.set_ylim(2.5,-.9);ax.set_xlim(0,134);ax.set_xticks([0,25,50,75,100]);ax.set_xlabel('Observed rows (%)')
    ax.spines[['left','top','right']].set_visible(False);ax.tick_params(axis='y',length=0)
    ax.legend(handles=[Patch(facecolor='#28746C',label='Eligible'),Patch(facecolor='#EEF0F2',edgecolor='#737D86',hatch='///',label='Missing / invalid')],
              frameon=False,fontsize=7.2,ncol=2,loc='upper left',columnspacing=.7,handlelength=1.2)
    ax=axes[1,1];panel(ax,'D','2021 source anomaly')
    anomaly=read('a06_2021_diagnostic_contrast.csv')
    order={'06906135':0,'06906140':1,'06906145':2}
    for r in anomaly.itertuples():
        y=order[r.code]
        ax.plot([r.raw_sum_outside_flagged_cluster,r.raw_col01_sum],[y,y],color='#A7ADB3',lw=.8)
        ax.scatter(r.raw_col01_sum,y,color='#4D5560',s=20,marker='o',zorder=3)
        ax.scatter(r.raw_sum_outside_flagged_cluster,y,color='#28746C',s=25,marker='D',zorder=3)
        ax.annotate(fmt(r.raw_col01_sum),(r.raw_col01_sum,y),xytext=(-2,8),textcoords='offset points',ha='right',fontsize=7.1)
        ax.annotate(fmt(r.raw_sum_outside_flagged_cluster),(r.raw_sum_outside_flagged_cluster,y),xytext=(0,-13),textcoords='offset points',ha='center',fontsize=7.1)
    ax.set_yticks(range(3),['GDS','Burden','Satisfaction']);ax.set_ylim(2.5,-1.0);ax.set_xscale('log');ax.set_xlim(20,250000)
    ax.set_xticks([100,1000,10000,100000],['100','1,000','10,000','100,000']);ax.minorticks_off();ax.set_xlabel('Recorded evaluations (log scale)')
    ax.spines[['left','right','top']].set_visible(False);ax.tick_params(axis='y',length=0)
    ax.legend(handles=[Line2D([],[],color='#4D5560',marker='o',ls='',label='All source rows'),Line2D([],[],color='#28746C',marker='D',ls='',label='Outside flagged cluster')],
              frameon=False,fontsize=7,ncol=1,loc='upper left',handletextpad=.4)
    src=source_file(pd.concat([annual.assign(panel_record='Annual coverage and completeness'),anomaly.assign(panel_record='2021 diagnostic sensitivity; not corrected estimates')],ignore_index=True),'NI-A-F2_source.csv')
    return export(fig,'NI-A-F2_recording_coverage_anomaly',src,
        'Panels A and B describe observed reporting facilities and the fraction of observed rows meeting all nine-cell completeness/coherence criteria. The unresolved 2021 A06 year is withheld from primary comparisons. Panel C gives 2025 eligible/observed row counts; a missing cell is not a recorded zero. Panel D contrasts all 2021 source recordings with those outside a flagged four-facility January cluster; this logarithmic point comparison is diagnostic and is not an adopted correction. The original cluster contributes 107,160 to each measure. Coverage is observed-source coverage, not national completeness, and perfect arithmetic reconciliation did not resolve the suspicious replicated vectors.',
        'Observed A06 recording coverage, complete-case selection and unresolved source anomaly',
        'Four panels show reporting-facility growth, incomplete nine-cell rows, 2025 complete-case selection and the extreme 2021 source cluster dominating all three measures.', 'NI-A-F2')

def figure3(zarit,zsel,funcs,fsel,yes):
    fig,axes=plt.subplots(3,2,figsize=(180/25.4,204/25.4),layout='constrained')
    fig.set_constrained_layout_pads(w_pad=.05,h_pad=.07,wspace=.09,hspace=.14)
    ax=axes[0,0];panel(ax,'A','Zarit: intense caregiver burden')
    for sex,marker in [('Women','o'),('Men','s')]:
        q=zarit.loc[zarit.sex.eq(sex)&zarit.direction.eq('Intense burden')].sort_values('year')
        ax.plot(q.year,q.percent,color=SEXCOL[sex],marker=marker,ms=3.5,label=sex)
    ax.set(ylim=(0,100),ylabel='Intense burden / paired recordings (%)');years(ax);decorate(ax);ax.legend(frameon=False,fontsize=7.5,loc='lower left')
    ax=axes[0,1];panel(ax,'B','Zarit: paired-category availability')
    q=zsel.sort_values('year');x=np.arange(len(q));p=q.eligible_set_percent
    ax.bar(x,p,color='#28746C',width=.67,edgecolor='white',lw=.4)
    ax.bar(x,100-p,bottom=p,color='#EEF0F2',width=.67,edgecolor='#737D86',hatch='///',lw=.35)
    for i,v in enumerate(p):ax.text(i,v/2,f'{v:.0f}',ha='center',va='center',color='white',fontsize=7,weight='bold')
    ax.set_xticks(x,[str(y)[2:] for y in q.year]);ax.set(ylim=(0,100),ylabel='Eligible / observed sets (%)',xlabel='Year (2019–2025)');decorate(ax)
    ax.text(0,1.02,'Both Zarit category rows required',transform=ax.transAxes,fontsize=7.2)
    panels=[('Timed Up and Go',axes[1,0],'C','TUG: programme discharge, 2025'),('Functionality questionnaire',axes[1,1],'D','Functionality questionnaire, 2025'),('Hospital Barthel change',axes[2,0],'E','Hospital Barthel change, 2025')]
    for measure,ax,letter,title in panels:
        panel(ax,letter,title)
        q=funcs.loc[funcs.year.eq(2025)&funcs.measure.eq(measure)&funcs.sex.ne('Both sexes')]
        s=fsel.loc[fsel.year.eq(2025)&fsel.measure.eq(measure)].iloc[0]
        stack_sexes(ax,q,['Improved','Maintained','Declined'],f'Eligible sets: {fmt(s.eligible_facility_month_sets)} / {fmt(s.candidate_facility_month_sets)} observed')
    axes[1,0].legend(handles=[Patch(facecolor=COL[d],hatch=HATCH[d],edgecolor='white',label=d) for d in ['Improved','Maintained','Declined']],
                     frameon=False,fontsize=7,ncol=3,loc='lower left',bbox_to_anchor=(-.03,1.3),columnspacing=.8,handlelength=1.2)
    ax=axes[2,1];panel(ax,'F','Yesavage: recorded applications')
    q=yes.loc[yes.code.eq('09600226')].sort_values('year');x=np.arange(len(q));bottom=np.zeros(len(q))
    for sex,col in [('Women','women'),('Men','men')]:
        ax.bar(x,q[col],bottom=bottom,color=SEXCOL[sex],label=sex,width=.55,edgecolor='white',lw=.55,hatch='..' if sex=='Women' else '')
        for i,v in enumerate(q[col]):ax.text(i,bottom[i]+v/2,f'{v/1000:.1f}',ha='center',va='center',fontsize=7.5,color='white',weight='bold')
        bottom+=q[col].to_numpy()
    ax.set_xticks(x,q.year);ax.set_ylabel('Applications (thousands)');ax.yaxis.set_major_formatter(ticker.FuncFormatter(lambda v,pos:f'{v/1000:.0f}'))
    ax.set_ylim(bottom=0);decorate(ax);ax.legend(frameon=False,fontsize=7.2,loc='upper left')
    ax.text(0,1.02,'Depression screening; not dementia GDS',transform=ax.transAxes,fontsize=7.2)
    src=source_file(pd.concat([zarit.loc[zarit.sex.ne('Both sexes')&zarit.direction.eq('Intense burden')].assign(panel_record='Zarit intensity share'),zsel.assign(panel_record='Zarit paired selection'),funcs.loc[funcs.year.eq(2025)&funcs.sex.ne('Both sexes')].assign(panel_record='2025 selected functional change'),yes.assign(panel_record='Yesavage application activity')],ignore_index=True),'NI-A-F3_source.csv')
    return export(fig,'NI-A-F3_caregiver_functional_context',src,
        'Panel A shows intense burden among repeated caregiver evaluation recordings in facility-months with both Zarit categories present and coherent total/sex cells. Panel B shows the selected paired-set fraction; absent rows and blanks are not zero. This severe-dependency caregiver scope is not dementia-specific. Panels C–E show 2025 improved, maintained and declined categories within each instrument\'s separate complete three-category sets, with recorded evaluation denominators. Programme TUG/functionality (age 60+) and hospital Barthel (age 65+) represent different settings and cannot be pooled as a treatment response. Panel F shows Yesavage GDS-15 application activity, a depression-screening construct distinct from GDS-Reisberg. All counts may repeat individuals; no population risk, causal benefit or clinical diagnostic accuracy is inferred.',
        'Caregiver burden, selected functional change and depression-screening context',
        'Six panels show Zarit caregiver burden shares and selection, 2025 TUG/functionality/hospital Barthel change distributions by sex, and Yesavage screening application counts.', 'NI-A-F3')

def run():
    annual=read('a06_annual.csv');changes=read('a06_change_categories.csv')
    zarit,zsel=read('zarit_categories.csv'),read('zarit_selection.csv')
    funcs,fsel=read('functional_change_categories.csv'),read('functional_selection.csv');yes=read('yesavage_context.csv')
    (OUT/'figures').mkdir(parents=True,exist_ok=True)
    with plt.rc_context(STYLE):
        results=[figure1(annual,changes),figure2(annual),figure3(zarit,zsel,funcs,fsel,yes)]
    bundle=json.loads((OUT/'analysis_bundle.json').read_text())
    bundle['figures']=[r[0] for r in results]
    (OUT/'analysis_bundle.json').write_text(json.dumps(bundle,ensure_ascii=False,indent=2,allow_nan=False))
    manifest={'figures':[r[1] for r in results],'software':{'matplotlib':matplotlib.__version__,'pandas':pd.__version__,'numpy':np.__version__},
              'offline_command':'python scripts/rem_neuro_instruments/a_figures.py','data_policy':'Frozen aggregate inputs only; no external disk access','visual_review':'Pending direct inspection'}
    (OUT/'figure_manifest.json').write_text(json.dumps(manifest,indent=2))
    print(json.dumps({'figures':len(results),'png_dimensions':[r[1]['pixels'] for r in results]},indent=2))

if __name__=='__main__':run()
