"""Locate observed REM A instrument rows without changing existing analyses.

Input: the separately audited annual coded-template CSV. Source rows and
zero/blank states are retained on the external data volume; only aggregate
availability checks are written to the project. Counts are recording events,
not unique patients. This script does not estimate prevalence or effects.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
DATA = Path(os.environ.get("ASESORIAS_DATA_ROOT", "/Volumes/Datos/Asesorias_Data"))
OUT = ROOT / "outputs/rem_neuro_instruments_2026-10-30/a_data_audit"
PRIVATE = DATA / "derived/Reproductive-hormones-cognitive-decline-women-Chile/rem_neuro_instruments"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def run(mapping_path: Path) -> None:
    mapping = pd.read_csv(mapping_path, dtype=str, keep_default_na=False)
    required = {"year", "code", "coded_columns"}
    if not required.issubset(mapping.columns):
        raise ValueError(f"Expected {required}; found {list(mapping.columns)}")
    codes = sorted(set(mapping.code))
    assert all(re.fullmatch(r"[0-9]{8}[A-Z]?", code) for code in codes)
    OUT.mkdir(parents=True, exist_ok=True)
    PRIVATE.mkdir(parents=True, exist_ok=True)
    files, profiles, cells = [], [], []
    for year in sorted(set(mapping.year)):
        source = DATA / f"REM/SerieA/SerieA_{year}.csv"
        target = PRIVATE / f"instrument_selected_A_{year}.csv.gz"
        temporary = PRIVATE / f"instrument_scan_A_{year}.tmp"
        with source.open(encoding="latin1", newline="") as handle:
            header = next(csv.reader(handle, delimiter=";"))
        assert header[:7] == ["Mes", "IdServicio", "Ano", "IdEstablecimiento", "CodigoPrestacion", "IdRegion", "IdComuna"]
        assert header[7:] == [f"Col{i:02d}" for i in range(1, 51)]
        pattern = r"^(?:[^;]*;){4}(?:" + "|".join(codes) + ");"
        with temporary.open("wb") as handle:
            result = subprocess.run(["rg", "--text", "--no-heading", "--no-filename", "--no-line-number", pattern, str(source)], stdout=handle, stderr=subprocess.PIPE)
        assert result.returncode in (0, 1), result.stderr.decode()
        if temporary.stat().st_size:
            frame = pd.read_csv(temporary, sep=";", header=None, names=header, dtype=str, keep_default_na=False, encoding="latin1")
        else:
            frame = pd.DataFrame(columns=header)
        frame.to_csv(target, index=False, compression={"method": "gzip", "mtime": 0})
        temporary.unlink()
        assert frame.CodigoPrestacion.isin(codes).all()
        source_stat = source.stat()
        key = ["Ano", "Mes", "IdServicio", "IdEstablecimiento", "CodigoPrestacion"]
        file_record = {"year": int(year), "source": str(source), "source_bytes": source_stat.st_size, "source_mtime_ns": source_stat.st_mtime_ns,
                       "filter_codes": codes, "filter_regex": pattern, "selected_rows": len(frame), "selected_cache": str(target),
                       "selected_cache_sha256": sha256(target), "mapping_sha256": sha256(mapping_path),
                       "duplicate_key_rows": int(frame.duplicated(key, keep=False).sum()), "duplicate_full_rows": int(frame.duplicated(keep=False).sum())}
        files.append(file_record)
        year_map = mapping[mapping.year == year]
        # A code must have one meaning/layout within a year in this inventory.
        unique = year_map[["code", "coded_columns"]].drop_duplicates()
        assert not unique.code.duplicated().any(), f"Ambiguous mapping in {year}"
        for code in codes:
            subset = frame[frame.CodigoPrestacion == code]
            info = unique[unique.code == code]
            active = re.findall(r"(?i)COL[0-9]{2}", info.coded_columns.iloc[0]) if len(info) else []
            active = list(dict.fromkeys("Col" + item[-2:] for item in active))
            numeric = subset[active].apply(pd.to_numeric, errors="coerce") if active else pd.DataFrame(index=subset.index)
            raw = subset[active] if active else pd.DataFrame(index=subset.index)
            total = pd.to_numeric(subset.Col01, errors="coerce")
            profile = {"year": int(year), "code": code, "mapped_in_annual_template": bool(len(info)),
                       "raw_rows": len(subset), "facilities_with_rows": subset.IdEstablecimiento.nunique(),
                       "months_with_rows": ";".join(str(x) for x in sorted(pd.to_numeric(subset.Mes).unique())),
                       "mapped_columns": ";".join(active), "active_blank_cells": int(raw.eq("").sum().sum()),
                       "active_explicit_zero_cells": int(numeric.eq(0).sum().sum()), "active_positive_cells": int(numeric.gt(0).sum().sum()),
                       "active_negative_cells": int(numeric.lt(0).sum().sum()),
                       "active_invalid_nonempty_cells": int((raw.ne("") & numeric.isna()).sum().sum()),
                       "rows_with_positive_active_cell": int(numeric.gt(0).any(axis=1).sum()) if active else 0,
                       "facilities_with_positive_active_cell": subset.loc[numeric.gt(0).any(axis=1), "IdEstablecimiento"].nunique() if active else 0,
                       "col01_nonempty_rows": int(subset.Col01.ne("").sum()), "col01_positive_rows": int(total.gt(0).sum()),
                       "col01_sum_recordings_not_unique_people": float(total.sum(min_count=1)) if total.notna().any() else None,
                       "duplicate_key_rows": int(subset.duplicated(key, keep=False).sum()),
                       "duplicate_full_rows": int(subset.duplicated(keep=False).sum())}
            profiles.append(profile)
            for col in active:
                values = numeric[col]
                cells.append({"year": int(year), "code": code, "column": col, "raw_rows": len(subset),
                              "blank_rows": int(subset[col].eq("").sum()), "zero_rows": int(values.eq(0).sum()),
                              "positive_rows": int(values.gt(0).sum()), "negative_rows": int(values.lt(0).sum()),
                              "nonempty_invalid_rows": int((subset[col].ne("") & values.isna()).sum()),
                              "sum_recordings_not_unique_people": float(values.sum(min_count=1)) if values.notna().any() else None})
        print(f"Series A {year}: {len(frame):,} selected rows; {frame.CodigoPrestacion.nunique()} observed codes", flush=True)
    pd.DataFrame(profiles).to_csv(OUT / "annual_code_availability.csv", index=False)
    pd.DataFrame(cells).to_csv(OUT / "annual_active_column_profile.csv", index=False)
    (OUT / "raw_source_audit.json").write_text(json.dumps({"scope": "2019-2025 instrument availability, annual coded-template fields only", "source_files": files,
        "warnings": ["Monthly activity is recorded events, not unique persons or person-level trajectories.",
                     "Blank active cells and absent code rows remain distinct from recorded zero.",
                     "Rows for codes without a current-year mapping are observed but not interpreted.",
                     "No national denominator, full-reporting claim, prevalence estimate or causal effect is inferred."]}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mapping", type=Path)
    run(parser.parse_args().mapping)
