"""Offline scientific panels from sufficient REM P5 aggregate statistics."""
from pathlib import Path
import hashlib,json,platform,sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.colors import Normalize
import geopandas as gpd

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(Path(__file__).parent))
from p_analysis import OUT,CATEGORIES,LABELS,FOCUS_LABELS,AGE_BANDS,REGIONS
SOURCE=OUT/'source_data'
COLORS={'functional':'#8E3564','tug':'#22678E','balance':'#977022'}
SEX={'Women':('#8E3564','o'),'Men':('#22678E','s')}
SHORT={'functional':'Dependency risk or dependency','tug':'Mild/high TUG fall risk','balance':'Altered single-leg stance'}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def style():
 plt.rcParams.update({'font.family':'Arial','font.size':8.5,'axes.labelsize':8.5,'axes.titlesize':9,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,'lines.linewidth':1.1,'lines.markersize':3.6,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','svg.hashsalt':'REM-P5-neuro-2026-10-30','figure.facecolor':'white','axes.facecolor':'white','savefig.facecolor':'white'})

def label(ax,letter,title):
 ax.set_title(f'{letter}  {title}',loc='left',weight='bold',pad=9)

def export(fig,id,name,title,caption,alt,source):
 path=OUT/'figures'/name
 for ext in ['png','svg','pdf']:
  metadata={'png':{'Software':'Matplotlib '+matplotlib.__version__},'svg':{'Date':None},'pdf':{'CreationDate':None,'ModDate':None}}[ext]
  fig.savefig(path.with_suffix('.'+ext),dpi=600,bbox_inches=None,facecolor='white',metadata=metadata)
 fig.savefig(path.with_name(name+'_preview').with_suffix('.png'),dpi=150,bbox_inches=None,facecolor='white')
 plt.close(fig)
 return {'id':id,'title':title,'caption':caption,'path_png':str(path.with_suffix('.png').relative_to(ROOT)),'path_pdf':str(path.with_suffix('.pdf').relative_to(ROOT)),'path_svg':str(path.with_suffix('.svg').relative_to(ROOT)),'source_csv':source,'alt':alt,'width_mm':180,'height_mm':round(fig.get_figheight()*25.4,3),'dpi':600}

def f1():
 flow=pd.read_csv(SOURCE/'instrument_completeness_by_year.csv')
 trend=pd.read_csv(SOURCE/'annual_balanced_comparison.csv')
 ann=pd.read_csv(SOURCE/'annual_category_composition.csv')
 source=OUT/'figures/NI-P-F1_source.csv'
 # Long data contain provider completeness, denominator and adverse share.
 z=trend.merge(flow[['year','instrument','any_represented_facilities','complete_facilities']],on=['year','instrument'],validate='many_to_one')
 z.to_csv(source,index=False)
 fig,axs=plt.subplots(2,2,figsize=(180/25.4,180/25.4))
 fig.subplots_adjust(left=.105,right=.975,top=.94,bottom=.18,wspace=.34,hspace=.49)
 ax=axs[0,0];label(ax,'A','Complete reporting providers')
 for ins,mk in [('functional','o'),('tug','s'),('balance','^')]:
  d=flow[flow.instrument.eq(ins)]
  ax.plot(d.year,d.complete_facilities,color=COLORS[ins],marker=mk,label=LABELS[ins])
  ax.text(2025.18,d.complete_facilities.iloc[-1],f'{d.complete_facilities.iloc[-1]:,}',fontsize=8,color=COLORS[ins],va='center')
 ax.set(ylabel='Establishments with all category totals',xlabel='December snapshot',ylim=(0,2200),xlim=(2018.7,2026.6));ax.set_xticks([2019,2021,2023,2025]);ax.grid(axis='y',color='.9',lw=.5)
 ax=axs[0,1];label(ax,'B','Functional classified denominator')
 for sex,(color,mk) in SEX.items():
  d=trend[trend.instrument.eq('functional')&trend.sex.eq(sex)&trend['sample'].eq('Annual complete providers')]
  ax.plot(d.year,d.denominator/1000,c=color,marker=mk,label=sex)
  ax.text(2025.12,d.denominator.iloc[-1]/1000,f'{d.denominator.iloc[-1]/1000:,.1f}',fontsize=8,color=color,va='center')
 ax.set(ylabel='Recorded classifications (thousands)',xlabel='December snapshot',ylim=(0,650),xlim=(2018.7,2026.8));ax.set_xticks([2019,2021,2023,2025]);ax.legend(loc='upper left',frameon=False);ax.grid(axis='y',color='.9',lw=.5)
 for ax,sex,letter in [(axs[1,0],'Women','C'),(axs[1,1],'Men','D')]:
  label(ax,letter,sex+': adverse classifications')
  for ins,mk in [('functional','o'),('tug','s'),('balance','^')]:
   for sample,ls,alpha in [('Annual complete providers','-',1),('Balanced providers, 2019–2025','--',.82)]:
    d=trend[trend.instrument.eq(ins)&trend.sex.eq(sex)&trend['sample'].eq(sample)]
    ax.plot(d.year,d.percent,c=COLORS[ins],marker=mk if ls=='-' else None,ls=ls,alpha=alpha)
  ax.set(ylabel='Share of classified records (%)',xlabel='December snapshot',ylim=(0,60),xlim=(2018.7,2025.3));ax.set_xticks([2019,2021,2023,2025]);ax.grid(axis='y',color='.9',lw=.5)
 h=[Line2D([],[],c=COLORS[i],marker=m,ls='-',label=LABELS[i]) for i,m in [('functional','o'),('tug','s'),('balance','^')]]
 fig.legend(handles=h,loc='lower center',bbox_to_anchor=(.5,.063),ncol=3,frameon=False,handlelength=1.6,columnspacing=1.8)
 fig.legend(handles=[Line2D([],[],c='.2',ls='-',label='Annual complete providers'),Line2D([],[],c='.2',ls='--',label='Same providers in all seven years')],loc='lower center',bbox_to_anchor=(.5,.015),ncol=2,frameon=False,handlelength=2.2)
 balanced=trend[trend['sample'].eq('Balanced providers, 2019–2025')].groupby('instrument').facilities.max().to_dict()
 cap=f'December reporting completeness, classified-population denominators and provider-selection sensitivity, 2019–2025. A: establishments with complete numeric total and sex counts in all seven functional, three Timed Up and Go (TUG) or two single-leg stance categories, respectively. A provider with a zero sex-specific instrument denominator contributes no record to that sex-specific share. B: functional classified denominators by sex in annual complete-provider samples. C–D: adverse classifications as percentages of their respective classified denominators: dependency risk or any Barthel dependency; mild/high TUG fall risk; and altered single-leg stance. Solid lines use annual complete providers; dashed lines retain the same {balanced["functional"]:,} functional, {balanced["tug"]:,} TUG and {balanced["balance"]:,} balance providers across all seven years. Categories are age 65+ under-control classifications, not population prevalence or neurodegenerative diagnoses. Exact duplicates are removed, inconsistent records are quarantined, and absent or blank fields are not imputed as zero. Balanced membership does not establish person-level follow-up; provider selection and case mix remain. Administrative counts have no added sampling intervals. Source: annual DEIS REM Series P files and coded templates.'
 return export(fig,'NI-P-F1','Figure_NI_P1_classification_trends','Reporting completeness and functional/mobility classification trends',cap,'Four panels show changing complete reporting samples, functional classified denominators, and adverse classification shares for women and men under annual and fixed provider membership.',str(source.relative_to(ROOT)))

def f2():
 comp=pd.read_csv(SOURCE/'2025_age_category_composition.csv');met=pd.read_csv(SOURCE/'2025_age_focus_metrics.csv');flow=pd.read_csv(SOURCE/'age_completeness_by_year.csv')
 source=OUT/'figures/NI-P-F2_source.csv';comp.to_csv(source,index=False)
 fig=plt.figure(figsize=(180/25.4,185/25.4))
 # Explicit physical layout leaves room for full age labels and shared scale.
 gs=fig.add_gridspec(2,3,left=.13,right=.98,bottom=.16,top=.94,wspace=.28,hspace=.78,height_ratios=[1.35,1])
 top=[];bottom=[];norm=Normalize(0,100);cmap=plt.colormaps['cividis']
 for col,ins in enumerate(['functional','tug','balance']):
  ax=fig.add_subplot(gs[0,col]);top.append(ax)
  categories=[cat for _,cat in CATEGORIES[ins]]
  idx=pd.MultiIndex.from_product([['Women','Men'],AGE_BANDS],names=['sex','age'])
  d=comp[comp.instrument.eq(ins)].pivot(index=['sex','age'],columns='category',values='percent').reindex(index=idx,columns=categories)
  im=ax.imshow(d.to_numpy(),vmin=0,vmax=100,cmap=cmap,aspect='auto',interpolation='nearest')
  xt={'functional':['No risk','With risk','Dep. risk','Mild','Moderate','Severe','Total'],'tug':['Normal','Mild risk','High risk'],'balance':['Normal','Altered']}[ins]
  ax.set_xticks(range(len(categories)),xt,rotation=58,ha='right',rotation_mode='anchor')
  ax.set_yticks(range(8),[(('W ' if s=='Women' else 'M ')+a) for s,a in idx] if col==0 else ['']*8)
  ax.tick_params(axis='both',length=0,pad=4)
  ax.axhline(3.5,c='white',lw=2)
  for row in range(8):
   for cc in range(len(categories)):
    v=d.iloc[row,cc]
    if pd.notna(v):ax.text(cc,row,f'{v:.1f}',ha='center',va='center',fontsize=8,color='white' if v<50 else 'black')
  label(ax,'ABC'[col],{'functional':'Functional categories','tug':'TUG categories','balance':'Balance categories'}[ins])
  if col==0:ax.set_ylabel('Sex and age (years); W women, M men')
  ax=fig.add_subplot(gs[1,col]);bottom.append(ax)
  label(ax,'DEF'[col],{'functional':'Dependency risk / dependency','tug':'Mild / high fall risk','balance':'Altered balance'}[ins])
  for sex,(color,mk) in SEX.items():
   d=met[met.instrument.eq(ins)&met.sex.eq(sex)].set_index('age').reindex(AGE_BANDS)
   ax.plot(range(4),d.percent,c=color,marker=mk,label=sex)
  ax.set_xticks(range(4),AGE_BANDS,rotation=40,ha='right');ax.set(ylim=(0,100),xlabel='Age (years)')
  if col==0:ax.set_ylabel('Adverse classified share (%)')
  ax.set_yticks([0,25,50,75,100]);ax.grid(axis='y',c='.9',lw=.5)
  n=int(flow[(flow.year==2025)&flow.instrument.eq(ins)].complete_age_reconciled_facilities.iloc[0])
  ax.text(.03,.97,f'{n:,} age-complete providers',transform=ax.transAxes,va='top',fontsize=8)
 cbax=fig.add_axes([.21,.478,.68,.013]);cb=fig.colorbar(im,cax=cbax,orientation='horizontal',ticks=[0,25,50,75,100]);cb.set_label('Within-age and sex classified share (%)',labelpad=1,fontsize=8)
 fig.legend(handles=[Line2D([],[],c=c,marker=m,label=s) for s,(c,m) in SEX.items()],loc='lower center',bbox_to_anchor=(.5,.025),ncol=2,frameon=False)
 cap='Age and sex composition of functional and mobility classifications in December 2025. A–C: numerical heat maps of within-age, sex and instrument category percentages, with women (W) above men (M). Functional categories are autonomous without risk, autonomous with risk, dependency risk and mild, moderate, severe or total Barthel dependency. TUG categories are normal, mild fall risk and high fall risk; single-leg stance is normal or altered. D–F: adverse-classification shares across the same four age bands, with distinct markers for women and men. The age-reconciled provider samples contain 492 functional, 824 TUG and 899 balance providers before removing zero sex/age denominators; all source age cells must be observed and reconcile to sex totals in every required category. The 80+ band sums 80–84 through 100+ categories. Each instrument has a separate classified-population denominator. These selected under-control shares cannot estimate population prevalence or individual disease progression, and are not neurodegenerative-disease-specific. No missing field is recoded to zero. Source: DEIS REM Series P 2025 and its coded workbook; exact numerators, denominators and provider counts accompany the figure.'
 return export(fig,'NI-P-F2','Figure_NI_P2_age_sex_classifications','Age and sex patterns in recorded functional and mobility classifications',cap,'Six panels show category composition and adverse-classification shares across ages65–69,70–74,75–79 and80+ for women and men in three separate instruments.',str(source.relative_to(ROOT)))

def f3():
 std=pd.read_csv(SOURCE/'2025_region_standardised_shares.csv');weights=pd.read_csv(SOURCE/'2025_standard_age_weights.csv')
 source=OUT/'figures/NI-P-F3_source.csv';std.to_csv(source,index=False)
 boundaries=gpd.read_file(SOURCE/'chile_regions_mainland_utm19s.geojson')
 assert boundaries.crs.to_epsg()==32719
 fig=plt.figure(figsize=(180/25.4,235/25.4))
 gs=fig.add_gridspec(2,3,left=.16,right=.975,bottom=.13,top=.90,wspace=.24,hspace=.19,height_ratios=[1.55,1])
 maps=[];dots=[];norm=Normalize(0,100);cmap=plt.colormaps['cividis']
 minx,miny,maxx,maxy=boundaries.total_bounds
 # All panels retain the complete mainland N–S extent and the same projected
 # aspect. A 250 km scale bar uses metre units in WGS84 / UTM zone19S.
 for col,ins in enumerate(['functional','tug','balance']):
  ax=fig.add_subplot(gs[0,col]);maps.append(ax)
  women=std[std.instrument.eq(ins)&std.sex.eq('Women')]
  geo=boundaries.merge(women[['region','standardised_percent','facilities']],left_on='codregion',right_on='region',how='left',validate='one_to_one')
  geo.plot(column='standardised_percent',ax=ax,cmap=cmap,norm=norm,edgecolor='#4A4A4A',linewidth=.35,missing_kwds={'color':'#EEEEEE','edgecolor':'#666666','hatch':'///'})
  sparse=geo[geo.facilities.lt(5)]
  if len(sparse):sparse.plot(ax=ax,facecolor='none',edgecolor='black',hatch='///',linewidth=.4)
  ax.set_xlim(minx-105000,maxx+105000);ax.set_ylim(miny-150000,maxy+100000);ax.set_aspect('equal');ax.set_axis_off()
  cell=gs[0,col].get_position(fig)
  title={'functional':'Dependency risk /\ndependency','tug':'Mild / high\nTUG fall risk','balance':'Altered\nsingle-leg stance'}[ins]
  fig.text(cell.x0,.982,'ABC'[col]+'  '+title,ha='left',va='top',fontsize=9,fontweight='bold')
  fig.text((cell.x0+cell.x1)/2,.929,'Women; age-standardised',ha='center',va='top',fontsize=8)
  bx=minx+50000;by=miny-70000
  ax.plot([bx,bx+250000],[by,by],color='black',lw=1.2);ax.plot([bx,bx],[by-16000,by+16000],c='black',lw=.8);ax.plot([bx+250000,bx+250000],[by-16000,by+16000],c='black',lw=.8)
  ax.text(bx+125000,by-45000,'250 km',ha='center',va='top',fontsize=8)
  ax.annotate('N',xy=(.11,.82),xytext=(.11,.72),xycoords='axes fraction',textcoords='axes fraction',ha='center',fontsize=8,arrowprops={'arrowstyle':'-|>','lw':.8,'color':'.2'})
  ax=fig.add_subplot(gs[1,col]);dots.append(ax)
  order=list(REGIONS)
  for rnum,reg in enumerate(order):
   d=std[std.instrument.eq(ins)&std.region.eq(reg)].set_index('sex')
   if {'Women','Men'}.issubset(d.index):ax.plot([d.loc['Women','standardised_percent'],d.loc['Men','standardised_percent']],[rnum,rnum],c='.7',lw=.6,zorder=1)
  for sex,(color,mk) in SEX.items():
   d=std[std.instrument.eq(ins)&std.sex.eq(sex)].set_index('region').reindex(order)
   for sparse in [False,True]:
    mask=d.facilities.lt(5).eq(sparse)
    ax.scatter(d.loc[mask,'standardised_percent'],np.arange(16)[mask.to_numpy()],facecolors='white' if sparse else color,marker=mk,s=16,label=sex if not sparse else None,zorder=3,linewidths=.8 if sparse else .45,edgecolors=color if sparse else 'white')
  ax.set_yticks(range(16),[REGIONS[i] for i in order] if col==0 else ['']*16);ax.invert_yaxis();ax.tick_params(axis='y',length=0,pad=5);ax.set(xlim=(0,100),xlabel='Age-standardised share (%)');ax.set_xticks([0,25,50,75,100]);ax.grid(axis='x',color='.9',lw=.5)
  label(ax,'DEF'[col],'Regional sex comparison')
 cbax=fig.add_axes([.31,.075,.62,.012]);sm=plt.cm.ScalarMappable(norm=norm,cmap=cmap);cb=fig.colorbar(sm,cax=cbax,orientation='horizontal',ticks=[0,25,50,75,100]);cb.set_label('Age-standardised adverse-classification share (%)',fontsize=8,labelpad=2)
 fig.legend(handles=[Line2D([],[],ls='',c=c,marker=m,label=s) for s,(c,m) in SEX.items()]+[Patch(facecolor='white',edgecolor='black',hatch='///',label='<5 providers: hatched / open')],loc='lower center',bbox_to_anchor=(.56,.008),ncol=3,frameon=False,columnspacing=1.3)
 cap='Regional functional and mobility classification shares, December 2025. A–C: female choropleths; D–F: female/male comparisons ordered north–south. All panels share 0–100% scales. Direct age standardisation uses 65–69, 70–74, 75–79 and 80+ years and instrument-specific pooled female-plus-male age weights from the national age-reconciled classified sample (492 functional, 824 TUG and 899 balance providers before zero-denominator exclusions). Both sexes in all 16 regions have positive denominators in all four age bands. Weights, counts and crude comparisons are retained in the source tables and Table NI-P-T6. Hatching/open markers flag fewer than five providers; all values remain. Aysén functional counts come from one provider (18 female, 14 male); Arica y Parinacota uses four. Selected under-control shares do not estimate population prevalence or accessibility. Source: DEIS REM 2025 and BCN Mapoteca. Mainland boundaries use EPSG:32719 and 250-km scale bars; oceanic and Antarctic territories are omitted.'
 return export(fig,'NI-P-F3','Figure_NI_P3_standardised_chile_maps','Chile maps and regional age-standardised classifications',cap,'Three mainland Chile maps show female age-standardised adverse-classification shares, and three adjacent regional dot plots compare women and men for functional dependency risk, TUG fall risk and altered balance.',str(source.relative_to(ROOT)))

def run():
 style();(OUT/'figures').mkdir(exist_ok=True)
 figures=[f1(),f2(),f3()]
 p=OUT/'analysis_bundle.json';bundle=json.loads(p.read_text());bundle['figures']=figures;p.write_text(json.dumps(bundle,indent=2,ensure_ascii=False))
 manifest={'width_mm':180,'dpi':600,'font':'Arial','font_points':{'body':8.5,'ticks':8,'panels':9,'cell_values':8},'python':platform.python_version(),'matplotlib':matplotlib.__version__,'geopandas':gpd.__version__,'figures':[{**f,'sha256_png':digest(ROOT/f['path_png']),'sha256_pdf':digest(ROOT/f['path_pdf']),'sha256_svg':digest(ROOT/f['path_svg'])} for f in figures],'status':'Exports complete; manual visual inspection required'}
 (OUT/'figure_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False));print(json.dumps({'figures':len(figures),'bundle':str(p.relative_to(ROOT))},indent=2))
 return figures

if __name__=='__main__':run()
