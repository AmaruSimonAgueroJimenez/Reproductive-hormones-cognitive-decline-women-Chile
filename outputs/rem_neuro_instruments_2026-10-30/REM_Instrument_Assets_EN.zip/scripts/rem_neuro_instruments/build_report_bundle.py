"""Bind the two independently analysed REM components to one display evidence set."""
from __future__ import annotations

import json
from pathlib import Path

from report_render import content_hash, file_sha, load_instrument_bundle, CONTEXT

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/rem_neuro_instruments_2026-10-30"


def build():
    components = [(OUT / name / "analysis_bundle.json") for name in ["analysis_p", "analysis_a"]]
    parts = [json.loads(path.read_text()) for path in components]
    data = {"schema_version": 1, "revision_date": "2026-10-30", "language": "en",
            "title": "Functional status dementia reassessment and caregiver recording in Chile",
            "methods": [{"title": "Source definitions and complementary observation units", "paragraphs": [
                "We extended the multisource study with REM functional classifications, mobility assessments, dementia programme reassessments and caregiver measures. Definitions and annual field mappings were obtained from the [DEIS annual REM files and coded dictionaries](https://deis.minsal.cl/#datosabiertos), the [REM Series A manual](https://repositoriodeis.minsal.cl/ContenidoSitioWeb2020/REM/2025/SERIE/Manual_Series_REM_2025_2026_SERIE_A_BS_BM_D_V1.3.pdf) and the [REM Series P manual](https://repositoriodeis.minsal.cl/ContenidoSitioWeb2020/REM/2025/SERIE/MANUAL_REM_P_2025_V1.1.pdf). The seven annual coded templates were checked individually for 2019–2025; a manual description alone was not treated as evidence of a standalone data field.",
                "Series P describes populations recorded under control at the December cut-off; Series A records activities during reporting months. Instrument-specific classifications and activity counts were analysed separately. The data do not establish raw cognitive scores, individual progression, dementia incidence, treatment effectiveness or patient-level linkage between menopause care and neurodegeneration. Functional dependence, fall risk and depression measures were retained as complementary clinical context rather than neurodegenerative diagnoses."
            ]}], "results": [], "tables": [], "figures": [], "report_introductions": CONTEXT,
            "component_evidence": [{"path": str(path.relative_to(ROOT)), "sha256": file_sha(path)} for path in components]}
    for part in parts:
        for key in ["methods", "results", "tables", "figures"]:
            data[key].extend(part[key])
    data["results"].append({"title": "Relationship to the reproductive and diagnostic recording analyses", "paragraphs": [
        "These findings add complementary information to the original recorded neurodegenerative burden, reproductive-history analyses and menopause-care context. The functional and mobility distributions identify the classifications observed among people under control, while dementia reassessment and caregiver measures describe activity among selected reporting programmes. Differences in provider completeness, observation units and patient composition limit direct comparisons between instruments.",
        "The new REM results do not add an individual-level test of hormone exposure and cognitive decline. Shared provider or regional patterns can support a subsequent ecological analysis with explicit denominator and reporting checks, but cannot establish that the same women received menopause treatment and subsequently experienced a neurodegenerative outcome. No new hormonal association model was fitted in this extension."
    ], "table_ids": [], "figure_ids": []})
    paths = set()
    for kind in ["tables", "figures"]:
        for item in data[kind]:
            for key in ["path_png", "path_pdf", "path_svg"]:
                if item.get(key): paths.add(item[key])
            sources = item.get("source_csv", [])
            paths.update([sources] if isinstance(sources, str) else sources)
    data["file_hashes"] = [{"path": path, "sha256": file_sha(ROOT / path)} for path in sorted(paths)]
    data["arithmetic_checks"] = [
        {"id": "P5 annual complete-category denominators", "type": "grouped_category_sum",
         "source_csv": "outputs/rem_neuro_instruments_2026-10-30/analysis_p/source_data/annual_category_composition.csv",
         "group_columns": ["year", "instrument", "sex"], "count_column": "n", "denominator_column": "classified_n", "percent_column": "percent", "absolute_tolerance": 1e-6},
        {"id": "P5 age-specific complete-category denominators", "type": "grouped_category_sum",
         "source_csv": "outputs/rem_neuro_instruments_2026-10-30/analysis_p/source_data/2025_age_category_composition.csv",
         "group_columns": ["year", "instrument", "sex", "age"], "count_column": "n", "denominator_column": "classified_n", "percent_column": "percent", "absolute_tolerance": 1e-6},
        *[{"id": identifier, "type": "grouped_category_sum", "source_csv": "outputs/rem_neuro_instruments_2026-10-30/analysis_a/source_data/" + filename,
           "group_columns": ["year", "measure", "sex"], "count_column": "recorded_evaluations", "denominator_column": "denominator", "percent_column": "percent", "absolute_tolerance": 1e-6}
          for identifier, filename in [("Dementia reassessment category denominators", "a06_change_categories.csv"),
                                       ("Functional change category denominators", "functional_change_categories.csv"),
                                       ("Zarit paired-category denominators", "zarit_categories.csv")]],
    ]
    for check in data["arithmetic_checks"]:
        if check["id"] == "Dementia reassessment category denominators":
            check["allow_zero_denominator"] = True
    data["content_sha256"] = content_hash(data)
    (OUT / "report_bundle.json").write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False))
    load_instrument_bundle(ROOT)
    print(json.dumps({"content_sha256": data["content_sha256"], "tables": len(data["tables"]), "figures": len(data["figures"])}))
    return data


if __name__ == "__main__":
    build()
