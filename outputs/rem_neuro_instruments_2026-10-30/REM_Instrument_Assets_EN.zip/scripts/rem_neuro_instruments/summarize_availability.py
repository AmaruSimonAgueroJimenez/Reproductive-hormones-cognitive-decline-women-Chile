"""Combine separately checked REM A/P availability, not clinical outcomes."""
from pathlib import Path
import json
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/rem_neuro_instruments_2026-10-30"


def years(values):
    return ";".join(map(str, sorted(set(int(v) for v in values))))


def run():
    a = pd.read_csv(OUT / "a_data_audit/annual_code_availability.csv", dtype={"code": str})
    mapping = pd.read_csv(OUT / "a_dictionary_audit/annual_code_inventory.csv", dtype={"code": str})
    a = a.merge(mapping[["year", "code", "instrument"]].drop_duplicates(), on=["year", "code"], how="left", validate="one_to_one")
    a = a[a.mapped_in_annual_template].copy()
    p = pd.read_csv(OUT / "p_series_audit/annual_source_presence.csv", dtype={"code": str})
    rows = []
    for (instrument, code), g in a.groupby(["instrument", "code"]):
        rows.append({"series": "A", "record_type": "Monthly recorded activity", "instrument_or_context": instrument, "code": code,
                     "years_with_coded_template_row": years(g.year), "years_with_source_rows": years(g.loc[g.raw_rows > 0, "year"]),
                     "years_with_positive_mapped_cells": years(g.loc[g.rows_with_positive_active_cell > 0, "year"]),
                     "latest_year_checked": int(g.year.max()), "interpretation": "Availability only; monthly records are not unique people"})
    for (instrument, code), g in p.groupby(["group", "code"]):
        rows.append({"series": "P", "record_type": "December under-control snapshot", "instrument_or_context": instrument, "code": code,
                     "years_with_coded_template_row": years(g.loc[g.template_coded_row_present, "year"]),
                     "years_with_source_rows": years(g.loc[g.december_source_rows > 0, "year"]),
                     "years_with_positive_mapped_cells": years(g.loc[g.Col01_december_positive_rows > 0, "year"]),
                     "latest_year_checked": int(g.year.max()), "interpretation": "Availability only; snapshots must not be summed as unique people"})
    result = pd.DataFrame(rows).sort_values(["series", "instrument_or_context", "code"])
    result.to_csv(OUT / "Instrument_Data_Availability_EN.csv", index=False)
    private = Path("/Volumes/Datos/Asesorias_Data/derived/Reproductive-hormones-cognitive-decline-women-Chile/rem_neuro_instruments")
    keys = ["Ano", "Mes", "IdServicio", "IdEstablecimiento", "CodigoPrestacion"]
    duplicate_rows = []
    for year in range(2019, 2026):
        frame = pd.read_csv(private / f"instrument_selected_A_{year}.csv.gz", dtype=str, keep_default_na=False)
        for key, group in frame[frame.duplicated(keys, keep=False)].groupby(keys):
            duplicate_rows.append({"year": year, "month": key[1], "code": key[4], "source_rows": len(group),
                                   "distinct_full_rows": len(group.drop_duplicates()),
                                   "conflict_after_exact_deduplication": len(group.drop_duplicates()) > 1,
                                   "differing_columns": ";".join(c for c in frame.columns if group[c].nunique() > 1)})
    pd.DataFrame(duplicate_rows).to_csv(OUT / "a_data_audit/duplicate_key_audit.csv", index=False)
    receipt = {"scope": "Code-level data discovery, 2019-2025; no clinical estimates", "inventory_code_rows": len(result),
               "a_annual_active_mappings": len(mapping), "a_selected_rows_scanned": int(a.raw_rows.sum()),
               "p_annual_code_checks": len(p), "a_conflicting_duplicate_keys": sum(x["conflict_after_exact_deduplication"] for x in duplicate_rows),
               "warnings": ["Source values were not corrected or excluded.", "Review the 2021 GDS/caregiver anomaly before using these series.",
                            "Mapped-column and age changes require annual harmonisation.", "No patient-level linkage or raw cognitive scores have been established."]}
    (OUT / "availability_receipt.json").write_text(json.dumps(receipt, indent=2))
    print(json.dumps(receipt))


if __name__ == "__main__":
    run()
