"""Verify the shared instrument evidence in native Word and executed HTML."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import zipfile

from lxml import etree

from report_render import load_instrument_bundle, normalize, validate_arithmetic_checks, validate_instrument_html

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs/rem_neuro_instruments_2026-10-30"
REPORTS = {
    "descriptive": ("manuscript/revision_descriptiva_2026-10-28/Methods_Results_EN.docx", "docs/descriptive_methods_results.html"),
    "connected": ("manuscript/publication_programme_2026-10-28/Connected_Reproductive_Neurodegenerative_Results_EN.docx", "docs/reproductive_life_course.html"),
    "access": ("manuscript/access_diagnostic_extension_2026-10-29/Methods_Results_EN.docx", "docs/access_diagnostic_recording_extension.html"),
}
NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}


def text(node):
    return "".join(node.xpath(".//w:t/text()", namespaces=NS))


def table_rows(table):
    return [[normalize(text(cell)) for cell in row.xpath("./w:tc", namespaces=NS)] for row in table.xpath("./w:tr", namespaces=NS)]


def read(path):
    with zipfile.ZipFile(path) as archive:
        tree = etree.fromstring(archive.read("word/document.xml"))
        media = {name: hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist() if name.startswith("word/media/")}
    return tree, media


def validate_word_report(path, bundle=None):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    bundle = bundle or load_instrument_bundle(ROOT)
    relative = path.relative_to(ROOT)
    baseline = OUT / "report_revision/backups" / relative
    actual, media = read(path)
    original, original_media = read(baseline)
    bookmark = actual.xpath("//w:bookmarkStart[@w:name='REMInstrumentExtension']", namespaces=NS)
    assert len(bookmark) == 1, "One instrument extension is required"
    old_paragraphs = [normalize(text(p)) for p in original.xpath("//w:body/w:p", namespaces=NS) if text(p).strip()]
    actual_paragraphs = [normalize(text(p)) for p in actual.xpath("//w:body/w:p", namespaces=NS) if text(p).strip()]
    assert actual_paragraphs[:len(old_paragraphs)] == old_paragraphs, "The original scientific prose changed"
    original_tables = original.xpath("//w:tbl", namespaces=NS)
    actual_tables = actual.xpath("//w:tbl", namespaces=NS)
    assert len(actual_tables) == len(original_tables) + len(bundle["tables"])
    for expected, observed in zip(original_tables, actual_tables):
        assert table_rows(expected) == table_rows(observed), "An original table changed"
    for name, digest in original_media.items():
        assert media[name] == digest, "An original figure changed"
    all_text = normalize(" ".join(actual_paragraphs))
    for section in [*bundle["methods"], *bundle["results"]]:
        for paragraph in section["paragraphs"]:
            assert normalize(paragraph.replace("**", "")) in all_text, section["title"]
    cells = 0
    for table, expected in zip(actual_tables[len(original_tables):], bundle["tables"]):
        rows = [[normalize(str(value)) for value in row] for row in [expected["columns"], *expected["rows"]]]
        assert table_rows(table) == rows, expected["id"]
        cells += sum(map(len, rows))
        assert normalize("Table " + expected["id"] + ". " + expected["title"]) in all_text
    for figure in bundle["figures"]:
        assert hashlib.sha256((ROOT / figure["path_png"]).read_bytes()).hexdigest() in media.values(), figure["id"]
        assert normalize(figure["caption"]) in all_text, figure["id"]
    sections = actual.xpath("//w:sectPr", namespaces=NS)
    assert all(section.xpath("./w:lnNumType/@w:restart", namespaces=NS) == ["continuous"] for section in sections)
    assert not any(section.xpath("./w:lnNumType/@w:start", namespaces=NS) for section in sections[1:])
    return {"path": str(relative), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "status": "PASS",
            "original_prose_blocks_preserved": len(old_paragraphs), "original_tables_preserved": len(original_tables),
            "original_figure_files_preserved": len(original_media), "new_tables": len(bundle["tables"]),
            "new_table_cells_verified": cells, "new_figures_verified": len(bundle["figures"]),
            "all_new_methods_and_results_match": True, "continuous_line_numbering": True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--word", action="store_true")
    parser.add_argument("--html", action="store_true")
    args = parser.parse_args()
    bundle = load_instrument_bundle(ROOT)
    result = {"instrument_content_sha256": bundle["content_sha256"], "aggregate_arithmetic": validate_arithmetic_checks(ROOT, bundle)}
    if args.word:
        result["word"] = [validate_word_report(ROOT / paths[0], bundle) for paths in REPORTS.values()]
    if args.html:
        result["html"] = [validate_instrument_html(ROOT, ROOT / paths[1]) for paths in REPORTS.values()]
    (OUT / "report_revision/content_validation.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
