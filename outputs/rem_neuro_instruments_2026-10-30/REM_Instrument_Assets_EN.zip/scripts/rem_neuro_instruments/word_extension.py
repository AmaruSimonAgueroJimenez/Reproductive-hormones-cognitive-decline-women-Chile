"""Append the shared scientific instrument evidence to reviewed English reports.

The existing pages, figures and numerical tables are preserved. The new methods,
results, native tables and original figure PNGs share one bundle with Quarto.
Run with the bundled document Python after the DOCX operation marker.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
import build_descriptive_docx as core
from docx import Document
from docx.enum.section import WD_SECTION_START
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.shared import Pt

OUT = ROOT / "outputs/rem_neuro_instruments_2026-10-30"
REPORTS = {
    "descriptive": "manuscript/revision_descriptiva_2026-10-28/Methods_Results_EN.docx",
    "connected": "manuscript/publication_programme_2026-10-28/Connected_Reproductive_Neurodegenerative_Results_EN.docx",
    "access": "manuscript/access_diagnostic_extension_2026-10-29/Methods_Results_EN.docx",
}


def plain(text):
    return re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r"\1", str(text))


def paragraph(doc, text, **kwargs):
    """Preserve visible scientific prose and native external citations."""
    p = core.paragraph(doc, plain(text), **kwargs)
    links = dict(re.findall(r"\[([^\]]+)\]\((https?://[^\s)]+)\)", str(text)))
    if not links:
        return p
    pattern = re.compile("(" + "|".join(re.escape(x) for x in sorted(links, key=len, reverse=True)) + ")")
    parts = pattern.split(p.text)
    p.clear()
    for part in parts:
        if part not in links:
            core.font(p.add_run(part), size=kwargs.get("size", 12))
            continue
        hyperlink = OxmlElement("w:hyperlink")
        hyperlink.set(qn("r:id"), p.part.relate_to(links[part], RT.HYPERLINK, is_external=True))
        run = OxmlElement("w:r")
        props = OxmlElement("w:rPr")
        fonts = OxmlElement("w:rFonts")
        for key in ["ascii", "hAnsi", "eastAsia", "cs"]:
            fonts.set(qn("w:" + key), core.FONT)
        props.append(fonts)
        for tag, value in [("sz", "24"), ("color", "000000")]:
            item = OxmlElement("w:" + tag)
            item.set(qn("w:val"), value)
            props.append(item)
        run.append(props)
        element = OxmlElement("w:t")
        element.text = part
        run.append(element)
        hyperlink.append(run)
        p._p.append(hyperlink)
    return p


def append_one(report, bundle, *, base_path=None):
    path = ROOT / REPORTS[report]
    original = base_path or OUT / "report_revision/backups" / REPORTS[report]
    assert original.is_file(), f"An original report must be preserved first: {original}"
    doc = Document(original)
    original_table_count = len(doc.tables)
    with zipfile.ZipFile(original) as z:
        original_media = {n: hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith("word/media/")}
    new = doc.add_section(WD_SECTION_START.NEW_PAGE)
    core.configure_section(new, landscape=False, figures=False)
    new.footer.is_linked_to_previous = True
    start = paragraph(doc, "Additional methods for REM instruments", style="Heading 1", size=12, bold=True)
    bookmark = OxmlElement("w:bookmarkStart")
    bookmark.set(qn("w:id"), "9001")
    bookmark.set(qn("w:name"), "REMInstrumentExtension")
    start._p.insert(0, bookmark)
    bookmark_end = OxmlElement("w:bookmarkEnd")
    bookmark_end.set(qn("w:id"), "9001")
    start._p.append(bookmark_end)
    for section in bundle["methods"]:
        paragraph(doc, section["title"], style="Heading 2", size=12, bold=True)
        for text in section["paragraphs"]:
            paragraph(doc, text)
    paragraph(doc, "Additional results from REM instruments", style="Heading 1", size=12, bold=True)
    intro = bundle.get("report_introductions", {}).get(report)
    if intro:
        paragraph(doc, intro)
    for section in bundle["results"]:
        paragraph(doc, section["title"], style="Heading 2", size=12, bold=True)
        for text in section["paragraphs"]:
            paragraph(doc, text)
    for table in bundle["tables"]:
        entry = copy.deepcopy(table)
        entry["number"] = entry["id"]
        entry.setdefault("landscape", len(entry["columns"]) >= 6)
        preceding_note = entry.pop("note", "") if entry["id"] == "NI-P-T2" else ""
        if preceding_note:
            entry["note"] = ""
            entry["vertical_padding_twips"] = 75
        core.add_table(doc, entry, "en")
        if preceding_note:
            note = paragraph(doc, preceding_note, style="Caption", size=10)
            note.paragraph_format.keep_with_next = True
            note.paragraph_format.keep_together = True
            doc.tables[-1]._tbl.addprevious(note._p)
    figures = []
    for figure in bundle["figures"]:
        entry = copy.deepcopy(figure)
        entry["number"] = entry["id"]
        entry["path"] = entry["path_png"]
        core.add_figure(doc, entry, "en", figures)
    doc.core_properties.subject = (doc.core_properties.subject or "Reviewed original evidence") + "; REM instrument extension " + bundle["content_sha256"]
    doc.save(path)
    with zipfile.ZipFile(path) as z:
        for name, digest in original_media.items():
            assert hashlib.sha256(z.read(name)).hexdigest() == digest, name
    assert len(doc.tables) == original_table_count + len(bundle["tables"])
    receipt = {
        "report": report, "path": REPORTS[report], "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "original_path": str(original.relative_to(ROOT)), "original_sha256": hashlib.sha256(original.read_bytes()).hexdigest(),
        "instrument_content_sha256": bundle["content_sha256"], "original_tables": original_table_count,
        "additional_tables": len(bundle["tables"]), "additional_figures": figures,
        "original_media_preserved_exactly": True, "continuous_line_numbering": True,
    }
    return receipt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", choices=[*REPORTS, "all"], default="all")
    args = parser.parse_args()
    from report_render import load_instrument_bundle
    bundle = load_instrument_bundle(ROOT)
    reports = list(REPORTS) if args.report == "all" else [args.report]
    receipts = [append_one(report, bundle) for report in reports]
    (OUT / "report_revision/word_extension_manifest.json").write_text(json.dumps(receipts, indent=2))
    print(json.dumps([{"report": r["report"], "additional_tables": r["additional_tables"], "additional_figures": len(r["additional_figures"])} for r in receipts]))


if __name__ == "__main__":
    main()
