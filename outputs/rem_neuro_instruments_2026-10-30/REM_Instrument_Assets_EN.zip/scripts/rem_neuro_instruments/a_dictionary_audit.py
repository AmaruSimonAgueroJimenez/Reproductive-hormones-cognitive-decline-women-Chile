"""Read-only audit of locally held official REM A annual coded templates.

The output documents active coded fields, not whether a facility submitted data.
Original Spanish cell values are retained as source evidence; analytical labels
and notes are English. Raw annual CSV presence is a separate check.
"""
from pathlib import Path
import csv
import hashlib
import json
import os
import re
import unicodedata
import warnings
import openpyxl

ROOT = Path(__file__).resolve().parents[2]
DATA = Path(os.environ.get("ASESORIAS_DATA_ROOT", "/Volumes/Datos/Asesorias_Data"))
OUT = ROOT / "outputs/rem_neuro_instruments_2026-10-30/a_dictionary_audit"

def norm(v):
    return " ".join(str(v).split()) if v is not None else ""

def fold(v):
    return "".join(c for c in unicodedata.normalize("NFD", norm(v).lower()) if unicodedata.category(c) != "Mn")

def code(v):
    return str(int(v)).zfill(8) if isinstance(v, (int, float)) else norm(v)

def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

GROUPS = {
    "dementia_gds_reisberg": ["06906135"],
    "dementia_caregiver_burden_change": ["06906140"],
    "dementia_caregiver_satisfaction_change": ["06906145"],
    "timed_up_and_go_change": [f"0350035{i}" for i in range(3)],
    "functional_questionnaire_change": [f"0350035{i}" for i in range(3, 6)],
    "hospital_barthel_change": [f"0350035{i}" for i in range(6, 9)],
    "zarit_abbreviated_severe_dependency_caregivers": ["03500361", "03500362"],
    "zarit_naneas_caregivers_distinct_scope": ["03710011", "03710012"],
    "ivadec_origin_severity": ["03051000A"] + [f"0305{i}00" for i in range(11, 40)],
    "ivadec_entry_exit_severity": [f"035003{i}" for i in range(36, 46)],
    "yesavage_application_count": ["09600226"],
    "shared_mental_health_risk_results_not_yesavage_specific": ["09600227", "09600228", "09600229"],
    "empam_functional_programme_entries": ["05021207", "05021208", "05120900"],
    "empam_functional_programme_exits": ["05050700", "05050800", "05050900"],
    "barthel_programme_entries": ["05130100", "05130200", "05130300", "05810100"],
    "barthel_programme_exits": ["05051000", "05051100", "05051200", "05051300"],
    "yesavage_post_screening_counselling": ["29101573"],
    "yesavage_post_screening_assisted_referral": ["29101581"],
}
LOOKUP = {c: g for g, codes in GROUPS.items() for c in codes}

def cells(row, number, end=55):
    return [{"cell": f"{openpyxl.utils.get_column_letter(j + 1)}{number}", "value": norm(c.value)}
            for j, c in enumerate(row[:end]) if c.value is not None]

def run():
    OUT.mkdir(parents=True, exist_ok=True)
    records, inventory, files, name_search = [], [], [], []
    for year in range(2019, 2026):
        paths = [p for p in (DATA / f"REM/SerieA/metadata/diccionarios/{year}").glob("*")
                 if re.search(r"(^|[ _])SA[ _-]", p.name, re.I) and p.suffix in [".xlsx", ".xlsm"]]
        assert len(paths) == 1, (year, paths)
        path = paths[0]
        digest = sha(path)
        files.append({"year": year, "source": str(path), "source_file": path.name,
                      "bytes": path.stat().st_size, "sha256": digest})
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            book = openpyxl.load_workbook(path, read_only=True, data_only=True)
            for sn in book.sheetnames:
                rows = list(book[sn].iter_rows())
                for i, r in enumerate(rows):
                    txt = " ".join(norm(x.value) for x in r[:12] if x.value is not None)
                    if re.search(r"\bmmse\b|\bmoca\b|pfeffer|folstein|mini[ -]?mental|\bnpi\b|cambio percibido", fold(txt)):
                        name_search.append({"year": year, "sheet": sn, "row": i + 1, "cells": cells(r, i + 1), "source_file": path.name})
                if sn not in ["A03", "A05", "A06", "A27"]:
                    continue
                section, header_start = "", 0
                for i, r in enumerate(rows):
                    vals = [c.value for c in r]
                    b = fold(vals[1] if len(vals) > 1 else "")
                    if re.search(r"secc?ion", b):
                        section = norm(vals[1]); header_start = i
                    c = code(vals[0])
                    if c not in LOOKUP:
                        continue
                    coded = []
                    for j, cell in enumerate(r):
                        if re.fullmatch(r"COL\d{2}", norm(cell.value)):
                            coded.append({"cell": f"{openpyxl.utils.get_column_letter(j + 1)}{i + 1}",
                                          "value": norm(cell.value), "locked": cell.protection.locked,
                                          "fill_colour_type": cell.fill.fgColor.type,
                                          "fill_colour": cell.fill.fgColor.index})
                    if not coded:
                        continue  # Deleted/reference appearances are not active fields.
                    headers = [{"row": k + 1, "cells": cells(rows[k], k + 1)}
                               for k in range(header_start, i) if not any(re.fullmatch(r"COL\d{2}", norm(x.value)) for x in rows[k])]
                    preceding = [{"row": k + 1, "cells": cells(rows[k], k + 1)} for k in range(max(header_start, i - 4), i)]
                    item = {"year": year, "sheet": sn, "code": c, "instrument": LOOKUP[c],
                            "source_label": " | ".join(norm(x) for x in vals[1:4] if x is not None and not re.fullmatch(r"COL\d{2}", norm(x))),
                            "section": section, "row": i + 1, "source_file": path.name, "source_sha256": digest,
                            "data_cells": coded, "section_header_and_noncoded_context": headers,
                            "preceding_rows": preceding}
                    records.append(item)
                    inventory.append({k: item[k] for k in ["year", "sheet", "code", "instrument", "source_label", "section", "row", "source_file", "source_sha256"]} |
                                     {"coded_columns": ";".join(x["value"].replace("COL", "Col") for x in coded),
                                      "coded_column_count": len(coded)})
            book.close()
    assert len({(x["year"], x["sheet"], x["code"]) for x in records}) == len(records)
    proof = {"scope": "Official annual local Series A coded templates, 2019–2025; active coded fields only",
             "not_a_data_presence_audit": True, "files": files, "records": records,
             "targeted_instrument_name_search_all_sheets": name_search}
    (OUT / "annual_mapping_proof.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2))
    with (OUT / "annual_code_inventory.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(inventory[0])); w.writeheader(); w.writerows(inventory)
    presence = []
    for g, codes in GROUPS.items():
        for year in range(2019, 2026):
            obs = sorted({x["code"] for x in records if x["instrument"] == g and x["year"] == year})
            presence.append({"year": year, "instrument": g, "active_code_count": len(obs), "active_codes": ";".join(obs),
                             "active_columns": ";".join(sorted({str(len(x["data_cells"])) for x in records if x["instrument"] == g and x["year"] == year}))})
    with (OUT / "instrument_year_template_presence.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(presence[0])); w.writeheader(); w.writerows(presence)
    print(json.dumps({"annual_files": len(files), "active_code_year_records": len(records),
                      "candidate_code_count": len(LOOKUP), "output": str(OUT),
                      "targeted_name_search_matches": len(name_search)}, indent=2))

if __name__ == "__main__":
    run()
