"""Reproduce the REM instrument extension from retained aggregate evidence.

Default processing rebuilds scientific tables, prose and figures without reading
the external source volume. --refresh-raw additionally audits/extracts original
REM files and refreshes the aggregate inputs. Existing report regeneration needs
the complete parent project. Documents use the bundled document runtime.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/rem_neuro_instruments_2026-10-30"
MODULES = ROOT / "scripts/rem_neuro_instruments"
sys.path.insert(0, str(MODULES))


def run(script, *args, python=None):
    subprocess.run([str(python or sys.executable), str(ROOT / script), *args], cwd=ROOT, check=True)


def archive():
    """Only the new aggregate evidence, analysis sources and scientific assets."""
    include = [OUT / "report_bundle.json"]
    include += list(MODULES.glob("*.py"))
    include += [ROOT / "scripts/run_rem_instrument_extension.py", ROOT / "scripts/build_descriptive_docx.py"]
    for component in ["analysis_a", "analysis_p"]:
        directory = OUT / component
        include += [p for subdir in ["source_data", "tables", "figures"] for p in (directory / subdir).rglob("*")
                    if p.is_file() and p.suffix in {".csv", ".json", ".geojson", ".png", ".svg", ".pdf"}
                    and "_preview" not in p.stem and "_QA" not in p.stem]
        include += [p for p in directory.glob("*.json") if p.name in {"analysis_bundle.json", "analysis_validation.json", "validation.json", "offline_aggregate_validation.json"}]
    include += [p for p in [OUT / "INSTRUMENT_REBUILD_EN.txt", OUT / "Instrument_Data_Findings_EN.txt", OUT / "Instrument_Data_Availability_EN.csv", OUT / "SCIENTIFIC_ENVIRONMENT_EN.json", OUT / "requirements-scientific.txt"] if p.exists()]
    entries = []
    target = OUT / "REM_Instrument_Assets_EN.zip"
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for path in sorted(set(include)):
            relative = str(path.relative_to(ROOT))
            data = path.read_bytes()
            z.writestr(relative, data)
            entries.append({"path": relative, "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
        z.writestr("instrument_source_package_manifest.json", json.dumps({"scope": "Aggregate inputs and code for the new instrument extension; no original source-record cache", "files": entries}, indent=2))
    return {"path": str(target.relative_to(ROOT)), "files": len(entries) + 1, "bytes": target.stat().st_size, "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}


def word(marker_recorded):
    dependencies = Path.home() / ".cache/codex-runtimes/codex-primary-runtime/dependencies"
    python = Path(os.environ.get("DOCX_PYTHON", str(dependencies / "python/bin/python3")))
    node = dependencies / "node/bin/node"
    if not python.is_file():
        raise FileNotFoundError("Set DOCX_PYTHON to the document environment identified by the workspace dependency loader")
    if not marker_recorded:
        marker = dependencies.parent / "plugins/openai-primary-runtime/plugins/documents/skills/documents/container_tools/mark_artifact_operation_started.mjs"
        subprocess.run([str(node), str(marker), "--operation-kind", "edit", "--expected-output-count", "3", "--output-format", "docx"], cwd=ROOT, check=True)
    from word_extension import REPORTS
    # Preserve the reviewed originals. If a reproduction checkout has no saved
    # originals, rebuild its base reports from their existing frozen evidence.
    backup = OUT / "report_revision/backups"
    if not all((backup / relative).is_file() for relative in REPORTS.values()):
        for script, args in [("scripts/build_descriptive_docx.py", ["--lang", "en"]),
                             ("scripts/publication_programme/build_integrated_docx.py", []),
                             ("scripts/access_extension/build_access_docx.py", [])]:
            run(script, *args, python=python)
        for relative in REPORTS.values():
            source, destination = ROOT / relative, backup / relative
            if not destination.exists():
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, destination)
    run("scripts/rem_neuro_instruments/word_extension.py", python=python)


def html():
    env = os.environ.copy()
    env["QUARTO_PYTHON"] = sys.executable
    for name in ["descriptive_methods_results", "reproductive_life_course", "access_diagnostic_recording_extension"]:
        subprocess.run(["quarto", "render", f"docs/{name}.qmd", "--to", "html", "--execute", "--no-cache", "--execute-daemon", "0"], cwd=ROOT, env=env, check=True)
        shutil.copy2(ROOT / "_site/docs" / f"{name}.html", ROOT / "docs" / f"{name}.html")
    subprocess.run(["quarto", "render", "index.qmd", "--to", "html"], cwd=ROOT, env=env, check=True)
    shutil.copy2(ROOT / "_site/index.html", ROOT / "index.html")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--refresh-raw", action="store_true")
    parser.add_argument("--word", action="store_true")
    parser.add_argument("--html", action="store_true")
    parser.add_argument("--artifact-marker-already-recorded", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--package-only", action="store_true")
    args = parser.parse_args()
    if not args.package_only:
        if args.refresh_raw:
            for script in ["a_dictionary_audit.py", "p_inventory.py"]:
                run("scripts/rem_neuro_instruments/" + script)
            run("scripts/rem_neuro_instruments/profile_a_data.py", "outputs/rem_neuro_instruments_2026-10-30/a_dictionary_audit/annual_code_inventory.csv")
            run("scripts/rem_neuro_instruments/anomaly_checks.py")
        mode = "--refresh-raw" if args.refresh_raw else "--from-aggregates"
        for prefix in ["p", "a"]:
            run(f"scripts/rem_neuro_instruments/{prefix}_analysis.py", mode)
            run(f"scripts/rem_neuro_instruments/{prefix}_figures.py")
        run("scripts/rem_neuro_instruments/build_report_bundle.py")
        from integrate_qmd import install_all, REPORTS
        if all((ROOT / relative).is_file() for relative in REPORTS.values()):
            install_all(ROOT)
        elif args.html:
            raise FileNotFoundError("HTML regeneration requires the complete parent project and its three executable report sources")
    package = archive()
    if args.word:
        word(args.artifact_marker_already_recorded)
    if args.html:
        html()
    (OUT / "report_revision").mkdir(exist_ok=True)
    (OUT / "report_revision/reproduction_receipt.json").write_text(json.dumps({"source_refresh": args.refresh_raw, "word_rebuilt": args.word, "html_rebuilt": args.html, "package": package}, indent=2))
    print(json.dumps(package))


if __name__ == "__main__":
    main()
