"""Build the reviewed ES/EN Methods and Results DOCX files from review_bundle.json.

Run only with the bundled Codex Python, after the authoring marker has been emitted.
The source bundle is produced independently by the scientific review. This builder
does not rewrite scientific content or recompute analyses.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import re
from pathlib import Path

import docx
from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION_START
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Mm, Pt, RGBColor
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
BUNDLE = ROOT / "outputs/paper/revision_descriptiva_2026-10-28/review_bundle.json"
DEST = ROOT / "manuscript/revision_descriptiva_2026-10-28"
FONT = "Times New Roman"


def font(run, size=None, bold=None, italic=None):
    run.font.name = FONT
    props = run._element.get_or_add_rPr()
    fonts = props.find(qn("w:rFonts"))
    if fonts is None:
        fonts = OxmlElement("w:rFonts")
        props.insert(0, fonts)
    for key in ["ascii", "hAnsi", "eastAsia", "cs"]:
        fonts.set(qn(f"w:{key}"), FONT)
    run.font.color.rgb = RGBColor(0, 0, 0)
    if size is not None:run.font.size = Pt(size)
    if bold is not None:run.bold = bold
    if italic is not None:run.italic = italic


def element(parent, tag, **attrs):
    child = OxmlElement("w:" + tag)
    for key, value in attrs.items():child.set(qn("w:" + key), str(value))
    parent.append(child)
    return child


def configure_section(section, landscape=False, figures=False, first=False):
    section.orientation = WD_ORIENT.LANDSCAPE if landscape else WD_ORIENT.PORTRAIT
    section.page_width = Mm(297 if landscape else 210)
    section.page_height = Mm(210 if landscape else 297)
    section.left_margin = section.right_margin = Mm(20)
    section.top_margin = section.bottom_margin = Mm(12 if figures else 20)
    section.header_distance = Mm(7)
    section.footer_distance = Mm(8)
    sp = section._sectPr
    for tag in ["lnNumType", "pgNumType"]:
        for old in list(sp.findall(qn("w:" + tag))):sp.remove(old)
    ln=OxmlElement("w:lnNumType")
    attrs={"countBy":"1","restart":"continuous","distance":"180"}
    if first:attrs["start"]="1"
    for key,value in attrs.items():ln.set(qn("w:"+key),value)
    # CT_SectPr order: line numbering precedes page numbering, columns and grid.
    sp.insert_element_before(ln,"w:pgNumType","w:cols","w:formProt","w:vAlign","w:noEndnote","w:titlePg","w:textDirection","w:bidi","w:rtlGutter","w:docGrid","w:printerSettings","w:sectPrChange")


def configure_document(doc, lang):
    if "Line Number" not in doc.styles:
        doc.styles.add_style("Line Number",WD_STYLE_TYPE.CHARACTER)
    line_style=doc.styles["Line Number"]
    line_style.font.name=FONT;line_style.font.size=Pt(9);line_style.font.color.rgb=RGBColor(0,0,0)
    line_rpr=line_style.element.get_or_add_rPr()
    line_fonts=line_rpr.find(qn("w:rFonts"))
    if line_fonts is None:line_fonts=OxmlElement("w:rFonts");line_rpr.insert(0,line_fonts)
    for key in ["ascii","hAnsi","eastAsia","cs"]:line_fonts.set(qn("w:"+key),FONT)
    for name in ["Normal", "Body Text", "Title", "Subtitle", "Heading 1", "Heading 2", "Heading 3", "Caption", "Footer"]:
        style = doc.styles[name]
        style.font.name = FONT
        style.font.color.rgb = RGBColor(0, 0, 0)
        style.font.size = Pt(12)
        style.font.bold=False
        style.font.italic=False
        paragraph_props=style.element.find(qn("w:pPr"))
        if paragraph_props is not None:
            for border in list(paragraph_props.findall(qn("w:pBdr"))):paragraph_props.remove(border)
        props = style.element.get_or_add_rPr()
        rf = props.find(qn("w:rFonts"))
        if rf is None:rf = OxmlElement("w:rFonts");props.insert(0, rf)
        for key in ["ascii", "hAnsi", "eastAsia", "cs"]:rf.set(qn("w:"+key),FONT)
        lg = props.find(qn("w:lang"))
        if lg is None:lg=OxmlElement("w:lang");props.append(lg)
        lg.set(qn("w:val"), "es-CL" if lang=="es" else "en-GB")
        pf=style.paragraph_format
        pf.line_spacing=1.5;pf.space_after=Pt(6);pf.widow_control=True
        if name.startswith("Heading"):
            style.font.bold=True;pf.keep_with_next=True;pf.space_before=Pt(12);pf.space_after=Pt(6)
        if name=="Title":
            style.font.size=Pt(14);style.font.bold=True;pf.alignment=WD_ALIGN_PARAGRAPH.CENTER;pf.space_after=Pt(14);pf.keep_with_next=True
        if name in ["Caption","Footer"]:
            style.font.size=Pt(10);pf.line_spacing=1.0;pf.space_before=Pt(4);pf.space_after=Pt(4)
    configure_section(doc.sections[0],first=True)
    footer=doc.sections[0].footer.paragraphs[0]
    footer.style=doc.styles["Footer"]
    footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
    footer.paragraph_format.space_before=footer.paragraph_format.space_after=Pt(0)
    field=OxmlElement("w:fldSimple");field.set(qn("w:instr"),"PAGE")
    r=OxmlElement("w:r");t=OxmlElement("w:t");t.text="1";r.append(t);field.append(r);footer._p.append(field)
    # Fields are updated by Word/LibreOffice; numbering continues through sections.
    settings=doc.settings.element
    element(settings,"updateFields",val="true")
    doc.core_properties.title=""
    doc.core_properties.subject=""
    doc.core_properties.author=""
    doc.core_properties.keywords=""


def paragraph(doc, text, style="Normal", size=None, bold=False):
    p=doc.add_paragraph(style=style)
    p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY if style=="Normal" else None
    for part in re.split(r"(\*\*[^*]+\*\*)",str(text)):
        marked=part.startswith("**") and part.endswith("**")
        run=p.add_run(part[2:-2] if marked else part)
        font(run,size=size,bold=bool(bold or marked))
    return p


def page_section(doc, landscape=False, figures=False):
    previous=doc.sections[-1]
    same=(previous.orientation==WD_ORIENT.LANDSCAPE)==landscape and abs(previous.top_margin.mm-(12 if figures else 20))<.1
    if same:
        # An independent page-break paragraph can itself overflow and create a
        # blank page. Apply pageBreakBefore to the next real content paragraph.
        return True
    else:
        new=doc.add_section(WD_SECTION_START.NEW_PAGE)
        configure_section(new,landscape,figures)
        new.footer.is_linked_to_previous=True
        return False


def cell_properties(cell, fill=None, vertical_padding=85):
    props=cell._tc.get_or_add_tcPr()
    margins=OxmlElement("w:tcMar")
    for side in ["top","left","bottom","right"]:element(margins,side,w=str(vertical_padding) if side in ["top","bottom"] else "100",type="dxa")
    props.append(margins)
    borders=OxmlElement("w:tcBorders")
    for side in ["top","left","bottom","right"]:element(borders,side,val="single",sz="4",color="D9D9D9")
    props.append(borders)
    if fill:element(props,"shd",fill=fill,val="clear")
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER


def column_widths(columns,rows,total_mm):
    # Length-informed widths: short numerical columns stay compact.
    scores=[]
    for j,column in enumerate(columns):
        strings=[str(row[j]) for row in rows if j<len(row)]
        lengths=sorted(len(s) for s in strings)
        q=lengths[min(len(lengths)-1,int(len(lengths)*.8))] if lengths else 0
        score=max(9,min(55,max(len(str(column))*.75,q)*.70))
        scores.append(score)
    return [total_mm*x/sum(scores) for x in scores]


def add_table(doc,entry,lang):
    landscape=bool(entry.get("landscape",False))
    break_before=page_section(doc,landscape,False)
    title=entry["title"]
    prefix=("Tabla" if lang=="es" else "Table")+f" {entry['number']}"
    if not title.lower().startswith(prefix.lower()):title=prefix+". "+title
    p=paragraph(doc,title,"Caption",size=10,bold=True);p.paragraph_format.keep_with_next=True
    p.paragraph_format.page_break_before=break_before
    columns=entry["columns"];rows=entry["rows"]
    available=257 if landscape else 170
    widths=entry.get('column_widths_mm') or column_widths(columns,rows,available)
    if len(widths)!=len(columns) or abs(sum(widths)-available)>.1:
        raise ValueError('Table column widths must fit the selected page width')
    if len(columns)==4 and str(entry["number"])=="1" and not landscape:
        # Keep source names, year windows and volumes intact rather than
        # allocating almost all width to the coverage description.
        widths=[32,25,85,28]
    table=doc.add_table(rows=1,cols=len(columns));table.alignment=WD_TABLE_ALIGNMENT.CENTER;table.autofit=False
    for col,width in zip(table.columns,widths):col.width=Mm(width)
    header=table.rows[0]
    element(header._tr.get_or_add_trPr(),"tblHeader")
    for j,text in enumerate(columns):header.cells[j].text=str(text)
    for row in rows:
        cells=table.add_row().cells
        for j in range(len(columns)):cells[j].text=str(row[j]) if j<len(row) else ""
    for i,row in enumerate(table.rows):
        element(row._tr.get_or_add_trPr(),"cantSplit")
        for j,cell in enumerate(row.cells):
            # Retain 10 pt text while fitting the complete explanatory notes
            # below the dense centre summary and regional hospital table.
            padding=entry.get("vertical_padding_twips", {"S7":45,"S10":65}.get(str(entry["number"]),85))
            cell.width=Mm(widths[j]);cell_properties(cell,fill="E7EEF4" if i==0 else ("F7F9FB" if i%2==0 else "FFFFFF"),vertical_padding=padding)
            text=cell.text
            numeric=len(text)<30 and sum(ch.isdigit() for ch in text)>0 and not any(ch.isalpha() for ch in text.replace("NA",""))
            for p in cell.paragraphs:
                p.paragraph_format.line_spacing=1.0;p.paragraph_format.space_before=Pt(1);p.paragraph_format.space_after=Pt(1)
                p.alignment=WD_ALIGN_PARAGRAPH.CENTER if i==0 or numeric else WD_ALIGN_PARAGRAPH.LEFT
                for run in p.runs:font(run,size=10 if len(columns)<9 else 9.5,bold=i==0)
    if entry.get("note"):
        p=paragraph(doc,entry["note"],"Caption",size=10);p.paragraph_format.keep_with_next=False
        p.paragraph_format.keep_together=True
        # Keep a continued table's last row with the complete explanatory note.
        for cell in table.rows[-1].cells:
            for last_paragraph in cell.paragraphs:last_paragraph.paragraph_format.keep_with_next=True


def add_figure(doc,entry,lang,manifest):
    break_before=page_section(doc,False,True)
    path=Path(entry["path"])
    if not path.is_absolute():path=ROOT/path
    im=Image.open(path);native_width,native_height=im.size
    p=doc.add_paragraph();p.paragraph_format.line_spacing=1.0;p.paragraph_format.space_before=Pt(0);p.paragraph_format.space_after=Pt(0);p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.page_break_before=break_before
    p.paragraph_format.keep_with_next=True
    image_run=p.add_run();font(image_run,size=1,bold=False)
    picture=image_run.add_picture(str(path),width=Mm(170))
    picture._inline.docPr.set("descr",entry.get("alt",entry.get("caption","")))
    picture._inline.docPr.set("title",("Figura" if lang=="es" else "Figure")+f" {entry['number']}")
    caption=entry["caption"]
    prefix=("Figura" if lang=="es" else "Figure")+f" {entry['number']}"
    if not caption.lower().startswith(prefix.lower()):caption=prefix+". "+caption
    cap=paragraph(doc,"**"+prefix+"**"+caption[len(prefix):],"Caption",size=10)
    cap.paragraph_format.keep_together=True
    cap.paragraph_format.keep_with_next=False
    cap.paragraph_format.line_spacing=Pt(11.5)
    cap.paragraph_format.space_before=Pt(3)
    cap.paragraph_format.space_after=Pt(0)
    cap.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
    manifest.append({"number":entry["number"],"path":str(path.relative_to(ROOT)),"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"inserted_width_mm":170,"inserted_height_mm":170*native_height/native_width,"caption_words":len(caption.split())})


def build(lang,data,dest,bundle_id):
    doc=Document();configure_document(doc,lang)
    title=paragraph(doc,data["title"],"Title",size=14,bold=True)
    title.alignment=WD_ALIGN_PARAGRAPH.CENTER
    doc.core_properties.title=data["title"]
    doc.core_properties.subject=f"Evidence bundle {bundle_id}; Python {platform.python_version()}; python-docx {docx.__version__}"
    doc.core_properties.keywords=f"evidence-bundle:{bundle_id}; python-docx:{docx.__version__}; python:{platform.python_version()}"
    sections=data.get("sections",[])
    if len(sections)!=2:raise ValueError(f"Expected exactly two principal sections for {lang}")
    for i,section in enumerate(sections):
        paragraph(doc,section["heading"],"Heading 1",size=12,bold=True)
        for block in section["blocks"]:
            if block["type"]=="heading":
                level=max(2,min(int(block.get("level",2)),3))
                paragraph(doc,block["text"],f"Heading {level}",size=12,bold=True)
            elif block["type"]=="paragraph":paragraph(doc,block["text"])
            else:raise ValueError(f"Unsupported block type: {block['type']}")
        if i==0 and data.get("references"):
            paragraph(doc,"Referencias metodológicas" if lang=="es" else "Methodological references","Heading 2",size=12,bold=True)
            for j,reference in enumerate(data["references"],1):
                p=paragraph(doc,f"{j}. {reference}")
                p.paragraph_format.line_spacing=1.5
    for entry in data.get("tables",[]):add_table(doc,entry,lang)
    figures=[]
    for entry in data.get("figures",[]):add_figure(doc,entry,lang,figures)
    dest.parent.mkdir(parents=True,exist_ok=True)
    doc.save(dest)
    return {"language":lang,"path":str(dest.relative_to(ROOT)),"sha256":hashlib.sha256(dest.read_bytes()).hexdigest(),"bundle_content_sha256":bundle_id,"software":{"python":platform.python_version(),"python-docx":docx.__version__},"figures":figures,"tables":len(data.get("tables",[])),"main_sections":[s["heading"] for s in sections],"paper":"A4","body_font":FONT,"body_points":12,"body_line_spacing":1.5,"caption_points":10,"figure_caption_leading_points":11.5,"figure_vertical_margins_mm":12,"continuous_line_numbering":True,"line_number_points":9}


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--bundle",type=Path,default=BUNDLE);parser.add_argument("--output-dir",type=Path,default=DEST)
    parser.add_argument("--lang",choices=["en","es","both"],default="en")
    args=parser.parse_args()
    content=json.loads(args.bundle.read_text(encoding="utf-8"))
    manifests=[]
    for lang,name in [("es","Metodologia_Resultados_ES.docx"),("en","Methods_Results_EN.docx")]:
        if args.lang!="both" and args.lang!=lang:continue
        dest=args.output_dir/name
        manifests.append(build(lang,content["languages"][lang],dest,content["content_sha256"]));print(dest,flush=True)
    (args.output_dir/"docx_build_manifest.json").write_text(json.dumps({"bundle":str(args.bundle.relative_to(ROOT)),"bundle_sha256":hashlib.sha256(args.bundle.read_bytes()).hexdigest(),"bundle_content_sha256":content["content_sha256"],"software":{"python":platform.python_version(),"python-docx":docx.__version__},"outputs":manifests},ensure_ascii=False,indent=2),encoding="utf-8")


if __name__=="__main__":main()
