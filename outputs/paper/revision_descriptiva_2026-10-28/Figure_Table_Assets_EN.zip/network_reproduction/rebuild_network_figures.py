#!/usr/bin/env python3
"""Rebuild the three network/prevalence panels from saved aggregate estimates."""
from pathlib import Path
import argparse
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-inputs-only", action="store_true")
    args = parser.parse_args()
    manifest = json.loads((ROOT / "reproduction_manifest.json").read_text())
    for record in manifest["files"]:
        path = ROOT / record["path"]
        if not path.is_file() or digest(path) != record["sha256"]:
            raise ValueError("Input integrity check failed: " + record["path"])
    if args.check_inputs_only:
        print(json.dumps({"status": "pass", "input_files_verified": len(manifest["files"])}))
        return
    sys.path.insert(0, str(ROOT / "scripts/paper"))
    import matplotlib as mpl
    import numpy as np
    import pandas as pd
    import p18_descriptive_review_figures as historical
    import p22_candidate_networks as unique
    tables = ROOT / "outputs/multifuente/tables"
    # Only 21-condition correlation matrices and node labels are supplied.
    for name in ("network_dis_matrices.npz", "network_unique_matrices.npz"):
        with np.load(tables / name, allow_pickle=False) as data:
            for key in data.files:
                value = data[key]
                allowed = (key.startswith("keys_") and value.shape == (21,) and value.dtype.kind in "US")
                allowed = allowed or (value.shape == (21, 21) and value.dtype.kind in "fi")
                if not allowed:
                    raise ValueError("Unexpected aggregate matrix shape: " + name + " / " + key)
    # Sample and model-summary denominators must agree before bars are drawn.
    for prefix, keys in (("network_dis", ["disease", "sex", "period"]),
                         ("network_unique", ["disease", "sex"])):
        sample = pd.read_csv(tables / (prefix + "_sample.csv")).set_index(keys)["n"].sort_index()
        summary = pd.read_csv(tables / (prefix + "_global.csv")).set_index(keys)["n"].sort_index()
        # Historical sample summaries also include the pooled 2019–2024
        # period; compare only the periods actually represented by networks.
        sample = sample.reindex(summary.index)
        if not sample.equals(summary):
            raise ValueError("Sample/model denominator mismatch: " + prefix)
    (historical.OUT / "figures/source_data").mkdir(parents=True, exist_ok=True)
    mpl.rcdefaults()
    historical.style()
    historical.figure3("en")
    for folder in (unique.FIG, unique.SOURCE, unique.TABLES):
        folder.mkdir(parents=True, exist_ok=True)
    # Original figure families run in separate processes. Reset inherited
    # rcParams so the historical tick styles cannot affect S15/S16 rendering.
    mpl.rcdefaults()
    unique.style()
    matrices = np.load(tables / "network_unique_matrices.npz", allow_pickle=False)
    nodes = unique.read("network_nodes.csv")
    nodes = nodes[nodes.in_network.eq(1)].set_index("node")
    summary = unique.read("network_unique_global.csv").set_index(["disease", "sex"])
    xy, maximum = unique.common_layout(matrices)
    unique.network_figure("S15", False, matrices, nodes, summary, xy, maximum)
    unique.network_figure("S16", True, matrices, nodes, summary, xy, maximum)
    checks = []
    for expected in manifest["expected_outputs"]:
        path = ROOT / expected["path"]
        actual = digest(path)
        checks.append({"path": expected["path"], "sha256": actual,
                       "matches_reviewed_output": actual == expected["sha256"]})
    report = {"status": "pass" if all(row["matches_reviewed_output"] for row in checks) else "mismatch",
              "network_models_refitted": False, "source_records_read": False,
              "input_files_verified": len(manifest["files"]), "outputs": checks}
    (ROOT / "rebuild_validation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    if report["status"] != "pass":
        raise SystemExit("Output hashes differ. Use the recorded Python/package environment; rendering libraries and platform fonts can affect PNG bytes.")


if __name__ == "__main__":
    main()
