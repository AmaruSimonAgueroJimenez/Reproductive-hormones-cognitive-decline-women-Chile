# Network and recorded-prevalence figure reconstruction

This kit recreates the English historical Figure 3 and unique-person Figures S15–S16, including their adjacent bars for all 21 prespecified comorbidities. It uses the exact plotting modules and saved aggregate estimates from the reviewed project. It does **not** refit the network models or recreate those estimates from patient records.

## Rebuild

Use Python **3.14.3** and the package versions in `requirements.txt`. From this extracted `network_reproduction` folder:

```sh
python3 -m pip install -r requirements.txt
python3 rebuild_network_figures.py --check-inputs-only
python3 rebuild_network_figures.py
```

The existing `scripts/paper/` and `outputs/multifuente/tables/` structure must be retained because the original modules resolve paths relative to their location. All inputs are included; an external data disk or network connection is not required for rebuilding after software installation. The workflow creates PNG, SVG and PDF figures and the three prevalence CSV exports below `outputs/paper/revision_descriptiva_2026-10-28/`.

## Scope and interpretation

- Figure 3 uses women's GRD person-year observations in 2019–2021 and 2022–2024. A woman may contribute more than one year; the bars use person-years as their denominators.
- Figures S15–S16 use unique people at their first eligible year in 2021–2024. The two figures share identical **raw** recorded comorbidity percentages. Only the S16 network connections are conditional on age and coding depth.
- The NPZ inputs contain only 21 × 21 estimated correlation matrices and 21-condition labels. CSV inputs contain group-level percentages, denominators, model summaries and sample summaries. No individual records or patient identifiers are included.
- Bars equal 100 × coded observations / eligible observations in the corresponding network group. They describe selected hospital coding and are not population or clinically validated prevalence estimates. Network associations do not identify causal mechanisms.

Scientific sources are [FONASA GRD](https://datosabiertos.fonasa.cl/dimensiones-financiamientos/) and the definitions and observation windows documented in the report captions. Technical manifests are integrity records, not original scientific sources.

## Integrity and reproducibility

`reproduction_manifest.json` records SHA256 hashes for every supplied file and expected hashes for the three 600 dpi PNGs and three prevalence CSVs. The wrapper verifies the input hashes, checks the permitted aggregate matrix shapes, cross-checks sample/model denominators, rebuilds the figures and records output comparisons in `rebuild_validation.json`.

Exact PNG hashes have been verified in the recorded authoring environment. Different operating systems or rendering libraries may produce different antialiasing or PNG bytes despite identical data; use the recorded environment for the strict comparison. SVG/PDF metadata can contain generation timestamps, so their binary hashes are not used as equality criteria. Rebuilding from aggregate estimates is distinct from independent re-extraction and refitting, which require the complete analytical project and authorised source data.
