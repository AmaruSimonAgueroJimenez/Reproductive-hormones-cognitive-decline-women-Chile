"""English-only candidate network figures S15-S18 and tables S15-S20.

Read final aggregate network_unique_* outputs; no models are refitted. Write only
to revision_descriptiva_2026-10-28/bank and never to the core manuscript metadata.
"""
from __future__ import annotations

from datetime import datetime, timezone
import argparse
import hashlib
import json
from pathlib import Path
import platform
import shutil

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.colors import TwoSlopeNorm
from matplotlib.lines import Line2D
from matplotlib.transforms import Bbox
import networkx as nx
import numpy as np
import pandas as pd
from network_prevalence_panels import draw_grouped_prevalence, prevalence_legend_handles

ROOT = Path(__file__).resolve().parents[2]
TAB = ROOT / "outputs/multifuente/tables"
OUT = ROOT / "outputs/paper/revision_descriptiva_2026-10-28/bank"
FIG = OUT / "figures"
TABLES = OUT / "tables"
SOURCE = FIG / "source_data"
WIDTH = 170 / 25.4
DIS = {"AD": "Alzheimer disease", "UD": "Unspecified dementia", "PD": "Parkinson disease"}
SEX = {"Mujer": "Women", "Hombre": "Men"}
ORDER = [(d, s) for d in DIS for s in SEX]
COMM = {"ND": ("#D4AED0", "D", "Neurological"),
        "CMV": ("#A8CDE0", "o", "Cardiometabolic and vascular"),
        "CHR": ("#B5D9C6", "s", "Other chronic conditions"),
        "GER": ("#E9CB8F", "^", "Geriatric syndromes")}
SHORT = {"HYPOT": "THYR", "DYSPH": "DYS"}
META = {"figures": [], "tables": []}


def read(name):
    return pd.read_csv(TAB / name)


def source(path):
    p = Path(path)
    if not p.is_absolute():
        p = TAB / p
    return {"root": "project", "path": p.relative_to(ROOT).as_posix(),
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}


def f(value, decimals=2):
    return "–" if pd.isna(value) else f"{float(value):.{decimals}f}"


def count(value):
    return f"{int(value):,}"


def centrality_title(disease):
    label = DIS[disease] if disease in ("AD", "PD") else DIS[disease].lower()
    return f"Node centrality in {label} networks"


def style():
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 7.2,
        "axes.titlesize": 7.6, "axes.labelsize": 7.2, "xtick.labelsize": 6.8,
        "ytick.labelsize": 6.8, "legend.fontsize": 6.7, "axes.linewidth": .65,
        "lines.linewidth": 1.1, "axes.spines.top": False, "axes.spines.right": False,
        "legend.frameon": False, "pdf.fonttype": 42, "ps.fonttype": 42,
        "svg.fonttype": "none", "figure.dpi": 140, "savefig.facecolor": "white",
        "figure.facecolor": "white", "axes.facecolor": "white"})


def capture(stem, df):
    p = SOURCE / f"{stem}.csv"
    df.to_csv(p, index=False)
    return p


def export(fig, number, stem, caption, inputs, transformations, values):
    fig.canvas.draw()
    min_font = min(t.get_fontsize() for t in fig.findobj(matplotlib.text.Text) if t.get_visible() and t.get_text())
    if min_font < 6.3 - 1e-8:
        raise ValueError(f"{number}: visible font below 6.3 pt: {min_font}")
    for ext in ("png", "pdf", "svg"):
        fig.savefig(FIG / f"{stem}_en.{ext}", dpi=600, bbox_inches=None, facecolor="white")
    fig.savefig(FIG / f"{stem}_en_preview.png", dpi=160, bbox_inches=None, facecolor="white")
    size = fig.get_size_inches() * 25.4
    plt.close(fig)
    META["figures"].append({"number": number,
        "paths": {"en": (FIG / f"{stem}_en.png").relative_to(ROOT).as_posix()},
        "captions": {"en": caption}, "sources": [source(p) for p in inputs],
        "transformations": transformations, "values": values,
        "formats": {ext: (FIG / f"{stem}_en.{ext}").relative_to(ROOT).as_posix() for ext in ("pdf", "svg")},
        "width_mm": float(size[0]), "height_mm": float(size[1]), "dpi": 600,
        "minimum_visible_font_pt": float(min_font)})
    print(f"Figure {number}: {FIG / (stem + '_en_preview.png')}", flush=True)


def definitions(nodes):
    parts = [f"{SHORT.get(k,k)}, {r.label_en.lower()}" for k, r in nodes.iterrows()]
    parts.insert(1, "DEM, dementia (replaces PARK in Parkinson disease networks)")
    return "; ".join(parts) + "."


def adjusted_network_caption(nodes):
    """Compact S16 caption; retain every qualification and abbreviation."""
    return (
        "Figure S16. Adjusted networks of unique people aged ≥60 with public-hospital GRD episodes, 2021–2024, "
        "including day surgery and other coded activities. Rows show Alzheimer disease (A–B), unspecified dementia "
        "(C–D) and Parkinson disease (E–F); the first two columns show women and men. Adjacent panels G–I show "
        "raw recorded comorbidity percentages for the same disease/sex groups, with all 21 network nodes in "
        "the same fixed order and a common zero-to-80% axis. Pink solid bars indicate women; blue hatched bars "
        "indicate men. These descriptive percentages are 100 × people with the coded condition / eligible "
        "people in that group; they have no inferential intervals and are identical to Figure S15. Network "
        "adjustment does not make these bars adjusted prevalence estimates. Each person contributes "
        "their first eligible year and all diagnoses recorded in that year's episodes; identifiers with discordant "
        "recorded sex are excluded. Alzheimer disease and unspecified dementia are disjoint at baseline; Parkinson "
        "disease may coexist with dementia. Edges are regularised partial correlations from graphical lasso on "
        "tetrachoric correlations, EBIC γ=0.5 and 50 penalty-grid points, conditional on age and log(1 + other "
        "distinct diagnoses) as continuous nodes. All selected non-zero edges remain. Figures S15–S16 share "
        "deterministic positions, constant node area and edge-width scaling across twelve panels. Solid blue edges "
        "are positive; dashed red edges negative. Shapes and colours identify predefined communities. Node size "
        "encodes neither prevalence nor centrality; edge counts depend on sample size and selection threshold. "
        "Recorded-diagnosis associations are descriptive, without causal interpretation. " + definitions(nodes))


def common_layout(matrices):
    weights = [matrices[f"{d}_{'W' if s == 'Mujer' else 'M'}_pcor{suffix}"]
               for d, s in ORDER for suffix in ("", "_adj")]
    mean = np.mean(np.abs(weights), axis=0)
    graph = nx.Graph()
    for i in range(21):
        for j in range(i + 1, 21):
            graph.add_edge(i, j, weight=float(mean[i, j]) + .03)
    positions = nx.spring_layout(graph, weight="weight", seed=22, k=1.9 / np.sqrt(21), iterations=2000)
    xy = np.array([positions[i] for i in range(21)])
    xy = (xy - xy.mean(0)) / np.abs(xy - xy.mean(0)).max(0)
    for _ in range(600):
        delta = np.zeros_like(xy)
        for i in range(21):
            for j in range(i + 1, 21):
                v = xy[i] - xy[j]
                dist = np.linalg.norm(v)
                if dist < .36:
                    push = .35 * (.36 - dist) * v / max(dist, 1e-8)
                    delta[i] += push
                    delta[j] -= push
        xy += delta
        if np.abs(delta).max() < 1e-7:
            break
    xy -= xy.mean(0)
    return xy, max(float(np.abs(w).max()) for w in weights)


def network_figure(number, adjusted, matrices, nodes, summary, xy, wmax):
    # The 225 mm height gives all 21 prevalence labels at least 6.3 pt without
    # crowding. The network coordinates and edge-width scale remain unchanged.
    fig = plt.figure(figsize=(WIDTH, 225 / 25.4))
    row_bottoms = [.665, .390, .115]
    axes = [[fig.add_axes([.015, bottom, .255, .225]),
             fig.add_axes([.285, bottom, .255, .225]),
             fig.add_axes([.665, bottom, .305, .225])]
            for bottom in row_bottoms]
    prevalence = read("network_unique_prevalence.csv").set_index(["disease", "sex", "node"], verify_integrity=True)
    edge_rows, node_rows, prevalence_rows, panels, bar_records = [], [], [], [], []
    lim = float(np.abs(xy).max()) + .22
    for row, dis in enumerate(DIS):
        keys = [str(k) for k in matrices[f"keys_{dis}"]]
        for col, sex in enumerate(SEX):
            index = row * 2 + col
            ax = axes[row][col]
            tag = f"{dis}_{'W' if sex == 'Mujer' else 'M'}_pcor" + ("_adj" if adjusted else "")
            weights = matrices[tag]
            n = int(summary.loc[(dis, sex), "n"])
            for positive, colour, line in ((True, "#2166AC", "solid"), (False, "#A82432", "dashed")):
                segments, widths = [], []
                for i in range(21):
                    for j in range(i + 1, 21):
                        value = float(weights[i, j])
                        if (value > 0) == positive and value != 0:
                            segments.append([xy[i], xy[j]])
                            widths.append(.2 + 2.4 * abs(value) / wmax)
                ax.add_collection(LineCollection(segments, colors=colour, linewidths=widths,
                                  linestyles=line, alpha=.62, zorder=1))
            groups = ["ND" if k == "DEM" else nodes.loc[k, "community"] for k in keys]
            for community, (colour, shape, _) in COMM.items():
                ix = np.array([i for i, g in enumerate(groups) if g == community])
                ax.scatter(xy[ix, 0], xy[ix, 1], s=120, marker=shape, facecolor=colour,
                           edgecolor="#333333", linewidth=.55, zorder=3)
            for i, key in enumerate(keys):
                ax.text(*xy[i], SHORT.get(key, key), ha="center", va="center", fontsize=6.3,
                        fontweight="bold", zorder=4)
                node_rows.append({"disease": DIS[dis], "sex": SEX[sex], "node": key,
                                  "community": groups[i], "x": xy[i, 0], "y": xy[i, 1],
                                  "eligible_people": n, "adjusted": adjusted, "node_area_pt2": 120})
                pct = float(prevalence.loc[(dis, sex, key), "pct"])
                coded = int(round(n * pct / 100))
                if not np.isclose(pct, 100 * coded / n, rtol=0, atol=1e-10):
                    raise ValueError(f"Prevalence n/N failed for {dis} {sex} {key}")
                prevalence_rows.append({"disease": DIS[dis], "disease_code": dis, "sex": SEX[sex],
                    "group": sex, "node": key, "node_label": "Dementia" if key == "DEM" else str(nodes.loc[key, "label_en"]),
                    "abbreviation": SHORT.get(key, key), "n_coded": coded, "N": n, "pct": pct,
                    "observation_unit": "unique people at first eligible year", "period": "2021–2024",
                    "prevalence_adjusted": False})
            for i in range(21):
                for j in range(i + 1, 21):
                    edge_rows.append({"disease": DIS[dis], "sex": SEX[sex], "node1": keys[i], "node2": keys[j],
                                      "partial_correlation": float(weights[i, j]), "drawn": bool(weights[i, j] != 0),
                                      "adjusted": adjusted, "eligible_people": n})
            ax.set_aspect("equal")
            ax.set(xlim=(-lim, lim), ylim=(-lim, lim))
            ax.axis("off")
            ax.set_title(f"{'ABCDEF'[index]}  {DIS[dis]}\n{SEX[sex]}; n={count(n)}", loc="left",
                         fontsize=7.1, fontweight="bold", pad=6)
            panels.append({"disease": dis, "sex": SEX[sex], "n": n,
                           "edges": int(np.count_nonzero(weights[np.triu_indices(21, 1)]))})
        bar_data = pd.DataFrame([r for r in prevalence_rows if r["disease_code"] == dis])
        bar_records.append(draw_grouped_prevalence(axes[row][2], bar_data, keys,
            list(SEX), list(SEX.values()), ["#A83266", "#216A94"], ["", "////"],
            abbreviations=SHORT, x_max=80, title=f"{'GHI'[row]}  Raw recorded prevalence (%)"))
        if row < 2:
            axes[row][2].set_xlabel("")
    title = "Unique-person networks: " + ("conditional on age and coding depth" if adjusted else "unadjusted")
    fig.text(.5, .985, title, ha="center", fontsize=8.0, fontweight="bold")
    bar_legend = fig.legend(handles=prevalence_legend_handles(list(SEX.values()),
        ["#A83266", "#216A94"], ["", "////"]), loc="upper right",
        bbox_to_anchor=(.985, .96), ncol=2, fontsize=6.7, columnspacing=.8,
        handlelength=1.2, handletextpad=.4)
    handles = [Line2D([], [], marker=shape, mfc=colour, mec="#333333", mew=.5,
                      ls="none", ms=5, label=name) for colour, shape, name in COMM.values()]
    handles += [Line2D([], [], color="#2166AC", lw=1.3, label="Positive edge"),
                Line2D([], [], color="#A82432", ls="--", lw=1.3, label="Negative edge")]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(.5, .012), ncol=3,
               fontsize=6.7, columnspacing=1.0, handlelength=1.5)
    # Exact crop geometry permits the slide to reuse the original AD-row image.
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    row_crops = {}
    for row, dis in enumerate(DIS):
        boxes = [ax.get_tightbbox(renderer) for ax in axes[row]]
        if row == 0:
            boxes.append(bar_legend.get_window_extent(renderer))
        box = Bbox.union(boxes).expanded(1.01, 1.035)
        x0 = max(0, box.x0 / fig.bbox.width); x1 = min(1, box.x1 / fig.bbox.width)
        y0 = max(0, box.y0 / fig.bbox.height); y1 = min(1, box.y1 / fig.bbox.height)
        row_crops[dis] = [x0, 1-y1, x1-x0, y1-y0]
    stem = f"Figure{number}_unique_{'adjusted' if adjusted else 'unadjusted'}"
    ep = capture(stem + "_edges", pd.DataFrame(edge_rows))
    np_ = capture(stem + "_nodes", pd.DataFrame(node_rows))
    pp = capture(stem + "_prevalence", pd.DataFrame(prevalence_rows))
    cap = (f"Figure {number}. {'Adjusted' if adjusted else 'Unadjusted'} comorbidity networks of unique people aged ≥60 "
           "with recorded public-hospital GRD episodes in 2021–2024, including day surgery and other coded activities. "
           "Rows show Alzheimer disease (A–B), unspecified dementia (C–D) and Parkinson disease (E–F); the first two "
           "columns show women and men. Adjacent panels G–I show raw recorded comorbidity percentages for the same "
           "disease/sex groups, using all 21 network nodes in the same fixed order and a common zero-to-80% axis. "
           "Pink solid bars indicate women; blue hatched bars indicate men. Percentages are 100 × people with the "
           "coded condition / eligible people in the group; they are descriptive, with no inferential intervals. "
           "Each person contributes their first eligible year and all diagnoses from episodes in that year; identifiers "
           "with discordant recorded sex are excluded. Alzheimer disease and unspecified dementia are disjoint at "
           "baseline; Parkinson disease may coexist with dementia. Edges are selected regularised partial correlations "
           "estimated with graphical lasso on tetrachoric correlations, EBIC γ=0.5 and a 50-point penalty-grid rule. " +
           ("These networks condition on age and log(1 + other distinct diagnoses), included as continuous nodes. "
            if adjusted else "These networks are not conditioned on age or coding depth. ") +
           "All selected non-zero edges are retained. Figures S15 and S16 share deterministic positions, constant "
           "node area of 120 pt² and the same edge-width scale across all twelve network panels. Solid blue edges "
           "are positive; dashed red edges are negative. Shapes and colours distinguish predefined communities. "
           "Node size does not encode prevalence or centrality. Edge counts depend on sample size and selection "
           "threshold. Associations among recorded diagnoses are descriptive and do not identify causal mechanisms. " + definitions(nodes))
    if adjusted:
        cap = adjusted_network_caption(nodes)
    export(fig, number, stem, cap,
           ["network_unique_matrices.npz", "network_nodes.csv", "network_unique_global.csv", "network_unique_prevalence.csv", ep, np_, pp],
           ["Reuse final unique-person network matrices without refitting", "Fixed 21 nodes; no significance filter",
            "Shared layout across twelve networks; spring seed22 and collision distance0.36",
            "Constant network node area120pt²; common absolute edge-width maximum", "Retain every non-zero selected edge",
            "Adjacent grouped bars use raw recorded diagnosis n/N percentages; identical between S15 and S16",
            "Common 0–80% bar scale and all 21 nodes; no inferential intervals"],
           {"panels": panels, "bar_panels": bar_records, "positions": xy.tolist(),
            "maximum_absolute_edge": wmax, "adjusted": adjusted, "node_area_pt2": 120,
            "row_crops": row_crops, "prevalence_source_csv": pp.relative_to(ROOT).as_posix()})
    META["figures"][-1]["alt"] = {"en": "Six comorbidity networks of unique eligible people, grouped by disease and sex, alongside three grouped horizontal bar charts of raw recorded comorbidity percentages in the same people. Pink bars show women; blue hatched bars show men. All 21 conditions and a common 0–80% axis are retained."}
    META["figures"][-1]["prevalence_source_csv"] = pp.relative_to(ROOT).as_posix()


def prevalence_gap(matrices, nodes, summary):
    p = read("network_unique_prevalence.csv").set_index(["disease", "sex", "node"])
    rows = []
    for dis in DIS:
        keys = [str(k) for k in matrices[f"keys_{dis}"]]
        for position, key in enumerate(keys):
            women, men = float(p.loc[(dis, "Mujer", key), "pct"]), float(p.loc[(dis, "Hombre", key), "pct"])
            rows.append({"disease": DIS[dis], "disease_code": dis, "node_position": position, "node": key,
                         "women_percent": women, "men_percent": men, "women_minus_men_pp": women - men,
                         "women_n": int(summary.loc[(dis, "Mujer"), "n"]), "men_n": int(summary.loc[(dis, "Hombre"), "n"])})
    gap = pd.DataFrame(rows)
    data = gap.pivot(index="node_position", columns="disease_code", values="women_minus_men_pp").reindex(columns=DIS)
    limit = float(np.ceil(np.abs(data.to_numpy()).max() / 2) * 2)
    fig, ax = plt.subplots(figsize=(WIDTH, 165 / 25.4))
    fig.subplots_adjust(left=.40, right=.91, top=.89, bottom=.14)
    im = ax.imshow(data, cmap="RdBu_r", norm=TwoSlopeNorm(vmin=-limit, vcenter=0, vmax=limit),
                   interpolation="nearest", aspect="auto")
    keys = [str(k) for k in matrices["keys_AD"]]
    labels = ["PARK / DEM*" if i == 0 else f"{nodes.loc[k,'label_en']} ({SHORT.get(k,k)})" for i, k in enumerate(keys)]
    ax.set_yticks(range(21), labels, fontsize=6.5)
    ax.set_xticks(range(3), ["Alzheimer\ndisease", "Unspecified\ndementia", "Parkinson\ndisease"], fontsize=7.1)
    ax.xaxis.tick_top()
    ax.tick_params(length=0, pad=5)
    for i in range(21):
        for j in range(3):
            value = float(data.iloc[i, j])
            label = f"{0 if abs(value)<.05 else value:+.1f}"
            ax.text(j, i, label, ha="center", va="center", fontsize=6.6,
                    color="white" if abs(value) > .60 * limit else "#202020")
    cbax = fig.add_axes([.435, .075, .44, .018])
    colourbar = fig.colorbar(im, cax=cbax, orientation="horizontal")
    colourbar.set_label("Recorded prevalence difference: women − men (percentage points)", fontsize=6.7)
    colourbar.ax.tick_params(labelsize=6.5, length=2)
    fig.text(.5, .965, "Sex differences in recorded comorbidity, unique people 2021–2024", ha="center", fontsize=8.0, fontweight="bold")
    fig.text(.40, .115, "*PARK in dementia networks; DEM in Parkinson disease", ha="left", fontsize=6.3)
    csv = capture("FigureS17_prevalence_gap", gap)
    cap = ("Figure S17. Differences in coded comorbidity percentages between women and men with public-hospital GRD "
           "episodes, among unique people aged ≥60 in 2021–2024. Cells show women minus men in percentage points, "
           "calculated directly from the unweighted percentages in each disease and sex group. Positive values indicate "
           "more frequent coding in women and negative values more frequent coding in men. A common symmetric colour "
           "scale is centred on zero; numbers provide a colour-independent reading. The first row is parkinsonism "
           "(PARK) in the Alzheimer and unspecified dementia groups and dementia (DEM) in the Parkinson disease group; "
           "these are different conditions. All 21 fixed node positions are retained. The figure shows descriptive "
           "point differences without confidence intervals, hypothesis tests or multiplicity-adjusted claims. Percentages "
           "reflect recorded diagnoses in this selected care population, not population prevalence or causal sex effects. "
           "The same baseline eligibility and disease definitions as figures S15–S16 apply.")
    export(fig, "S17", "FigureS17_prevalence_gap", cap,
           ["network_unique_prevalence.csv", "network_unique_global.csv", "network_unique_matrices.npz", "network_nodes.csv", csv],
           ["Women percentage minus men percentage within disease/node; signed percentage-point difference",
            "All21node positions retained; PARK/DEM substitution explicit", "No model fitting, intervals or significance selection",
            "Common zero-centred symmetric colour limits"], {"colour_limit_pp": limit, "cells": gap.to_dict("records")})


def stability_figure(summary):
    d = read("network_unique_stability.csv").copy()
    d["removed_percent"] = 100 * (1 - d.prop_retained)
    fig, axes = plt.subplots(3, 2, figsize=(WIDTH, 185 / 25.4))
    fig.subplots_adjust(left=.10, right=.98, top=.90, bottom=.14, hspace=.60, wspace=.32)
    ymin = max(-1, np.floor(min(d.strength_q05.min(), d.edge_q05.min()) * 10) / 10 - .03)
    records = []
    cs_label = lambda v: ("≥" if v >= .7 - 1e-9 else "") + f(v, 2)
    for index, ((dis, sex), ax) in enumerate(zip(ORDER, axes.flat)):
        z = d[(d.disease == dis) & (d.sex == sex)].sort_values("removed_percent")
        for metric, colour, marker in (("strength", "#2166AC", "o"), ("edge", "#A83266", "s")):
            ax.plot(z.removed_percent, z[metric + "_mean"], color=colour, marker=marker, ms=3.1, ls="-")
            ax.plot(z.removed_percent, z[metric + "_q05"], color=colour, marker=marker, ms=2.5, mfc="white", ls="--")
        ax.axhline(.7, color="#555555", ls=":", lw=.9)
        ax.set(xlim=(8, 72), ylim=(ymin, 1.025), xticks=[10, 30, 50, 70], yticks=[.4, .6, .7, .8, 1.0])
        ax.grid(axis="y", color="#E8E8E8", lw=.45)
        if index % 2 == 0:
            ax.set_ylabel("Pearson correlation")
        if index >= 4:
            ax.set_xlabel("People removed (%)")
        r = summary.loc[(dis, sex)]
        ax.set_title(f"{'ABCDEF'[index]}  {DIS[dis]} · {SEX[sex]}\nCS strength {cs_label(r.cs_strength)}; edges {cs_label(r.cs_edge)}",
                     loc="left", fontsize=6.7, fontweight="bold", pad=6)
        records.append({"disease": dis, "sex": SEX[sex], "CS_strength": float(r.cs_strength), "CS_edges": float(r.cs_edge)})
    handles = [Line2D([], [], color=colour, marker=marker, mfc="white" if stat == "5th percentile" else colour,
                      ls="--" if stat == "5th percentile" else "-", ms=3.2,
                      label=f"{metric}: {stat}") for metric, colour, marker in
               (("Node strength", "#2166AC", "o"), ("Edge weights", "#A83266", "s")) for stat in ("Mean", "5th percentile")]
    handles.append(Line2D([], [], color="#555555", ls=":", label="CS threshold: 0.70"))
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(.5, .018), ncol=2,
               fontsize=6.6, columnspacing=1.8)
    fig.text(.5, .975, "Case-dropping stability of unique-person networks", ha="center", fontsize=8.0, fontweight="bold")
    display = d.copy()
    display.sex = display.sex.map(SEX)
    display.disease = display.disease.map(DIS)
    csv = capture("FigureS18_case_dropping", display)
    cap = ("Figure S18. Case-dropping stability of the six unadjusted unique-person networks, 2021–2024. Rows show "
           "Alzheimer disease, unspecified dementia and Parkinson disease; women are left and men right. At each "
           "fraction removed (10–70%), the existing analysis drew 50 subsamples without replacement and re-estimated "
           "the network with the same 50-point EBIC penalty-grid rule. Pearson correlations compare each subsample "
           "vector with the full-sample vector, separately for node strength and all 210 edge weights. Solid lines show "
           "mean correlations and dashed lines their fifth percentiles; neither is a confidence interval. CS is the "
           "largest tested fraction dropped whose fifth-percentile correlation reaches 0.70. A displayed CS ≥0.70 "
           "means the criterion still holds at the largest tested removal fraction, so it is a lower bound on the "
           "unexplored range. Shared axes and a horizontal 0.70 threshold permit direct inspection of sampling stability. "
           "The figure describes resampling robustness of these selected networks and does not establish temporal "
           "stability, clinical importance or equivalence between sexes.")
    export(fig, "S18", "FigureS18_case_dropping", cap, ["network_unique_stability.csv", "network_unique_global.csv", csv],
           ["Reuse final50-replicate case-dropping summaries without refitting", "Removedpercent=100*(1-prop_retained)",
            "Show mean and fifth percentile separately for strength/edge vectors", "Same y axis and 0.70 threshold in all panels",
            "CS at0.70 labelled as lower bound at maximum tested fraction"], {"panels": records, "y_min": float(ymin)})


def table(number, title, columns, rows, note, sources):
    if any(len(row) != len(columns) for row in rows):
        raise ValueError(f"Table {number}: inconsistent row width")
    df = pd.DataFrame(rows, columns=columns)
    csv = TABLES / f"Table{number}_en.csv"
    df.to_csv(csv, index=False)
    (TABLES / f"Table{number}_en.md").write_text(f"**Table {number}. {title}**\n\n" + df.to_markdown(index=False) + "\n\n" + note + "\n", encoding="utf-8")
    META["tables"].append({"number": number, "title": {"en": title}, "columns": {"en": columns},
        "rows": {"en": rows}, "note": {"en": note}, "landscape": True,
        "sources": [source(s) for s in sources], "paths": {"en": csv.relative_to(ROOT).as_posix()}})


def all_tables(matrices, nodes, summary):
    sample = read("network_unique_sample.csv").set_index(["disease", "sex"])
    rows = []
    for dis, sex in ORDER:
        r = sample.loc[(dis, sex)]
        rows.append([DIS[dis], SEX[sex], count(r.n), f"{f(r.age_median,1)} ({f(r.age_q1,1)}–{f(r.age_q3,1)})",
                     f(r.age80_pct,1), f(r.codes_mean,2), f(r.episodes_mean,2), f(r.died_pct,1)])
    common = ("Unique people aged ≥60 with GRD episodes in public hospitals, 2021–2024, including day surgery and "
              "other coded activities. The baseline is each person's first eligible year; all diagnoses from episodes "
              "in that year are combined and later years are not reused. Identifiers with discordant recorded sex "
              "are excluded. Alzheimer disease and unspecified dementia are disjoint at baseline; Parkinson disease "
              "may coexist with dementia. These groups must not be summed as mutually exclusive populations. ")
    table("S15", "Unique-person sample by disease and sex",
          ["Disease", "Sex", "People, n", "Age, median (IQR), years", "Aged ≥80, %",
           "Distinct coded diagnoses, mean", "Episodes in baseline year, mean", "Death coded at discharge, %"], rows,
          common + "Death is any discharge coded as death in the baseline year's included episodes; it is not long-term or all-cause mortality follow-up.",
          ["network_unique_sample.csv", "network_unique_flow.csv"])
    prev = read("network_unique_prevalence.csv").set_index(["disease", "sex", "node"])
    keys = [str(k) for k in matrices["keys_AD"]]
    rows = []
    for i, key in enumerate(keys):
        label = "Parkinsonism / dementia*" if i == 0 else nodes.loc[key, "label_en"]
        codes = "PARK: G20–G23; DEM: F00–F03, G30, G31.0, G31.1, G31.8" if i == 0 else nodes.loc[key, "codes"]
        values = []
        for dis, sex in ORDER:
            node = "DEM" if dis == "PD" and i == 0 else key
            values.append(f(prev.loc[(dis, sex, node), "pct"], 1))
        rows.append([label, codes, *values])
    table("S16", "Coded prevalence of the 21 network nodes by disease and sex",
          ["Condition", "ICD-10 prefixes", "Alzheimer: women, %", "Alzheimer: men, %",
           "Unspecified: women, %", "Unspecified: men, %", "Parkinson: women, %", "Parkinson: men, %"], rows,
          common + "Percentages are unweighted coded diagnoses in these care populations, not population prevalence. "
          "*The first node is parkinsonism in the dementia networks and dementia in Parkinson disease networks. "
          "Prefixes are matched after punctuation removal; C means any cancer code beginning with C. Node selection "
          "was fixed from the original combined neurodegenerative population (≥2% in every sex/year), then retained in every network.",
          ["network_unique_prevalence.csv", "network_nodes.csv", "network_unique_sample.csv", "network_unique_matrices.npz"])
    centrality = read("network_unique_centrality.csv").set_index(["disease", "sex", "node"])
    for dis, number in (("AD", "S17"), ("UD", "S18"), ("PD", "S19")):
        keys = [str(k) for k in matrices[f"keys_{dis}"]]
        rows = []
        for key in keys:
            label = "Dementia (DEM)" if key == "DEM" else f"{nodes.loc[key,'label_en']} ({SHORT.get(key,key)})"
            w, m = centrality.loc[(dis, "Mujer", key)], centrality.loc[(dis, "Hombre", key)]
            rows.append([label, f(w.strength), f(m.strength), f(w.strength_adj), f(m.strength_adj),
                         f(w.expected_influence), f(m.expected_influence), f(w.bridge), f(m.bridge)])
        table(number, centrality_title(dis),
              ["Condition", "Strength: women", "Strength: men", "Adjusted strength: women", "Adjusted strength: men",
               "Expected influence: women", "Expected influence: men", "Bridge strength: women", "Bridge strength: men"], rows,
              common + "Strength is the sum of absolute incident edge weights; expected influence is their signed sum; "
              "bridge strength is the sum of absolute edges to other predefined communities. Adjusted strength conditions "
              "on age and log(1 + other distinct diagnoses). All 21 nodes are included without selection on magnitude or "
              "significance. These are descriptive point estimates; the table does not rank clinical priorities or report calibrated confidence intervals.",
              ["network_unique_centrality.csv", "network_nodes.csv", "network_unique_matrices.npz"])
    edges = read("network_unique_edges.csv").copy()
    edges["absolute_weight"] = edges.pcor.abs()
    rows = []
    for dis, sex in ORDER:
        z = edges[(edges.disease == dis) & (edges.sex == sex)].sort_values(
            ["absolute_weight", "node1", "node2"], ascending=[False, True, True]).head(10)
        for rank, r in enumerate(z.itertuples(), 1):
            edge = f"{SHORT.get(r.node1,r.node1)}–{SHORT.get(r.node2,r.node2)}"
            rows.append([DIS[dis], SEX[sex], str(rank), edge, f(r.pcor,3), f(r.pcor_adj,3),
                         f(r.boot_lo,3), f(r.boot_hi,3), f(100*r.boot_nonzero,1)])
    table("S20", "Ten largest absolute unadjusted edge weights in each unique-person network",
          ["Disease", "Sex", "Rank", "Edge", "Unadjusted weight", "Adjusted weight", "Bootstrap 2.5th percentile",
           "Bootstrap 97.5th percentile", "Non-zero in bootstrap, %"], rows,
          common + "Within each of six disease/sex networks, all 210 pairs were ordered by absolute unadjusted weight; "
          "the first ten were retained, with node-name order breaking exact ties. This display rule was fixed before "
          "generating the table and does not select on significance or bootstrap results. Signed weights are retained. "
          "Adjusted weights refer to the same selected pairs, not a separately selected top ten. The bootstrap uses "
          "200 independent-person resamples and reselects EBIC in each. Percentiles are diagnostics of the regularised "
          "estimator, not calibrated confidence intervals or tests against zero. A point estimate may fall outside these "
          "percentiles because of selection and regularisation. Non-zero frequency is a resampling selection frequency, "
          "not the probability that an edge exists. No causal or multiplicity-adjusted edge claims are made. Abbreviations follow table S16 and figures S15–S16.",
          ["network_unique_edges.csv", "network_unique_global.csv", "network_unique_sample.csv"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--metadata-only", "--s16-caption-only", dest="metadata_only", action="store_true",
                        help="Update S16 caption and proper-name table titles; preserve every figure and source-data file")
    parser.add_argument("--network-figures-only", action="store_true",
                        help="Rebuild only S15/S16 networks and adjacent prevalence panels, preserving all other figures and tables")
    args = parser.parse_args()
    if args.metadata_only and args.network_figures_only:
        parser.error("Choose metadata-only or network-figures-only, not both")
    if args.metadata_only:
        path = OUT / "networks.json"
        old = json.loads(path.read_text(encoding="utf-8"))
        backup = OUT / "backups" / f"s16_caption_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        backup.mkdir(parents=True, exist_ok=False)
        shutil.copy2(path, backup / path.name)
        nodes = read("network_nodes.csv")
        nodes = nodes[nodes.in_network.eq(1)].set_index("node")
        entry = next(x for x in old["figures"] if x["number"] == "S16")
        entry["captions"]["en"] = adjusted_network_caption(nodes)
        for number, disease in (("S17", "AD"), ("S19", "PD")):
            item = next(x for x in old["tables"] if x["number"] == number)
            item["title"]["en"] = centrality_title(disease)
            markdown = TABLES / f"Table{number}_en.md"
            if markdown.exists():
                shutil.copy2(markdown, backup / markdown.name)
                lines = markdown.read_text(encoding="utf-8").splitlines()
                lines[0] = f"**Table {number}. {item['title']['en']}**"
                markdown.write_text("\n".join(lines) + "\n", encoding="utf-8")
        path.write_text(json.dumps(old, indent=2, ensure_ascii=False), encoding="utf-8")
        environment = OUT / "networks_environment.json"
        record = json.loads(environment.read_text(encoding="utf-8"))
        shutil.copy2(environment, backup / environment.name)
        record["script_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        record["caption_revision_utc"] = datetime.now(timezone.utc).isoformat()
        environment.write_text(json.dumps(record, indent=2), encoding="utf-8")
        print(f"S16 caption: {len(entry['captions']['en'].split())} words; S17/S19 titles capitalised; figures and source data untouched")
        return
    for folder in (FIG, TABLES, SOURCE):
        folder.mkdir(parents=True, exist_ok=True)
    owned = [OUT / "networks.json", OUT / "networks_environment.json", OUT / "networks_validation.json",
             *SOURCE.glob("FigureS1[5-8]_*.csv"), *FIG.glob("FigureS1[5-8]_unique*"), *FIG.glob("FigureS17_prevalence*"),
             *FIG.glob("FigureS18_case*"), *TABLES.glob("TableS1[5-9]_en.*"), *TABLES.glob("TableS20_en.*")]
    if args.network_figures_only:
        if not (OUT / "networks.json").is_file():
            raise FileNotFoundError("A complete existing bank is required for network-figures-only mode")
        previous = json.loads((OUT / "networks.json").read_text(encoding="utf-8"))
        owned = [OUT / "networks.json", OUT / "networks_environment.json",
                 *SOURCE.glob("FigureS1[5-6]_*.csv"), *FIG.glob("FigureS1[5-6]_unique*")]
    existing = [p for p in owned if p.exists() and p.is_file()]
    if existing:
        backup = OUT / "backups" / f"networks_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        for path in existing:
            dest = backup / path.relative_to(OUT)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)
    style()
    matrices = np.load(TAB / "network_unique_matrices.npz")
    nodes = read("network_nodes.csv")
    nodes = nodes[nodes.in_network.eq(1)].set_index("node")
    summary = read("network_unique_global.csv").set_index(["disease", "sex"])
    if len(summary) != 6 or not summary.nboot.eq(200).all() or not summary.nlambda.eq(50).all():
        raise ValueError("Expected the six final validated networks")
    xy, wmax = common_layout(matrices)
    network_figure("S15", False, matrices, nodes, summary, xy, wmax)
    network_figure("S16", True, matrices, nodes, summary, xy, wmax)
    if args.network_figures_only:
        revised = {figure["number"]: figure for figure in META["figures"]}
        previous["figures"] = [revised.get(figure["number"], figure) for figure in previous["figures"]]
        (OUT / "networks.json").write_text(json.dumps(previous, indent=2, ensure_ascii=False), encoding="utf-8")
        environment = OUT / "networks_environment.json"
        record = json.loads(environment.read_text(encoding="utf-8")) if environment.exists() else {}
        record.update({"network_prevalence_revision_utc": datetime.now(timezone.utc).isoformat(),
            "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "shared_bar_helper_sha256": hashlib.sha256((Path(__file__).parent / "network_prevalence_panels.py").read_bytes()).hexdigest(),
            "scope": "S15/S16 network figures and adjacent raw recorded-prevalence bars only; no network refitting"})
        environment.write_text(json.dumps(record, indent=2, ensure_ascii=False), encoding="utf-8")
        print("Rebuilt S15/S16 only; all other figures, source files and tables preserved", flush=True)
        return
    prevalence_gap(matrices, nodes, summary)
    stability_figure(summary)
    all_tables(matrices, nodes, summary)
    (OUT / "networks.json").write_text(json.dumps(META, indent=2, ensure_ascii=False), encoding="utf-8")
    (OUT / "networks_environment.json").write_text(json.dumps({"created_utc": datetime.now(timezone.utc).isoformat(),
        "python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__,
        "matplotlib": matplotlib.__version__, "networkx": nx.__version__, "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2), encoding="utf-8")
    print("English network bank complete: four figures and six tables", flush=True)


if __name__ == "__main__":
    main()
