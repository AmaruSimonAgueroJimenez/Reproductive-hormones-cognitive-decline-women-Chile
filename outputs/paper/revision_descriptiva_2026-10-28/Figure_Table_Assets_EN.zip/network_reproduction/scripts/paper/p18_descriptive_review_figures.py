"""Readable bilingual descriptive manuscript figures, 170 mm, PNG/PDF/SVG.

Uses existing aggregate tables only; no source records or fitted analyses are changed.
Run with Python 3.14. Outputs are isolated in revision_descriptiva_2026-10-28.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle, Patch
from matplotlib.ticker import Formatter, FuncFormatter, NullFormatter
import numpy as np
import pandas as pd
from scipy.stats import poisson, spearmanr

ROOT = Path(__file__).resolve().parents[2]
TAB = ROOT / "outputs/multifuente/tables"
OUT = ROOT / "outputs/paper/revision_descriptiva_2026-10-28"
DATA_ROOT = Path(os.environ.get("ASESORIAS_DATA_ROOT", "/Volumes/Datos/Asesorias_Data"))
DERIVED = Path(os.environ.get("MF_DERIVED", str(DATA_ROOT / "derived" / ROOT.name)))
LOCAL_GEO = OUT / "source_data/geo"
GEO = LOCAL_GEO if all((LOCAL_GEO/name).exists() for name in ["regions.geojson","comunas_rm.geojson"]) else DERIVED / "geo"
WIDTH = 170 / 25.4
COL = {"Mujer": "#A83266", "Hombre": "#216A94"}
MARK = {"Mujer": "o", "Hombre": "s"}
STY = {"Mujer": "-", "Hombre": "--"}
NAMES = {"es": {"Mujer": "Mujeres", "Hombre": "Hombres"}, "en": {"Mujer": "Women", "Hombre": "Men"}}
SOURCES = {
    "Defunciones (causa básica)": ("Defunciones", "Deaths", "#222222", "o"),
    "GRD episodios (cualquier posición)": ("GRD: episodios", "GRD: episodes", "#0072B2", "s"),
    "GRD personas (primer episodio)": ("GRD: personas", "GRD: persons", "#D55E00", "^"),
    "REM A05 ingresos por demencia": ("REM A05: ingresos", "REM A05: entries", "#009E73", "D"),
    "REM dementia_stock (dic 2024)": ("REM P6: en control", "REM P6: caseload", "#9A4993", "v"),
    "REM dependency_dementia (dic 2024)": ("REM P3: dependencia", "REM P3: dependency", "#9B6A00", "P"),
    "REM parkinson_stock (dic 2024)": ("REM P3: en control", "REM P3: caseload", "#537421", "X"),
}
CLUSTER = {
    "Alto-Alto": ("Alto–Alto", "High–High", "#A61C2D", "^"),
    "Bajo-Bajo": ("Bajo–Bajo", "Low–Low", "#2166AC", "v"),
    "Alto-Bajo": ("Alto–Bajo", "High–Low", "#A05A17", "s"),
    "Bajo-Alto": ("Bajo–Alto", "Low–High", "#16817A", "D"),
    "No significativo": ("No significativo", "Not significant", "#B6B6B6", "o"),
}
META = {"created": "2026-10-28", "width_mm": 170, "dpi": 600, "purpose": "General manuscript revision; no publisher compliance claim", "path_resolution": {"project_root": ".", "external_data_root": "ASESORIAS_DATA_ROOT", "derived_root_override": "MF_DERIVED"}, "software": {"python": platform.python_version(), "matplotlib": matplotlib.__version__, "pandas": pd.__version__, "numpy": np.__version__}, "figures": {}}


def tr(lang, es, en):
    return es if lang == "es" else en


def load(name):
    return pd.read_csv(TAB / name)


def style():
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 7.4, "axes.titlesize": 8,
        "axes.labelsize": 7.4, "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7,
        "axes.linewidth": .65, "lines.linewidth": 1.1, "xtick.major.width": .6, "ytick.major.width": .6,
        "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
        "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none", "figure.dpi": 140,
        "savefig.facecolor": "white", "axes.facecolor": "white", "figure.facecolor": "white"})


def label(ax, letter, title):
    ax.set_title(f"{letter}  {title}", loc="left", fontweight="bold", pad=9)
    ax.grid(axis="y", color="#E7E7E7", linewidth=.45, zorder=0)
    ax.set_axisbelow(True)


def sex_legend(fig, lang, y=.97):
    handles = [Line2D([], [], color=COL[s], marker=MARK[s], ls="none", ms=4, label=NAMES[lang][s]) for s in COL]
    return fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(.5, y), ncol=2, columnspacing=2.5)


def num(v, lang, decimals=2):
    text = f"{v:.{decimals}f}"
    return text.replace(".", ",") if lang == "es" else text


def count(v,lang):
    value=f"{int(v):,}"
    return value.replace(","," ") if lang=="es" else value


class CommaFormatter(Formatter):
    """Localise existing numerical tick labels without changing their values."""
    def __init__(self,inner):self.inner=inner
    def set_axis(self,axis):
        super().set_axis(axis);self.inner.set_axis(axis)
    def set_locs(self,locs):self.inner.set_locs(locs)
    def __call__(self,value,pos=None):return re.sub(r"(?<=\d)\.(?=\d)",",",self.inner(value,pos))
    def get_offset(self):return self.inner.get_offset()


def export(fig, stem, lang, caption, sources, transformations, values):
    folder = OUT / "figures"
    folder.mkdir(parents=True, exist_ok=True)
    if lang=="es":
        for ax in fig.axes:
            for axis in [ax.xaxis,ax.yaxis]:
                formatter=axis.get_major_formatter()
                if not isinstance(formatter,(NullFormatter,CommaFormatter)):axis.set_major_formatter(CommaFormatter(formatter))
    fig.canvas.draw()
    for ext in ["png", "pdf", "svg"]:
        fig.savefig(folder / f"{stem}_{lang}.{ext}", dpi=600, bbox_inches=None, facecolor="white")
    # Separate preview is only a convenient inspection view; the final raster is native 600 dpi.
    fig.savefig(folder / f"{stem}_{lang}_preview.png", dpi=150, bbox_inches=None, facecolor="white")
    plt.close(fig)
    refs=[]
    for source in sources:
        path=Path(source)
        if not path.is_absolute():path=TAB/path
        try:ref={"root":"project", "path":str(path.relative_to(ROOT))}
        except ValueError:
            try:ref={"root":"ASESORIAS_DATA_ROOT", "path":str(path.relative_to(DATA_ROOT))}
            except ValueError:ref={"root":"MF_DERIVED", "path":str(path.relative_to(DERIVED))}
        ref["sha256"]=hashlib.sha256(path.read_bytes()).hexdigest()
        refs.append(ref)
    entry = META["figures"].setdefault(stem, {"captions": {}})
    entry.update({"sources": refs, "transformations": transformations, "values": values})
    entry["captions"][lang] = caption
    (OUT / f"captions_{lang}.txt").write_text("\n\n".join(k + "\n" + v["captions"][lang] for k, v in META["figures"].items() if lang in v["captions"]), encoding="utf-8")
    (OUT / "figures_metadata.json").write_text(json.dumps(META, ensure_ascii=False, indent=2, default=lambda x: x.item() if isinstance(x, np.generic) else str(x)), encoding="utf-8")
    print(folder / f"{stem}_{lang}_preview.png", flush=True)


def age_label(s):
    return "≥" + s[:-1] if s.endswith("+") else s.replace("-", "–")


def figure1(lang):
    rates, o = load("burden_deaths_age_sex.csv"), load("burden_onset_sources.csv")
    male = o[o.sex == "Hombre"][["source", "group", "age_class", "n"]].rename(columns={"n": "n_m"})
    o = o.merge(male, on=["source", "group", "age_class"], how="left")
    fig, axs = plt.subplots(2, 2, figsize=(WIDTH, 166 / 25.4))
    fig.subplots_adjust(left=.105, right=.975, top=.87, bottom=.16, hspace=.58, wspace=.40)
    ax = axs[0, 0]
    age_grid=rates[rates.age_order>=9][["age_order","age5"]].drop_duplicates().sort_values("age_order")
    for g, line in [("dementia", "-"), ("parkinsonism", ":")]:
        for sex in COL:
            z = rates[(rates.group == g) & (rates.sex == sex) & (rates.age_order >= 9) & (rates.n > 0)].sort_values("age_order")
            ax.errorbar(z.age_order-9, z.rate, yerr=[z.rate-z.rate_lo, z.rate_hi-z.rate], color=COL[sex], marker=MARK[sex], ls=line, ms=3, lw=1, capsize=1.2)
    ax.set_xticks(age_grid.age_order-9, [age_label(v) for v in age_grid.age5], rotation=50, ha="right")
    ax.set_yscale("log")
    ax.set_ylabel(tr(lang, "Muertes / 100.000 personas-año\n(escala logarítmica)", "Deaths / 100,000 person-years\n(log scale)"))
    ax.set_xlabel(tr(lang, "Edad al fallecer (años)", "Age at death (years)"))
    label(ax, "A", tr(lang, "Mortalidad por edad, 2019–2023", "Age-specific mortality, 2019–2023"))
    disease_handles = [Line2D([], [], color="#333333", ls=ls, label=t) for ls, t in [("-", tr(lang,"Demencia","Dementia")), (":",tr(lang,"Parkinsonismo","Parkinsonism"))]]
    ax.legend(handles=disease_handles, loc="upper left", fontsize=6.8, handlelength=2)
    classes = ["<45", "45-64", "65-79", "80+"]
    used = set()
    records = []
    for ax, group, letter, title in [(axs[0,1],"dementia","B",tr(lang,"Demencia: razón mujeres/hombres","Dementia: female-to-male ratio")), (axs[1,0],"parkinsonism","C",tr(lang,"Parkinsonismo: razón por sexo","Parkinsonism: female-to-male ratio")), (axs[1,1],"hereditary","D",tr(lang,"Comparador: G10–G11","Comparator: G10–G11"))]:
        q = o[(o.group == group) & (o.sex == "Mujer") & o.age_class.isin(classes)]
        srcs = [s for s in SOURCES if s in q.source.unique()]
        for i, src in enumerate(srcs):
            z = q[q.source == src].set_index("age_class").reindex(classes)
            ok = (z.n >= 5) & (z.n_m >= 5) & np.isfinite(z.fm_ratio) & np.isfinite(z.fm_hi)
            es, en, color, marker = SOURCES[src]
            xx = np.arange(4) + (i-(len(srcs)-1)/2)*.12
            ax.errorbar(xx[ok], z.fm_ratio[ok], yerr=[(z.fm_ratio-z.fm_lo)[ok], (z.fm_hi-z.fm_ratio)[ok]], fmt=marker, color=color, ms=3.6, capsize=1.6, lw=.8)
            if ok.any():used.add(src)
            records.extend(z.loc[ok].reset_index().assign(group=group, source=src)[["group","source","age_class","n","n_m","fm_ratio","fm_lo","fm_hi"]].to_dict("records"))
        ax.axhline(1, color="#444444", ls="--", lw=.75)
        ax.set_yscale("log")
        ax.set_ylim(.10, 4)
        ax.set_yticks([.125,.25,.5,1,2,4], [num(v,lang,3).rstrip("0").rstrip(",.") for v in [.125,.25,.5,1,2,4]])
        ax.yaxis.set_minor_formatter(NullFormatter())
        ax.set_xticks(range(4), [age_label(v) for v in classes])
        ax.set_xlabel(tr(lang, "Edad en el registro (años)", "Age at recorded event (years)"))
        ax.set_ylabel(tr(lang, "Razón estandarizada (IC 95%)", "Standardised ratio (95% CI)"))
        label(ax,letter,title)
    sex_legend(fig,lang,y=.985)
    handles = [Line2D([], [], color=SOURCES[s][2], marker=SOURCES[s][3], ls="none", ms=4, label=SOURCES[s][0 if lang=="es" else 1]) for s in SOURCES if s in used]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(.5,.015), ncol=3, fontsize=6.7, columnspacing=1.2)
    cap = tr(lang,
        "Figura 1. Patrones por edad y sexo en fuentes rutinarias. A: mortalidad por demencia y parkinsonismo como causa básica, 2019–2023, con tasas específicas por edad e IC del 95%; se muestran todos los conteos positivos, incluidos los menores de cinco. Los ceros no se representan en el eje logarítmico. B–D: razón mujeres/hombres de tasas estandarizadas por edad, con IC del 95%, por clase de edad en el registro. El umbral de al menos cinco registros en cada sexo se aplica únicamente a las razones B–D; la ausencia de un símbolo no equivale a cero. Las series representan muertes (2019–2023), episodios GRD (2019–2024), primeros registros GRD observados por persona (2021–2024), ingresos REM A05 (2019–2025) y población en control/dependencia en diciembre de 2024. Cada fuente conserva su unidad y denominador: no se combinan sus conteos ni se interpretan como incidencia. G10–G11 corresponde a Huntington y ataxias hereditarias. Las edades son de registro o fallecimiento, no de inicio clínico. Fuentes: DEIS, GRD, REM e INE.",
        "Figure 1. Age and sex patterns across routine sources. A: age-specific mortality with dementia or parkinsonism as underlying cause, 2019–2023, with 95% confidence intervals; all positive counts are shown, including those below five. Zero counts are not plotted on the logarithmic axis. B–D: female-to-male ratios of age-standardised rates with 95% confidence intervals by age class at recorded event. The threshold of at least five records in each sex applies only to ratios in B–D; absent symbols do not indicate zero. Series represent deaths (2019–2023), GRD episodes (2019–2024), first observed GRD records per person (2021–2024), REM A05 entries (2019–2025), and programme caseload/dependency in December 2024. Each source retains its unit and denominator; counts are not pooled or interpreted as incidence. G10–G11 denotes Huntington disease and hereditary ataxias. Ages refer to recorded events or death, not clinical onset. Sources: DEIS, GRD, REM and INE.")
    export(fig,"Figure1_age_sources",lang,cap,["burden_deaths_age_sex.csv","burden_onset_sources.csv"],["Age-specific mortality restricted to age 45+; positive counts including <5 retained", "A: zero counts omitted from log axis; positions fixed by age_order", "Ratios B–D require >=5 records per sex", "Source periods retained; no pooling", "Logarithmic y axes"],{"ratio_estimates":records})


def figure2(lang):
    t = load("burden_deaths_dsr_year.csv")
    fig,axs=plt.subplots(2,2,figsize=(WIDTH,166/25.4))
    fig.subplots_adjust(left=.105,right=.975,top=.87,bottom=.11,hspace=.58,wspace=.39)
    for ax,group,letter,title in [(axs[0,0],"dementia","A",tr(lang,"Demencia: mortalidad","Dementia mortality")),(axs[0,1],"parkinsonism","B",tr(lang,"Parkinsonismo: mortalidad","Parkinsonism mortality"))]:
        for sex in COL:
            z=t[(t.group==group)&(t.sex==sex)&(t.age_class=="Todas")].sort_values("year")
            ax.plot(z.year,z.dsr,color=COL[sex],ls=STY[sex],marker=MARK[sex],markevery=3,ms=2.6)
            ax.fill_between(z.year,z.dsr_lo,z.dsr_hi,color=COL[sex],alpha=.13,lw=0)
            pre=z[z.status=="preliminar"]
            ax.scatter(pre.year,pre.dsr,marker=MARK[sex],s=22,facecolors="white",edgecolors=COL[sex],lw=.9,zorder=5)
        ax.set_ylim(0,None);ax.set_xticks([2002,2008,2014,2020,2024]);ax.tick_params(axis="x",rotation=35)
        ax.set_xlabel(tr(lang,"Año (2024: preliminar)","Year (2024: preliminary)"))
        ax.set_ylabel(tr(lang,"Muertes estandarizadas / 100.000", "Standardised deaths / 100,000"))
        label(ax,letter,title)
    ax=axs[1,0]
    for age,col,ls,m in [("Todas","#333333","-","o"),("65+","#8A5A13","--","^")]:
        z=t[(t.group=="dementia")&(t.sex=="Mujer")&(t.age_class==age)].sort_values("year")
        ax.plot(z.year,z.fm_ratio,color=col,ls=ls,marker=m,markevery=3,ms=2.6,label=tr(lang,"Todas las edades","All ages") if age=="Todas" else "≥65")
        ax.fill_between(z.year,z.fm_lo,z.fm_hi,color=col,alpha=.13,lw=0)
    ax.axhline(1,color="#555555",ls=":",lw=.8)
    ax.set_ylabel(tr(lang,"Razón mujeres/hombres (IC 95%)","Female-to-male ratio (95% CI)"));ax.set_xlabel(tr(lang,"Año","Year"))
    ax.set_xticks([2002,2008,2014,2020,2024]);ax.tick_params(axis="x",rotation=35)
    ax.legend(loc="upper left",fontsize=6.8)
    label(ax,"C",tr(lang,"Demencia: evolución de la razón","Dementia: change in the sex ratio"))
    ax=axs[1,1]
    z=t[(t.age_class=="Todas") & t.group.isin(["dementia","alzheimer","unspecified_dementia","vascular_dementia"])]
    p=z.pivot_table(index=["sex","year"],columns="group",values="n")
    coded=[]
    for sex in COL:
        q=p.loc[sex]
        for group,ls,m in [("alzheimer","-","o"),("unspecified_dementia","--","s"),("vascular_dementia",":","^")]:
            yy=100*q[group]/q.dementia
            ax.plot(q.index,yy,color=COL[sex],ls=ls,marker=MARK[sex],markevery=4,ms=2.1)
            coded.extend({"sex":sex,"year":int(y),"group":group,"pct":v} for y,v in yy.items())
    ax.set_ylim(0,100);ax.set_ylabel(tr(lang,"Porcentaje de muertes por demencia", "Percentage of dementia deaths"));ax.set_xlabel(tr(lang,"Año","Year"))
    ax.set_xticks([2002,2008,2014,2020,2024]);ax.tick_params(axis="x",rotation=35)
    label(ax,"D",tr(lang,"Tipo de demencia codificado","Coded dementia type"))
    h=[Line2D([],[],color="#333333",ls=ls,label=tx) for ls,tx in [("-",tr(lang,"Alzheimer","Alzheimer disease")),("--",tr(lang,"No especificada","Unspecified")),(":",tr(lang,"Vascular","Vascular"))]]
    ax.legend(handles=h,loc="upper right",fontsize=6.4,ncol=1)
    legend=sex_legend(fig,lang,y=.985)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    title_top=max(ax._left_title.get_window_extent(renderer).y1 for ax in axs[0,:])
    legend_bottom=legend.get_window_extent(renderer).y0
    legend_gap_mm=(legend_bottom-title_top)*25.4/fig.dpi
    if legend_gap_mm<2:raise ValueError("Figure2 sex legend requires an independent header band")
    cap=tr(lang,
        "Figura 2. Tendencias y codificación de la mortalidad, 2002–2024. A–B: tasas de mortalidad estandarizadas por edad, todas las edades, en mujeres y hombres; bandas: IC del 95%. Los símbolos abiertos identifican 2024, preliminar al corte del 23 de junio de 2026. C: razón mujeres/hombres de mortalidad por demencia para todas las edades y ≥65 años, con IC del 95%; la línea horizontal indica igualdad de tasas. D: proporción de muertes por demencia codificadas como Alzheimer, demencia no especificada o vascular, según sexo. Estas categorías no necesariamente agotan la definición amplia de demencia; el gráfico muestra codificación de causa básica, no validación clínica del subtipo. Las tasas y razones proceden de las tablas de mortalidad y no son la tendencia de conteos estimada mediante regresión de Poisson. Fuentes: defunciones DEIS e INE; población estándar OMS.",
        "Figure 2. Mortality trends and coding, 2002–2024. A–B: age-standardised mortality rates at all ages in women and men; bands indicate 95% confidence intervals. Open symbols identify preliminary 2024 data, released with a cut-off of 23 June 2026. C: female-to-male dementia mortality ratios for all ages and age ≥65, with 95% confidence intervals; the horizontal line indicates equal rates. D: proportions of dementia deaths coded as Alzheimer disease, unspecified dementia or vascular dementia by sex. These categories do not necessarily exhaust the broad dementia definition; this panel describes underlying-cause coding rather than clinically validated subtypes. Rates and ratios come from the mortality tables and do not represent the Poisson-regression trend in death counts. Sources: DEIS deaths and INE; WHO standard population.")
    export(fig,"Figure2_trends_coding",lang,cap,["burden_deaths_dsr_year.csv"],["All ages retained for DSR", "2024 explicitly preliminary", "Coding percentage = subgroup deaths / all dementia deaths", "No APC coefficients plotted", "Sex legend has a separate header band"],{"coding_percentages":coded,"mortality_rates":t[(t.age_class=="Todas")&t.group.isin(["dementia","parkinsonism"])].to_dict("records"),"legend_title_vertical_gap_mm":legend_gap_mm})


def figure3(lang):
    """Historical networks beside raw coded prevalence; no inferential labels."""
    import networkx as nx
    from matplotlib.collections import LineCollection
    from network_prevalence_panels import draw_grouped_prevalence, prevalence_legend_handles
    matrices=np.load(TAB/"network_dis_matrices.npz")
    nodes=load("network_nodes.csv").set_index("node")
    summary=load("network_dis_global.csv")
    prevalence=load("network_dis_prevalence.csv")
    sample=load("network_dis_sample.csv")
    diseases=[("AD",tr(lang,"Alzheimer","Alzheimer disease")),("UD",tr(lang,"Demencia no especificada","Unspecified dementia")),("PD",tr(lang,"Enfermedad de Parkinson","Parkinson disease"))]
    periods=["2019–2021","2022–2024"]
    weights=[matrices[f"{d}_WP{j+1}_pcor"] for d,_ in diseases for j in range(2)]
    mean=np.mean([np.abs(w) for w in weights],axis=0)
    graph=nx.Graph()
    for i in range(21):
        for j in range(i+1,21):graph.add_edge(i,j,weight=float(mean[i,j])+.03)
    position=nx.spring_layout(graph,weight="weight",seed=11,k=1.9/np.sqrt(21),iterations=2000)
    coords=np.array([position[i] for i in range(21)])
    coords=(coords-coords.mean(0))/np.abs(coords-coords.mean(0)).max(0)
    # Purely graphical collision resolution shared by all six panels.
    for _ in range(500):
        delta=np.zeros_like(coords)
        for i in range(21):
            for j in range(i+1,21):
                v=coords[i]-coords[j];dist=np.linalg.norm(v)
                if dist<.34:
                    push=.35*(.34-dist)*v/max(dist,1e-8)
                    delta[i]+=push;delta[j]-=push
        coords+=delta
        if np.max(np.abs(delta))<1e-7:break
    coords-=coords.mean(0)
    max_coord=float(np.abs(coords).max())+.21
    wmax=max(float(np.abs(w).max()) for w in weights)
    community={"ND":("#D4AED0","D",tr(lang,"Neurológico","Neurological")),"CMV":("#A8CDE0","o",tr(lang,"Cardiometabólico y vascular","Cardiometabolic and vascular")),"CHR":("#B5D9C6","s",tr(lang,"Otras condiciones crónicas","Other chronic conditions")),"GER":("#E9CB8F","^",tr(lang,"Síndromes geriátricos","Geriatric syndromes"))}
    short={"HYPOT":"THYR","DYSPH":"DYS"}
    fig=plt.figure(figsize=(WIDTH,225/25.4))
    row_bottoms=[.665,.390,.115]
    row_height=.225
    period_colours=["#6F91B5","#243E66"]
    period_hatches=["","///"]
    records=[];bar_records=[];bar_panels=[];row_axes=[]
    for row,(d,name) in enumerate(diseases):
        keys=[str(k) for k in matrices[f"keys_{d}"]]
        communities=["ND" if k=="DEM" else nodes.loc[k,"community"] for k in keys]
        period_frames=[];this_row_axes=[]
        for col,period in enumerate(periods):
            ax=fig.add_axes([.015+.27*col,row_bottoms[row],.255,row_height])
            this_row_axes.append(ax)
            w=matrices[f"{d}_WP{col+1}_pcor"]
            edge_rows=[]
            for positive,colour,ls in [(True,"#2166AC","solid"),(False,"#A82432","dashed")]:
                segments=[];widths=[]
                for i in range(21):
                    for j in range(i+1,21):
                        value=float(w[i,j])
                        if value==0 or (value>0)!=positive:continue
                        segments.append([coords[i],coords[j]])
                        widths.append(.2+2.4*abs(value)/wmax)
                        edge_rows.append({"node1":keys[i],"node2":keys[j],"weight":value})
                ax.add_collection(LineCollection(segments,colors=colour,linewidths=widths,linestyles=ls,alpha=.62,zorder=1))
            for group,(colour,shape,_) in community.items():
                ix=np.array([i for i,k in enumerate(communities) if k==group])
                ax.scatter(coords[ix,0],coords[ix,1],s=120,marker=shape,facecolor=colour,edgecolor="#333333",linewidth=.55,zorder=3)
            for i,key in enumerate(keys):ax.text(coords[i,0],coords[i,1],short.get(key,key),ha="center",va="center",fontsize=6.3,fontweight="bold",zorder=4)
            ax.set_aspect("equal");ax.set_xlim(-max_coord,max_coord);ax.set_ylim(-max_coord,max_coord);ax.axis("off")
            r=summary[(summary.disease==d)&(summary.sex=="Mujer")&(summary.period==period)].iloc[0]
            n=int(r.n)
            sample_n=sample[(sample.disease==d)&(sample.sex=="Mujer")&(sample.period==period)].n
            if len(sample_n)!=1 or int(sample_n.iloc[0])!=n:
                raise ValueError(f"Historical network/bar denominator differs: {d} {period}")
            raw=prevalence[(prevalence.disease==d)&(prevalence.sex=="Mujer")&(prevalence.period==period)].set_index("node")
            if raw.index.has_duplicates or any(key not in raw.index for key in keys):
                raise ValueError(f"Historical prevalence node coverage differs: {d} {period}")
            raw=raw.loc[keys].copy()
            unrounded=raw.pct.to_numpy(dtype=float)*n/100
            coded=np.rint(unrounded).astype(int)
            if not np.isfinite(unrounded).all() or not np.allclose(unrounded,coded,rtol=0,atol=1e-9) or np.any((coded<0)|(coded>n)):
                raise ValueError(f"Historical prevalence does not recover integer n/N: {d} {period}")
            frame=pd.DataFrame({"group":period,"node":keys,"pct":raw.pct.to_numpy(dtype=float),"n_coded":coded,"N":n})
            period_frames.append(frame)
            for rank,record in enumerate(frame.to_dict("records")):
                bar_records.append({"disease":d,"disease_label":name,"sex":"Women","period":period,
                    "observation_unit":"person-year","node_order":rank,"node":record["node"],
                    "display_abbreviation":short.get(record["node"],record["node"]),
                    "condition":"Dementia" if record["node"]=="DEM" else nodes.loc[record["node"],"label_en"],
                    "n_coded":record["n_coded"],"N":n,"pct":record["pct"]})
            ax.set_title(f"{'ABCDEF'[row*2+col]}  {name}\n{period}, n={count(n,lang)}",loc="left",fontsize=6.8,fontweight="bold",pad=5)
            records.append({"disease":d,"sex":"Mujer","period":period,"n_person_years":n,"n_linkage_clusters":int(r.n_linkage_clusters),"n_edges":len(edge_rows),"global_strength":float(np.abs(w[np.triu_indices(21,1)]).sum()),"edges":edge_rows})
        bar_ax=fig.add_axes([.665,row_bottoms[row],.305,row_height])
        this_row_axes.append(bar_ax);row_axes.append(this_row_axes)
        bar_meta=draw_grouped_prevalence(bar_ax,pd.concat(period_frames,ignore_index=True),keys,periods,periods,
            period_colours,period_hatches,abbreviations=short,x_max=80,
            title=f"{'GHI'[row]}  "+tr(lang,"Comorbilidad registrada (%)","Recorded comorbidity (%)"))
        if row<2:
            bar_ax.set_xlabel("")
        bar_panels.append({"disease":d,"panel":"GHI"[row],**bar_meta})
    fig.text(.5,.978,tr(lang,"Redes históricas de comorbilidad en mujeres ≥60 años","Historical comorbidity networks in women aged ≥60"),ha="center",fontsize=8.1,fontweight="bold")
    fig.text(.5,.957,tr(lang,"Observaciones GRD de personas-año, 2019–2024","GRD person-year observations, 2019–2024"),ha="center",fontsize=7.1)
    period_legend=fig.legend(handles=prevalence_legend_handles(periods,period_colours,period_hatches),
        loc="center",bbox_to_anchor=(.812,.929),ncol=2,fontsize=6.3,columnspacing=.8,handlelength=1.3,handletextpad=.4)
    hs=[Line2D([],[],marker=shape,mfc=color,mec="#333333",mew=.5,ls="none",ms=5,label=name) for color,shape,name in community.values()]
    hs.extend([Line2D([],[],color="#2166AC",lw=1.3,label=tr(lang,"Arista positiva","Positive edge")),Line2D([],[],color="#A82432",ls="--",lw=1.3,label=tr(lang,"Arista negativa","Negative edge"))])
    fig.legend(handles=hs,loc="lower center",bbox_to_anchor=(.5,.012),ncol=3,fontsize=6.7,columnspacing=1.1,handlelength=1.4)
    defs=tr(lang,"PARK, parkinsonismo; DEM, demencia; HTN, hipertensión; DM, diabetes; DLP, dislipidemia; IHD, cardiopatía isquémica; HF, insuficiencia cardiaca; AF, fibrilación auricular; CVD, enfermedad cerebrovascular; CKD, enfermedad renal crónica; THYR, hipotiroidismo; CLRD, enfermedad respiratoria crónica; OA, artrosis; CANC, cáncer; HEAR, hipoacusia; EPI, epilepsia; DEPR, depresión; ANEM, anemia; DEL, delirium; PU, úlcera por presión; DYS, disfagia; MALN, desnutrición.","PARK, parkinsonism; DEM, dementia; HTN, hypertension; DM, diabetes; DLP, dyslipidaemia; IHD, ischaemic heart disease; HF, heart failure; AF, atrial fibrillation; CVD, cerebrovascular disease; CKD, chronic kidney disease; THYR, hypothyroidism; CLRD, chronic respiratory disease; OA, osteoarthritis; CANC, cancer; HEAR, hearing loss; EPI, epilepsy; DEPR, depression; ANEM, anaemia; DEL, delirium; PU, pressure ulcer; DYS, dysphagia; MALN, malnutrition.")
    cap=tr(lang,
        "Figura 3. Redes históricas de comorbilidad en mujeres ≥60 años con registros de Alzheimer (A–B), demencia no especificada (C–D) o enfermedad de Parkinson (E–F) en episodios GRD de hospitales públicos, 2019–2024; se incluyen cirugía mayor ambulatoria (CMA) y otras actividades codificadas. Cada fila compara 2019–2021 con 2022–2024. La unidad es persona-año; una misma mujer puede contribuir a varios años y los identificadores de 2019–2020 no permiten deduplicación entre años. Son representaciones descriptivas: no se muestran pruebas temporales ni intervalos de confianza históricos. Las aristas son correlaciones parciales regularizadas, obtenidas mediante graphical lasso sobre correlaciones tetracóricas, EBIC γ=0,5 y umbral de selección del análisis original. Se conservan todas las aristas no nulas. Las seis redes comparten posiciones, tamaño constante de nodos y escala del grosor de aristas; líneas azules continuas: asociaciones positivas; rojas discontinuas: negativas. Formas y colores distinguen comunidades. El tamaño de los nodos no representa prevalencia ni centralidad. PARK se sustituye por DEM en la red de Parkinson. Las asociaciones entre diagnósticos registrados no identifican mecanismos causales. ",
        "Figure 3. Historical comorbidity networks and recorded prevalence in women aged ≥60 with Alzheimer disease (A–B), unspecified dementia (C–D), or Parkinson disease (E–F) recorded in public-hospital GRD episodes, 2019–2024, including day surgery (CMA) and other coded activities. Each row compares 2019–2021 with 2022–2024. G–I show the recorded percentages of all 21 corresponding conditions beside each pair of networks. Bars equal coded person-years divided by the same disease, sex and period denominator as the network, multiplied by 100; lighter solid bars show 2019–2021 and darker hatched bars show 2022–2024. All bar axes run from 0% to 80%. The unit is the person-year; a woman can contribute multiple years, and 2019–2020 identifiers do not support deduplication between years. Recorded percentages are descriptive summaries of these selected hospital records, rather than population or clinically validated prevalence. These displays have no historical temporal tests or confidence intervals. Edges are regularised partial correlations from graphical lasso of tetrachoric correlations, EBIC γ=0.5, and the original selection threshold. All non-zero edges are retained. The six networks share deterministic node positions, constant node area of 120 pt² and edge-width scale; solid blue edges indicate positive associations and dashed red edges negative associations. Shapes and colours identify communities. Node size does not encode prevalence or centrality. DEM replaces PARK in Parkinson disease networks. Associations between recorded diagnoses do not identify causal mechanisms. ")+defs
    csv=OUT/f"figures/source_data/Figure3_historical_networks_prevalence_{lang}.csv"
    csv.parent.mkdir(parents=True,exist_ok=True)
    bars=pd.DataFrame(bar_records)
    if len(bars)!=126 or bars[["disease","period","node"]].duplicated().any():
        raise ValueError("Expected exactly 126 historical prevalence bars")
    temporary=csv.with_suffix(".csv.tmp")
    bars.to_csv(temporary,index=False);temporary.replace(csv)
    fig.canvas.draw()
    minimum_font=min(t.get_fontsize() for t in fig.findobj(matplotlib.text.Text) if t.get_visible() and t.get_text())
    if minimum_font<6.3-1e-8:
        raise ValueError(f"Historical figure visible font below 6.3 pt: {minimum_font}")
    renderer=fig.canvas.get_renderer()
    first_box=matplotlib.transforms.Bbox.union([ax.get_tightbbox(renderer) for ax in row_axes[0]]+[period_legend.get_window_extent(renderer)])
    first_crop=[max(0,float(first_box.x0/fig.bbox.width)-.005),max(0,1-float(first_box.y1/fig.bbox.height)-.005),
                min(1,float(first_box.width/fig.bbox.width)+.01),min(1,float(first_box.height/fig.bbox.height)+.01)]
    META["figures"].setdefault("Figure3_historical_networks",{"captions":{}})["prevalence_source_csv"]=str(csv.relative_to(ROOT))
    export(fig,"Figure3_historical_networks",lang,cap,["network_dis_matrices.npz","network_nodes.csv","network_dis_global.csv","network_dis_prevalence.csv","network_dis_sample.csv",csv],["Historical matrices reused without inference", "Six women networks; shared deterministic spring layout seed11", "Graphical collision resolution dmin0.34", "21 constant-size nodes of120pt²; minimum visible font6.3pt", "All non-zero selected edges retained; common thickness scale", "Node index0 PARK replaced by DEM in Parkinson disease", "126 adjacent raw coded-prevalence bars use the same person-year denominators as each network", "All bar axes0–80%; darker recent-period bars hatched; no confidence intervals or temporal tests"],{"panels":records,"prevalence_panels":bar_panels,"positions":coords.tolist(),"edge_absolute_max":wmax,"node_font_points":6.3,"node_area_points_squared":120,"minimum_visible_font_pt":minimum_font,"bar_source_csv":str(csv.relative_to(ROOT)),"bar_count":126,"figure_width_mm":170,"figure_height_mm":225,"first_disease_row_crop":first_crop})


def figure6(lang):
    """Final independent-person prevalence and strength, with diagnostic resampling."""
    prevalence=load("network_unique_prevalence.csv")
    centrality=load("network_unique_centrality.csv")
    summary=load("network_unique_global.csv")
    matrices=np.load(TAB/"network_unique_matrices.npz")
    if len(summary)!=6 or not summary.nboot.ge(200).all() or not summary.nlambda.eq(50).all():raise ValueError("Incomplete unique-person networks")
    if len(centrality)!=126 or sum("_pcor" in name for name in matrices.files)!=12:raise ValueError("Incomplete unique-person node estimates")
    figure,axs=plt.subplots(2,3,figsize=(WIDTH,198/25.4))
    figure.subplots_adjust(left=.075,right=.98,top=.90,bottom=.11,hspace=.35,wspace=.41)
    diseases=[("AD",tr(lang,"Alzheimer","Alzheimer disease")),("UD",tr(lang,"Demencia no\nespecificada","Unspecified\ndementia")),("PD",tr(lang,"Enfermedad de\nParkinson","Parkinson\ndisease"))]
    smax=max(centrality.strength.max(),centrality.strength_adj.max())*1.07
    records=[]
    short={"HYPOT":"THYR","DYSPH":"DYS"}
    for col,(d,name) in enumerate(diseases):
        keys=[str(k) for k in matrices[f"keys_{d}"]]
        yy=np.arange(len(keys))[::-1]
        counts={s:int(summary[(summary.disease==d)&(summary.sex==s)].iloc[0].n) for s in COL}
        ax=axs[0,col]
        for sex,off in [("Mujer",.14),("Hombre",-.14)]:
            z=prevalence[(prevalence.disease==d)&(prevalence.sex==sex)].set_index("node").reindex(keys)
            ax.scatter(z.pct,yy+off,marker=MARK[sex],color=COL[sex],s=10,linewidths=.4,zorder=3)
        ax.set_xlim(0,100);ax.set_xticks([0,50,100]);ax.set_yticks(yy,[short.get(k,k) for k in keys],fontsize=6.3)
        ax.set_ylim(-.7,20.7);ax.grid(axis="x",color="#E7E7E7",lw=.4);ax.tick_params(axis="y",length=0,pad=2)
        ax.set_xlabel(tr(lang,"Diagnóstico registrado (%)","Condition coded (%)"))
        label(ax,"ABC"[col],name)
        ax.text(.01,1.01,f"n={count(counts['Mujer'],lang)}/{count(counts['Hombre'],lang)}",transform=ax.transAxes,fontsize=6.5,va="bottom")
        ax=axs[1,col]
        for sex,off in [("Mujer",.18),("Hombre",-.18)]:
            z=centrality[(centrality.disease==d)&(centrality.sex==sex)].set_index("node").reindex(keys)
            ax.scatter(z.strength,yy+off,color=COL[sex],marker=MARK[sex],s=9,linewidths=.4,zorder=3)
            ax.scatter(z.strength_adj,yy+off*.2,edgecolors=COL[sex],facecolors="white",marker=MARK[sex],s=9,linewidths=.6,zorder=4)
        ax.set_xlim(0,smax);ax.set_yticks(yy,[short.get(k,k) for k in keys],fontsize=6.3);ax.set_ylim(-.7,20.7)
        ax.grid(axis="x",color="#E7E7E7",lw=.4);ax.tick_params(axis="y",length=0,pad=2)
        ax.set_xlabel(tr(lang,"Fuerza del nodo (Σ |r parcial|)","Node strength (Σ |partial r|)"))
        label(ax,"DEF"[col],tr(lang,"Fuerza del nodo\nsensibilidad al ajuste","Node strength\nadjustment sensitivity"))
        records.append({"disease":d,"counts":counts,"prevalence":prevalence[prevalence.disease==d].to_dict("records"),"centrality":centrality[centrality.disease==d].to_dict("records")})
    handles=[]
    for sex in COL:
        for adjusted in [False,True]:
            handles.append(Line2D([],[],color=COL[sex],marker=MARK[sex],ls="none",mfc="white" if adjusted else COL[sex],ms=4,label=NAMES[lang][sex]+tr(lang,", ajustada" if adjusted else ", sin ajuste",", adjusted" if adjusted else ", unadjusted")))
    figure.legend(handles=handles,loc="lower center",bbox_to_anchor=(.5,.015),ncol=2,fontsize=6.7,columnspacing=2)
    figure.text(.5,.975,tr(lang,"Personas únicas 2021–2024: diagnósticos registrados y fuerza de nodos","Unique people 2021–2024: coded conditions and node strength"),ha="center",fontsize=8.1,fontweight="bold")
    cap=tr(lang,
        "Figura 6. Sensibilidad con personas únicas ≥60 años con episodios GRD registrados en hospitales públicos, 2021–2024, incluida cirugía mayor ambulatoria (CMA) y otras actividades codificadas. A–C: porcentaje de personas con cada diagnóstico codificado; los tamaños muestrales indican mujeres/hombres. D–F: fuerza de cada nodo (suma de correlaciones parciales absolutas), sin ajuste y condicionando por edad y profundidad de codificación. Los puntos llenos son estimaciones sin ajuste y los vacíos, ajustadas; la forma distingue sexo. Se usa el primer año elegible de cada persona y todos los diagnósticos registrados en sus episodios de ese año; no se reutilizan años posteriores y se excluyen identificadores con sexo discordante. La pertenencia a enfermedad se fija en ese año; Alzheimer y demencia no especificada son grupos disjuntos, mientras que Parkinson puede coexistir con demencia. Las abreviaturas corresponden a la Figura 3. Los porcentajes describen codificación hospitalaria, no prevalencia poblacional. Estas redes usan una unidad y ventana diferentes de las históricas. Son estimaciones descriptivas sin barras de incertidumbre; el ajuste no es una comparación temporal ni un efecto causal. Fuente: GRD.",
        "Figure 6. Independent-person sensitivity at age ≥60 with public-hospital GRD episodes, 2021–2024, including day surgery (CMA) and other coded activities. A–C: percentages of people with each condition coded; sample sizes are women/men. D–F: node strength (sum of absolute partial correlations), unadjusted and conditional on age and coding depth. Filled symbols denote unadjusted estimates and open symbols adjusted estimates; shapes identify sex. Each person's first eligible year and all diagnoses recorded in their episodes that year are used; later years are not reused, and identifiers with discordant sex are excluded. Disease membership is fixed in that year; Alzheimer disease and unspecified dementia are disjoint, whereas Parkinson disease may coexist with dementia. Abbreviations follow Figure 3. Percentages describe hospital coding, not population prevalence. These networks use a different unit and window from the historical networks. These are descriptive point estimates without uncertainty bars; adjustment is neither a temporal contrast nor a causal effect. Source: GRD.")
    export(figure,"Figure6_unique_people",lang,cap,["network_unique_prevalence.csv","network_unique_centrality.csv","network_unique_global.csv","network_unique_matrices.npz"],["First eligible year per unique person, 2021–2024", "All21fixed nodes; no selection of high-centrality results", "Raw diagnostic coding percentages", "Only descriptive point estimates, no bootstrap percentile bands or p values", "Adjusted strength shown without unsupported confidence intervals", "Identical scales across disease panels"],{"panels":records,"bootstrap_replicates_in_source_tables":int(summary.nboot.min()),"strength_scale_max":smax})


def figure4(lang):
    p,summary,icc=load("centers_panel.csv"),load("centers_summary.csv"),load("centers_icc.csv")
    fig,axs=plt.subplots(2,2,figsize=(WIDTH,174/25.4))
    fig.subplots_adjust(left=.105,right=.975,top=.92,bottom=.16,hspace=.62,wspace=.43)
    target="Ingresos A05 por demencia 60+"
    emax=p[(p.outcome==target)&(p.E>0)].E.max()
    xx=np.geomspace(.01,emax*1.2,400)
    vals={}
    for ax,sex,letter in [(axs[0,0],"Mujer","A"),(axs[0,1],"Hombre","B")]:
        z=p[(p.outcome==target)&(p.sex==sex)&(p.E>0)]
        for q,ls in [(.025,"--"),(.001,":")]:
            ax.plot(xx,poisson.ppf(q,xx)/xx,color="#333333",ls=ls,lw=.7)
            ax.plot(xx,poisson.ppf(1-q,xx)/xx,color="#333333",ls=ls,lw=.7)
        ax.axhline(1,color="#333333",lw=.65)
        for flag,marker,alpha in [("dentro","o",.32),("alto","^",.75),("bajo","v",.75)]:
            zz=z[z.out_998==flag]
            ax.scatter(zz.E,zz.smr,color=COL[sex],s=5 if flag=="dentro" else 9,marker=marker,alpha=alpha,lw=0,zorder=3)
        ax.set_xscale("log");ax.set_yscale("symlog",linthresh=.25,linscale=.5)
        ax.set_xlim(.01,emax*1.2);ax.set_ylim(0,320)
        ax.set_xticks([.01,.1,1,10,100],["0,01","0,1","1","10","100"] if lang=="es" else ["0.01","0.1","1","10","100"])
        ax.set_yticks([0,.25,1,4,16,64,256],["0",tr(lang,"0,25","0.25"),"1","4","16","64","256"])
        ax.yaxis.set_minor_formatter(NullFormatter());ax.xaxis.set_minor_formatter(NullFormatter())
        ax.set_xlabel(tr(lang,"Registros esperados por centro (log)","Expected records per centre (log)"))
        ax.set_ylabel(tr(lang,"Observados/esperados (symlog)","Observed/expected (symlog)"))
        label(ax,letter,tr(lang,f"Embudo: {NAMES[lang][sex].lower()}",f"Funnel: {NAMES[lang][sex].lower()}"))
        r=summary[(summary.outcome==target)&(summary.sex==sex)].iloc[0]
        ax.text(.04,.96,tr(lang,f"n={count(len(z),lang)} centros\n{num(r.pct_out998,lang,1)}% fuera del 99,8%",f"n={count(len(z),lang)} centres\n{num(r.pct_out998,lang,1)}% outside 99.8%"),transform=ax.transAxes,va="top",fontsize=6.8,bbox={"facecolor":"white","edgecolor":"none","alpha":.85,"pad":2})
        vals[sex]={"n":len(z),"zero_observed":int((z.O==0).sum()),"outside998_pct":r.pct_out998}
    ax=axs[1,0]
    z=p[p.outcome==target]
    w=z[z.sex=="Mujer"][["estab","eb","E"]].merge(z[z.sex=="Hombre"][["estab","eb","E"]],on="estab",suffixes=("_f","_m"))
    w=w[(w.E_f>=5)&(w.E_m>=5)]
    ax.scatter(w.eb_m,w.eb_f,s=7,color="#72568A",alpha=.55,lw=0)
    lo=min(w.eb_m.min(),w.eb_f.min())*.8;hi=max(w.eb_m.max(),w.eb_f.max())*1.2
    ax.plot([lo,hi],[lo,hi],color="#444444",ls="--",lw=.75)
    ax.set_xscale("log");ax.set_yscale("log");ax.set_xlim(lo,hi);ax.set_ylim(lo,hi)
    for axis in [ax.xaxis,ax.yaxis]:axis.set_minor_formatter(NullFormatter())
    rho=float(spearmanr(w.eb_m,w.eb_f).statistic)
    ax.text(.04,.97,f"n={len(w)}; ρ={num(rho,lang)}",transform=ax.transAxes,va="top",fontsize=7)
    ax.set_xlabel(tr(lang,"O/E suavizado: hombres (log)","Smoothed O/E: men (log)"));ax.set_ylabel(tr(lang,"O/E suavizado: mujeres (log)","Smoothed O/E: women (log)"))
    label(ax,"C",tr(lang,"Concordancia entre sexos","Concordance between sexes"))
    ax=axs[1,1]
    rows=[]
    for outcome,short in [(target,tr(lang,"Ingresos","Entries")),("Demencia en control P6 60+",tr(lang,"Demencia","Dementia")),("Parkinson en control P3 60+",tr(lang,"Parkinson","Parkinson"))]:
        for sex in COL:
            key=f"{outcome}, {sex.lower()} (log EB-SMR)"
            r=icc[icc.measure==key].iloc[0]
            rows.append((f"{short}\n{NAMES[lang][sex].lower()}",sex,r.icc_comuna,int(r.centers),int(r.comunas)))
    yy=np.arange(len(rows))[::-1]
    for y,(name,sex,value,ncentres,nmunicipalities) in zip(yy,rows):
        ax.barh(y,100*value,color=COL[sex],height=.7)
        ax.barh(y,100*(1-value),left=100*value,color="#DEDEDE",height=.7,hatch="///",edgecolor="#BBBBBB",lw=.2)
        ax.text(100*value+1,y,f"{100*value:.0f}%",va="center",fontsize=6.8)
        ax.text(98,y,f"n={ncentres}",ha="right",va="center",fontsize=6.5)
    ax.set_yticks(yy,[x[0] for x in rows],fontsize=6.5);ax.set_xlim(0,100);ax.set_xticks([0,50,100],["0%","50%","100%"])
    ax.set_xlabel(tr(lang,"Varianza entre centros", "Between-centre variance"))
    label(ax,"D",tr(lang,"Componente entre comunas","Between-municipality component"))
    h=[Line2D([],[],color="#444444",ls="--",label=tr(lang,"Límites 95%","95% limits")),Line2D([],[],color="#444444",ls=":",label=tr(lang,"Límites 99,8%","99.8% limits")),Line2D([],[],marker="^",color="#555555",ls="none",label=tr(lang,"Fuera: alto/bajo (▲/▼)","Outside: high/low (▲/▼)"))]
    fig.legend(handles=h,loc="lower center",bbox_to_anchor=(.5,.015),ncol=3,fontsize=6.6,columnspacing=1)
    variance_handles=[Patch(facecolor="#666666",label=tr(lang,"Entre comunas","Between municipalities")),Patch(facecolor="#DEDEDE",hatch="///",edgecolor="#BBBBBB",label=tr(lang,"Dentro de la comuna","Within municipality"))]
    fig.legend(handles=variance_handles,loc="lower center",bbox_to_anchor=(.72,.065),ncol=1,fontsize=6.4,labelspacing=.25)
    cap=tr(lang,
        "Figura 4. Variación del registro de demencia y Parkinson entre centros de APS, 2019–2025. A–B: ingresos REM A05 por demencia en ≥60 años, O/E por centro, frente al número esperado según tasas internas por sexo y edad (60–79 y ≥80) y población inscrita FONASA. Límites de control Poisson del 95% (discontinuos) y 99,8% (punteados); triángulos distinguen valores fuera del límite del 99,8%. Todos los centros y ceros se conservan; eje x logarítmico y eje y symlog con tramo lineal entre 0 y 0,25. C: O/E suavizado Poisson–gamma en ambos sexos, restringido a centros con ≥5 esperados en cada sexo; línea diagonal: igualdad; ρ de Spearman calculado en esa muestra común. D: porcentaje de varianza entre centros atribuible a diferencias entre comunas, obtenido del modelo de intercepto aleatorio de log O/E suavizado en la muestra definida por el análisis original; gris rayado: variación dentro de la comuna. No son intervalos de riesgo clínico ni indicadores validados de desempeño. Fuentes: REM, FONASA y catálogo DEIS.",
        "Figure 4. Variation in dementia and Parkinson registration between primary-care centres, 2019–2025. A–B: REM A05 dementia entries at age ≥60, observed/expected (O/E) per centre against expected records based on internal sex- and age-specific rates (60–79 and ≥80) and FONASA enrolment. Poisson control limits are 95% (dashed) and 99.8% (dotted); triangles identify values outside the 99.8% limits. All centres and zeros are retained; x axis is logarithmic and y axis uses symlog with a linear segment from 0 to 0.25. C: Poisson–gamma smoothed O/E in both sexes, restricted to centres with ≥5 expected records in each sex; diagonal: equality; Spearman ρ is calculated in this common sample. D: percentage of between-centre variance attributable to municipality differences from the random-intercept model of log smoothed O/E in the original analysis sample; hatched grey denotes variation within municipalities. These are neither clinical risk intervals nor validated performance indicators. Sources: REM, FONASA and DEIS establishment catalogue.")
    cap += tr(lang," En D, n indica centros: ingresos, 638 en 276 comunas; demencia en control, 730 en 288 comunas; Parkinson en control, 766 en 292 comunas. Las mismas muestras se utilizan en ambos sexos dentro de cada desenlace."," In D, n denotes centres: entries, 638 in 276 municipalities; dementia caseload, 730 in 288 municipalities; Parkinson caseload, 766 in 292 municipalities. Within each outcome, the same samples are used for both sexes.")
    export(fig,"Figure4_centres",lang,cap,["centers_panel.csv","centers_summary.csv","centers_icc.csv"],["All centres with E>0 retained in funnels", "Zeros shown without artificial replacement", "Symlog y threshold 0.25", "Scatter requires E>=5 in both sexes; low precision excluded symmetrically", "ICC estimates reused, not refitted; exclude rural posts according to original table"],{"funnels":vals,"scatter_n":len(w),"scatter_spearman":rho,"icc_rows":rows})


def rings(path):
    result=[]
    for feature in json.loads(path.read_text(encoding="utf-8"))["features"]:
        g=feature["geometry"]
        polys=[g["coordinates"]] if g["type"]=="Polygon" else g["coordinates"]
        for poly in polys:result.extend(np.asarray(r,float) for r in poly)
    return result


def map_base(ax,reg,com,zoom,first=False):
    for r in com if zoom else reg:ax.plot(r[:,0],r[:,1],color="#9D9D9D",lw=.3 if zoom else .23,zorder=0)
    if zoom:
        ax.set_xlim(-70.98,-70.43);ax.set_ylim(-33.75,-33.18)
        ax.set_xticks([-70.9,-70.5],["70,9°O","70,5°O"] if first=="es" else ["70.9°W","70.5°W"])
        ax.set_yticks([-33.7,-33.3],["33,7°S","33,3°S"] if first=="es" else ["33.7°S","33.3°S"])
        lat=-33.7;x=-70.93;km=10
        ax.set_aspect(1/np.cos(np.deg2rad(-33.5)))
    else:
        ax.set_xlim(-76,-66.2);ax.set_ylim(-56.2,-17.3)
        ax.set_xticks([-74,-68],["74°O","68°O"] if first=="es" else ["74°W","68°W"])
        ax.set_yticks([-20,-30,-40,-50],["20°S","30°S","40°S","50°S"])
        lat=-54.7;x=-75.4;km=250
        ax.add_patch(Rectangle((-70.98,-33.75),.55,.57,fill=False,ec="black",lw=.6,zorder=5))
        ax.set_aspect(1/np.cos(np.deg2rad(-35)))
    dx=km/(111.32*np.cos(np.deg2rad(lat)))
    ax.plot([x,x+dx],[lat,lat],color="black",lw=1.3,zorder=6)
    ax.text(x+dx/2,lat+(.35 if not zoom else .016),f"{km} km",ha="center",fontsize=6.4,zorder=7)
    ax.tick_params(labelsize=6.4,length=2,pad=2)
    for spine in ax.spines.values():spine.set_visible(True);spine.set_linewidth(.45);spine.set_color("#777777")


def figure5(lang):
    p,l,ls,mor=load("centers_panel.csv"),load("centers_lisa.csv"),load("centers_lisa_sex.csv"),load("centers_moran.csv")
    q=l[l.measure=="EB-SMR demencia, mujeres"][["estab","lat","lon","region13"]]
    eb=p[p.outcome=="Ingresos A05 por demencia 60+"].pivot(index="estab",columns="sex",values="eb").rename(columns={"Mujer":"eb_f","Hombre":"eb_m"})
    d=q.merge(eb,on="estab").merge(ls,on="estab")
    reg,com=rings(GEO/"regions.geojson"),rings(GEO/"comunas_rm.geojson")
    fig=plt.figure(figsize=(WIDTH,210/25.4))
    gs=fig.add_gridspec(2,4,left=.09,right=.98,top=.93,bottom=.17,height_ratios=[2.75,1],wspace=.18,hspace=.20)
    norm=LogNorm(.25,4)
    records={}
    for j,(key,sex) in enumerate([("eb_f","Mujer"),("eb_m","Hombre"),("cluster_women","Mujer"),("cluster_men","Hombre")]):
        is_eb=j<2
        for i,zoom in enumerate([False,True]):
            ax=fig.add_subplot(gs[i,j]);map_base(ax,reg,com,zoom,lang)
            if j>0:ax.tick_params(labelleft=False)
            title=(tr(lang,"O/E suavizado","Smoothed O/E") if is_eb else "LISA")+"\n"+NAMES[lang][sex].lower() if not zoom else tr(lang,"Santiago","Santiago")
            ax.set_title(f"{'ABCDEFGH'[i*4+j]}  {title}",loc="left",fontsize=7.4,fontweight="bold",pad=8)
            if is_eb:
                z=d.sort_values(key)
                for below,marker in [(True,"v"),(False,"^")]:
                    zz=z[(z[key]<1)==below]
                    sc=ax.scatter(zz.lon,zz.lat,c=zz[key],norm=norm,cmap="RdBu_r",marker=marker,s=5 if not zoom else 12,linewidths=.15,edgecolors="#555555",zorder=3)
            else:
                for k,(es,en,color,marker) in reversed(list(CLUSTER.items())):
                    z=d[d[key]==k]
                    ax.scatter(z.lon,z.lat,c=color,marker=marker,s=(3 if k=="No significativo" else 8) if not zoom else (9 if k=="No significativo" else 18),linewidths=.2,edgecolors="#555555",zorder=2 if k=="No significativo" else 4)
            if not zoom:
                # A single shared north arrow and coordinate axes make map orientation explicit.
                if j==0:ax.annotate("N",xy=(.88,.93),xytext=(.88,.84),xycoords="axes fraction",ha="center",fontsize=7,arrowprops={"arrowstyle":"-|>","lw":.65})
        if is_eb:
            records[key]={"n":len(d),"below_0.25":int((d[key]<.25).sum()),"above_4":int((d[key]>4).sum()),"min":float(d[key].min()),"max":float(d[key].max())}
        else:records[key]=d[key].value_counts().to_dict()
    cax=fig.add_axes([.13,.11,.34,.016])
    cb=fig.colorbar(sc,cax=cax,orientation="horizontal",extend="both",ticks=[.25,.5,1,2,4])
    cb.ax.xaxis.set_minor_formatter(NullFormatter());cb.ax.set_xticklabels(["0,25","0,5","1","2","4"] if lang=="es" else ["0.25","0.5","1","2","4"])
    cb.ax.tick_params(labelsize=6.8)
    cb.set_label(tr(lang,"O/E suavizado (color logarítmico)","Smoothed O/E (log colour scale)"),fontsize=7,labelpad=3)
    fig.text(.30,.048,"▼ O/E < 1; ▲ O/E ≥ 1",ha="center",fontsize=6.8)
    hs=[Line2D([],[],marker=v[3],color=v[2],markeredgecolor="#555555",markeredgewidth=.3,ls="none",ms=4.3,label=v[0 if lang=="es" else 1]) for v in CLUSTER.values()]
    fig.legend(handles=hs,loc="center",bbox_to_anchor=(.75,.095),ncol=2,fontsize=6.6,columnspacing=.8,handletextpad=.3)
    fig.text(.5,.975,tr(lang,f"Registro de demencia ≥60 años: centros de APS (n={len(d)})",f"Dementia registration at age ≥60: primary-care centres (n={len(d)})"),ha="center",fontsize=8.5,fontweight="bold")
    cap=tr(lang,
        "Figura 5. Distribución espacial del registro de demencia en centros de APS, 2019–2025. A–B: O/E de ingresos por demencia en ≥60 años, suavizado mediante modelo Poisson–gamma, en mujeres y hombres. C–D: conglomerados y valores atípicos locales LISA para cada sexo. E–H: los mismos centros en el acercamiento de Santiago, delimitado por el recuadro de los mapas nacionales. Se conservan los 637 centros de la muestra espacial original (criterios de precisión, exclusión de postas y coordenadas disponibles); no representan toda la red de APS. La escala de O/E es compartida, logarítmica, de 0,25 a 4; las puntas de la barra indican valores que exceden esos límites y que conservan el color extremo. Cada categoría LISA tiene forma y color propios: Alto–Alto y Bajo–Bajo señalan concordancia local; Alto–Bajo y Bajo–Alto, valores atípicos. LISA usa log O/E, ocho vecinos más cercanos, 999 remuestreos condicionales con reemplazo y p<0,05 sin corrección por comparaciones múltiples, por lo que los conglomerados son exploratorios. Coordenadas WGS84; relación de aspecto ajustada por latitud media; barras de escala aproximadas (250 km nacional y 10 km Santiago). Se muestra Chile continental con límites regionales y, en Santiago, comunales; no se representan territorios oceánicos ni antárticos. Fuentes: REM, FONASA, DEIS y cartografía de los derivados del proyecto.",
        "Figure 5. Spatial distribution of dementia registration in primary-care centres, 2019–2025. A–B: Poisson–gamma smoothed O/E of dementia entries at age ≥60 in women and men. C–D: local LISA clusters and spatial outliers by sex. E–H: the same centres in the Santiago enlargement, indicated by rectangles on the national maps. The original spatial sample of 637 centres is retained (precision criteria, rural-post exclusion and available coordinates); this sample does not represent the entire primary-care network. O/E colour limits are shared and logarithmic, from 0.25 to 4; colourbar extensions indicate observations beyond these limits, shown in the extreme colour. Each LISA category uses both shape and colour: High–High and Low–Low indicate local concordance; High–Low and Low–High indicate outliers. LISA uses log O/E, eight nearest neighbours, 999 conditional resamples with replacement and p<0.05 without multiple-comparison correction; clusters are exploratory. Coordinates are WGS84; aspect ratios are adjusted for mean latitude; scale bars are approximate (250 km nationally and 10 km in Santiago). Mainland Chile is shown with regional boundaries and Santiago with municipal boundaries; oceanic and Antarctic territories are omitted. Sources: REM, FONASA, DEIS and project-derived cartography.")
    cap += tr(lang," Los triángulos descendentes indican O/E<1 y los ascendentes, O/E≥1 en los mapas de O/E."," Downward triangles indicate O/E<1 and upward triangles O/E≥1 in the O/E maps.")
    source_files=["centers_panel.csv","centers_lisa.csv","centers_lisa_sex.csv","centers_moran.csv",str(GEO/"regions.geojson"),str(GEO/"comunas_rm.geojson")]
    provenance=GEO/"cartography_provenance.json"
    if provenance.exists():
        records["cartography_provenance"]=json.loads(provenance.read_text(encoding="utf-8"))
        source_files.append(str(provenance))
    export(fig,"Figure5_maps",lang,cap,source_files,["No new spatial inference; original cluster labels retained", "Shared log colour limits 0.25–4; extreme colours show values beyond limits", "Shape redundantly encodes below/above O/E=1", "WGS84 aspect corrected at mean latitude, approximate scale bars", "Santiago viewport -70.98 to -70.43 longitude, -33.75 to -33.18 latitude", "All 637 matched centres retained"],records)


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--figures",nargs="+",default=["1","2","4","5"]);parser.add_argument("--lang",nargs="+",default=["en"])
    args=parser.parse_args();style()
    OUT.mkdir(parents=True,exist_ok=True)
    existing=OUT/"figures_metadata.json"
    if existing.exists():
        previous=json.loads(existing.read_text(encoding="utf-8"));META["figures"].update(previous.get("figures",{}))
    for figure in args.figures:
        for lang in args.lang:
            globals()[f"figure{figure}"](lang)


if __name__=="__main__":main()
