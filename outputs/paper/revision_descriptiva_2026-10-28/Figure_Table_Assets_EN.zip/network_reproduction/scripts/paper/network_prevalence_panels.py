"""Shared descriptive comorbidity bars for the reviewed network figures.

Percentages refer to the recorded diagnoses and denominators supplied by the
caller. They are not inferred from edge weights or node size. No models, tests
or uncertainty intervals are fitted here.
"""
from __future__ import annotations

import numpy as np
from matplotlib.patches import Patch


def draw_grouped_prevalence(ax, frame, keys, groups, group_labels, colours,
                            hatches, abbreviations=None, x_max=80, title=None):
    """Draw two raw coded-percentage series beside a pair of networks.

    ``frame`` has group, node, pct, n_coded and N columns. The fixed ``keys``
    order is shared with the network nodes, including PARK/DEM substitution.
    Text is at least 6.3 pt at the authored physical figure size.
    """
    if len(groups) != 2 or len(keys) != 21:
        raise ValueError("Expected two groups and all 21 prespecified nodes")
    table = frame.set_index(["group", "node"], verify_integrity=True)
    abbreviations = abbreviations or {}
    y = np.arange(len(keys), dtype=float)
    result = []
    for j, group in enumerate(groups):
        rows = table.loc[[(group, key) for key in keys]]
        pct = rows["pct"].to_numpy(dtype=float)
        denominators = rows["N"].to_numpy(dtype=float)
        numerator = rows["n_coded"].to_numpy(dtype=float)
        if not np.isfinite(pct).all() or (pct < 0).any() or (pct > x_max).any():
            raise ValueError("Missing or out-of-scale recorded percentage")
        if (denominators <= 0).any() or not np.equal(denominators, np.rint(denominators)).all():
            raise ValueError("Recorded percentages require positive integer denominators")
        if not np.equal(numerator, np.rint(numerator)).all() or (numerator < 0).any() or (numerator > denominators).any():
            raise ValueError("Invalid integer coded-diagnosis counts")
        if not np.allclose(pct, 100 * numerator / denominators, rtol=0, atol=1e-10):
            raise ValueError("Coded percentages do not reproduce supplied n/N")
        ax.barh(y + (-.19 if j == 0 else .19), pct, height=.34,
                color=colours[j], edgecolor="white" if hatches[j] else colours[j], linewidth=.25,
                hatch=hatches[j], label=group_labels[j], zorder=3)
        result.append({"group": str(group), "label": group_labels[j],
                       "N": int(denominators[0]), "coded_counts": numerator.astype(int).tolist(),
                       "percentages": pct.tolist()})
    ax.set_yticks(y, [abbreviations.get(key, key) for key in keys], fontsize=6.3)
    ax.set_ylim(len(keys) - .35, -.65)
    ax.set_xlim(0, x_max)
    ax.set_xticks(np.arange(0, x_max + 1, 20))
    ax.tick_params(axis="y", length=0, pad=3)
    ax.tick_params(axis="x", length=2.5, labelsize=6.3, pad=2)
    ax.set_xlabel("Recorded prevalence (%)", fontsize=6.5, labelpad=3)
    ax.grid(axis="x", color="#DFE5E9", linewidth=.45, zorder=0)
    ax.set_axisbelow(True)
    for spine in ("left", "top", "right"):
        ax.spines[spine].set_visible(False)
    ax.spines["bottom"].set_color("#73808A")
    ax.spines["bottom"].set_linewidth(.5)
    if title:
        ax.set_title(title, loc="left", fontsize=7.1, fontweight="bold", pad=5)
    return {"node_order": list(keys), "zero_baseline": True, "scale_percent": [0, x_max],
            "estimator": "100 × coded diagnoses / supplied eligible observation denominator",
            "uncertainty": "Descriptive observed percentages; no inferential interval", "groups": result}


def prevalence_legend_handles(labels, colours, hatches):
    return [Patch(facecolor=colour, edgecolor="white" if hatch else colour, hatch=hatch, linewidth=.25, label=label)
            for label, colour, hatch in zip(labels, colours, hatches)]
