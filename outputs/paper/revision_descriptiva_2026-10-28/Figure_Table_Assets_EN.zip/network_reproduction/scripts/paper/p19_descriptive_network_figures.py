"""Regenerate the reviewed historical and unique-person figures in both languages.

Requires final validated network_unique_* aggregates. No models are fitted here.
"""
from __future__ import annotations

import argparse
import json

import p18_descriptive_review_figures as figures


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--historical-only",action="store_true")
    parser.add_argument("--lang",nargs="+",default=["en"])
    args=parser.parse_args()
    figures.style()
    existing=figures.OUT/"figures_metadata.json"
    if existing.exists():figures.META["figures"].update(json.loads(existing.read_text(encoding="utf-8")).get("figures",{}))
    for language in args.lang:figures.figure3(language)
    if not args.historical_only:
        for language in args.lang:figures.figure6(language)


if __name__=="__main__":main()
