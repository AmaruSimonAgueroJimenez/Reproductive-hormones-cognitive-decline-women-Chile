English scientific asset collection

24 figures and 24 tables are supplied for author selection.
Each figure has a native-resolution PNG, editable SVG and vector PDF. Tables are CSV files. Captions specify source scope and interpretation. Candidate IDs do not assign material to the main article or supplement.

Core evidence: 71e7fad9e23d958a0103e6f8191aa7f5d28cbdf36d4c7b68514bced88adeff24
Candidate evidence: 889d6a7e6ae62ae71686fe96c9219b7b863c4e1743091968ac6612ae89ff4f88

The network_reproduction folder includes exact plotting sources, saved aggregate correlation matrices and percentages, environment pins and integrity checks for reconstructing Figure 3 and Figures S15-S16, including their prevalence bars, without patient records. Start with network_reproduction/README_EN.md. This plotting reconstruction does not refit the networks.

Source records and encrypted patient identifiers are excluded. Complete source-record reconstruction remains documented in the project Quarto report and scripts/run_descriptive_review.py.
