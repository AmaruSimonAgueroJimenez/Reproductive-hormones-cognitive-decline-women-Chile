English scientific asset collection

24 figures and 24 tables are supplied for author selection.
Each figure has a native-resolution PNG, editable SVG and vector PDF. Tables are CSV files. Captions specify source scope and interpretation. Candidate IDs do not assign material to the main article or supplement.

Core evidence: 847f2ac4f66c226a6716f72ce88516f1e1e11ccfe28b0552d8e80880921895da
Candidate evidence: 7c1623ce57aefc278c48eb4633932ff50c3fc8072e2189ae6719604e03bafa7c

Source records and encrypted patient identifiers are excluded. Full reproduction is documented in the project Quarto report and scripts/run_descriptive_review.py.
