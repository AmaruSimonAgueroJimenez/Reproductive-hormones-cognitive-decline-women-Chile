# Reproducing the hormonal care and diagnostic recording extension

This extension has two reproducibility levels. The public aggregate path regenerates all displayed tables, figures, manuscript paragraphs and facility association models without reading individual hospital records. The raw refresh path requires the same source releases on the external data volume, the documented upstream population/context preparation, and permission to analyse those records. Public aggregates are not independent validation of the raw data.

## Executed scope

- REM Series A and P: 2019–2025, annual coded dictionaries, programme activity and December caseloads.
- DEIS national principal-diagnosis hospital discharges: 2001–2024.
- FONASA GRD public-hospital episodes: 2019–2024; primary hospital population recorded women with admission-age proxy at least45.
- Facility association: earlier MHT recording during2019–2021 and later identified dementia/Parkinson caseload during2022–2025. Analysis rules were recorded before estimating these new coefficients, after earlier exploratory work and source-feasibility checks. This is not preregistration.

## Public aggregate rebuild

From the project root, use Python3.14 with the versions in `software_versions.json`. Quarto1.10.18 produced the delivered HTML. The complete project includes the public basemaps and shared style helper used by the REM map.

```bash
python3 scripts/run_access_diagnostic_extension.py --html
python3 scripts/run_access_diagnostic_extension.py --word --html
python3 scripts/run_access_diagnostic_extension.py --verify-only
```

The HTML itself executes the public rebuild every time it is rendered. `freeze` and notebook caching are disabled. Code is folded for reading but remains inspectable, and the report includes the complete computational source for its public derivations. Run Quarto jobs sequentially in this project because concurrent Jupyter renders can share temporary files.

The scientific interpreter and Word authoring interpreter are separate. The delivered build uses `/Library/Frameworks/Python.framework/Versions/3.14/bin/python3` for analysis and the Codex bundled Python for deterministic DOCX authoring. On another host set `DOCX_PYTHON` to a Python environment with the recorded python-docx, Pillow and lxml versions. The QMD uses the scientific interpreter when that host path exists, otherwise the active kernel interpreter. The orchestrator uses `QUARTO_PYTHON` for its HTML build.

The standalone component commands, in order, are:

```bash
python3 scripts/access_extension/rem_tables_figures.py
python3 scripts/access_extension/rem_report_content.py
python3 scripts/access_extension/neuro_reporting_figures.py
python3 scripts/access_extension/hospital_analysis.py --aggregates-only
python3 scripts/access_extension/association_analysis.py
python3 scripts/access_extension/association_report_content.py
python3 scripts/access_extension/access_report.py --qmd
```

The shared evidence binding is a computational interchange file. Institutional datasets, manuals and classifications listed in the manuscript are the scientific sources. No JSON file is cited as an original data source.

## Required public aggregate inputs

The source package preserves the public facility-year hormonal table, neurological facility-year and stage tables, observed activity/context cells summarised at facility-month level, hospital diagnostic and QC aggregates, annual dictionary proof, reconciliation tables, shared public cartography, scripts and report sources. These contain no patient identifiers. Public establishment identifiers and facility coordinates are retained for geographic reproducibility.

The REM map additionally uses `scripts/paper/p18_descriptive_review_figures.py` and the public `regions.geojson` and `comunas_rm.geojson` under `outputs/paper/revision_descriptiva_2026-10-28/source_data/geo`. Biblioteca del Congreso Nacional is credited for the boundaries. Original-source context and earlier frozen summaries used for reconciliation remain separate from the new result counts.

## Raw source refresh

```bash
python3 scripts/run_access_diagnostic_extension.py --refresh-raw --word --html
```

The current raw data root is `/Volumes/Datos/Asesorias_Data`, and private derived files remain under its `derived/Reproductive-hormones-cognitive-decline-women-Chile` directory. REM scripts support `ASESORIAS_DATA_ROOT` and `MF_DERIVED`; inspect the hospital source manifest for its exact configured paths. The source package does not redistribute individual hospital records or encrypted identifiers.

The existing project prepares population/context inputs with `scripts/mf00_denominators.py` and `scripts/mf06_establishments.py`. These include municipal INE single-age population, same-year FONASA enrolled-person snapshots, facility catalogue linkage and contemporary municipal poverty/rurality. Raw neurological reconciliation additionally compares against the historical selected-row cache from `scripts/mf04_rem.py`. Those upstream caches and original releases must exist for a full refresh from this project state. They are explicit dependencies rather than an implied fresh-machine download service. The new hormonal denominator construction reads the original FONASA bands directly, independently prorates ages45–64, and keeps unavailable population shares missing. Neurological denominators are independently reconciled against the original annual FONASA files.

The raw sequence is annual dictionary audit, one shared physical REM extraction, hormonal re-analysis, neurological re-analysis, complete-source hospital scanning, hospital private episode/person analysis, then the public commands above. Raw source manifests retain file hashes, source row totals, coding windows and dictionary mappings. Exact duplicate REM rows are removed; conflicting keys are quarantined. Source blanks, absent rows, explicit zeros, structurally absent fields and accounting-identified values remain distinct.

## Statistical checks and interpretive limits

The association script exports exact eligibility cohorts, internal age-sex-year reference rates, all36 model specifications including two dementia models withheld by the cluster gate, paired-sex contrasts, source-consistency sensitivities, cluster covariance verification and spatial residual diagnostics. Its manual cluster score sandwich is numerically compared with the library implementation. The strict focal model has97 facilities and61 municipal clusters; the numerator-flag sensitivity has96 facilities and60 clusters. Their different estimates are retained, not selected for significance. The mean model is Poisson with municipal-cluster t inference; large overdispersion is explicitly reported.

No absent REM stage or month is replaced by zero. Annual dementia-entry reporting does not support the required complete longitudinal cohort and is not forced into an association model. Caseloads are repeated December records, not unique people, incident disease or observed person-time. Hospital code co-recording is too sparse for a clinically interpretable adjusted hormonal-effect model. Provider coordinates do not measure residential travel or appointment access.

## Deliverable verification

The HTML validator compares every substantive paragraph, all native table cells and all embedded PNG hashes with the shared evidence. The Word validator performs the same checks and verifies continuous line-numbering settings. The Word is separately rendered and every page visually inspected. The figure bank includes SVG, PDF and 600 dpi PNG at stated physical sizes; these are general scientific exports, without a claim of compliance with an unspecified journal.

`reproducibility_manifest.json` records delivered file hashes. `software_versions.json` records the environments. Figure/page QA records document the actual inspection and are not substitutes for author review. Independent replication still requires obtaining source releases and applying the operational definitions anew.
