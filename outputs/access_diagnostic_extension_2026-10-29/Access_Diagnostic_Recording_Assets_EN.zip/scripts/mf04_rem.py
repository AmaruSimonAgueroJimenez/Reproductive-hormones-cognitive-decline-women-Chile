"""REM Series A y P 2019-2025: filas de demencia, Parkinson, funcionalidad, climaterio, THM y
anticoncepción hormonal (config/rem_neuro.yaml), decodificadas a formato largo por sexo y edad.

Las filas se extraen con grep (rápido sobre archivos de 0,3-0,7 GB) y se conservan por establecimiento
(unidad espacial más fina del REM); las filas con valor cero se omiten.
Serie A: suma anual de los meses. Serie P: cortes de junio y diciembre.
Salidas (derived/rem): rem_{A|P}_{año}.csv.gz y rem_long.csv.gz combinado
Control: outputs/multifuente/controls/rem_layout_checks.csv (suma de edades vs total por sexo)

Uso: python scripts/mf04_rem.py [--years 2019-2025] [--skip-existing]
"""
from __future__ import annotations

import io
import subprocess

import numpy as np
import pandas as pd

import mf_common as c

STEP = "mf04"
CFG = c.load_yaml("rem_neuro.yaml")["rows"]
COLS = [f"Col{i:02d}" for i in range(1, 51)]
HEAD = ["Mes", "IdServicio", "Ano", "IdEstablecimiento", "CodigoPrestacion", "IdRegion", "IdComuna"] + COLS
THM_AGES = {"Col02": "<45", "Col03": "45-49", "Col04": "50-54", "Col05": "55-59", "Col06": "60-64"}
CONTRA_AGES = {f"Col{i:02d}": a for i, a in zip(range(2, 11), ["<15", "15-19", "20-24", "25-29", "30-34",
                                                                "35-39", "40-44", "45-49", "50-54"])}


def grep_rows(path, codes: list[str]) -> pd.DataFrame:
    pat = ";(" + "|".join(codes) + ");"
    res = subprocess.run(["grep", "-E", pat, str(path)], capture_output=True, check=False)
    txt = res.stdout.decode("latin-1")
    if not txt:
        return pd.DataFrame(columns=HEAD)
    d = pd.read_csv(io.StringIO(txt), sep=";", header=None, names=HEAD, dtype={"CodigoPrestacion": str},
                    usecols=range(len(HEAD)))
    d = d[d["CodigoPrestacion"].isin(codes)]
    d[COLS] = d[COLS].apply(pd.to_numeric, errors="coerce").fillna(0)
    return d


def decode(d: pd.DataFrame, code: str, year: int) -> pd.DataFrame:
    meta = CFG[code]
    x = d[d["CodigoPrestacion"] == code]
    if x.empty or year < meta.get("from_year", 0):
        return pd.DataFrame()
    keys = ["Mes", "IdEstablecimiento", "IdComuna"]
    lay = meta["layout"]
    pieces = []

    def put(col: str, sex: str, age: str):
        pieces.append(x[keys].assign(sex=sex, age=age, value=x[col].to_numpy()))

    if lay == "sex_age17":
        put("Col02", "Hombre", "Total")
        put("Col03", "Mujer", "Total")
        for i, a in enumerate(c.AGE5_80):
            put(f"Col{4 + 2 * i:02d}", "Hombre", a)
            put(f"Col{5 + 2 * i:02d}", "Mujer", a)
    elif lay == "sex_total":
        put("Col02", "Hombre", "Total")
        put("Col03", "Mujer", "Total")
    elif lay == "total":
        put("Col01", "Total", "Total")
    elif lay == "climaterio":
        put("Col01" if year <= 2024 else "Col02", "Mujer", "45-64")
        if year >= 2025:
            put("Col01", "Mujer", "<45")
    elif lay == "thm_age":
        put("Col01", "Mujer", "Total")
        for col, a in THM_AGES.items():
            put(col, "Mujer", a)
    elif lay == "contraception_age":
        put("Col01", "Mujer", "Total")
        for col, a in CONTRA_AGES.items():
            put(col, "Mujer", a)
    out = pd.concat(pieces)
    out = out.groupby(keys + ["sex", "age"], as_index=False)["value"].sum()
    out = out[out["value"] != 0]
    return out.assign(code=code, year=year, serie=meta["serie"], block=meta["block"],
                      stage=meta.get("stage", "total"))


def layout_check(d: pd.DataFrame, code: str, year: int) -> dict | None:
    if CFG[code]["layout"] != "sex_age17" or year < CFG[code].get("from_year", 0):
        return None
    x = d[d["CodigoPrestacion"] == code]
    if CFG[code]["serie"] == "P":
        x = x[x["Mes"] == 12]
    if x.empty:
        return None
    s = x[COLS].sum()
    h_b = sum(s[f"Col{4 + 2 * i:02d}"] for i in range(17))
    m_b = sum(s[f"Col{5 + 2 * i:02d}"] for i in range(17))
    return {"code": code, "year": year, "total": s["Col01"], "men": s["Col02"], "women": s["Col03"],
            "men_age_sum": h_b, "women_age_sum": m_b,
            "max_rel_diff": max(abs(h_b - s["Col02"]) / max(s["Col02"], 1), abs(m_b - s["Col03"]) / max(s["Col03"], 1))}


def one_year(y: int) -> None:
    checks = []
    for serie, folder in (("A", c.SRC["rem_a"]), ("P", c.SRC["rem_p"])):
        path = folder / f"Serie{serie}_{y}.csv"
        codes = [k for k, v in CFG.items() if v["serie"] == serie]
        if not path.exists():
            c.log(STEP, f"AVISO falta {path.name}")
            continue
        d = grep_rows(path, codes)
        if serie == "P":
            d = d[d["Mes"].isin([6, 12])]
        long = pd.concat([decode(d, k, y) for k in codes])
        if serie == "A" and not long.empty:
            months = d.groupby("CodigoPrestacion")["Mes"].nunique()
            long = long.groupby(["IdEstablecimiento", "IdComuna", "sex", "age", "code", "year", "serie", "block", "stage"],
                                as_index=False)["value"].sum()
            long["months"] = long["code"].map(months)
            long["Mes"] = 0
        long = long.rename(columns={"IdEstablecimiento": "estab", "IdComuna": "comuna", "Mes": "month"})
        long.to_csv(c.derived("rem") / f"rem_{serie}_{y}.csv.gz", index=False)
        checks += [r for k in codes if (r := layout_check(d, k, y))]
        c.log(STEP, f"{y} serie {serie}: {len(d):,} filas fuente, {long['code'].nunique()} códigos")
    if checks:
        pd.DataFrame(checks).to_csv(c.derived("rem") / f"rem_checks_{y}.csv", index=False)


def combine() -> None:
    folder = c.derived("rem")
    files = sorted(folder.glob("rem_[AP]_[0-9]*.csv.gz"))
    if not files:
        return
    d = pd.concat(pd.read_csv(f, dtype={"code": str}) for f in files)
    d.to_csv(folder / "rem_long.csv.gz", index=False)
    ch = pd.concat(pd.read_csv(f, dtype={"code": str}) for f in sorted(folder.glob("rem_checks_*.csv")))
    ch["layout_ok"] = ch["max_rel_diff"] <= 0.02
    c.save(ch.sort_values(["code", "year"]), "rem_layout_checks.csv", c.CTRL)
    c.log(STEP, f"combinado: {d.year.min()}-{d.year.max()}; layouts con diferencia >2%: {int((~ch.layout_ok).sum())}")


def main() -> None:
    c.ensure_dirs()
    lo, hi = c.YEARS["rem"]
    for y in c.years_arg(list(range(lo, hi + 1))):
        if c.flag("--skip-existing") and (c.derived("rem") / f"rem_P_{y}.csv.gz").exists():
            continue
        one_year(y)
    if not c.flag("--no-combine"):
        combine()


if __name__ == "__main__":
    main()
