"""Centros de salud: catálogo DEIS, población inscrita FONASA por centro y denominadores.

La unidad espacial más fina disponible para la atención primaria es el establecimiento que
reporta al REM. Cada centro de APS tiene su población inscrita en FONASA por sexo, tramo de edad y
tramo de ingreso (A-D), lo que permite tasas, estandarización indirecta y un indicador de
privación propio del centro (% de inscritos en tramo A).

Salidas:
  derived/denominators/fonasa_centros.csv.gz  año x centro x sexo x tramo de edad armonizado
  outputs/multifuente/tables/centers_context.csv  atributos por centro (tipo, dependencia, coordenadas,
      comuna, región, inscritos, % tramo A, mujeres 45-64 y 15-49 inscritas, 60+ por sexo)
  derived/geo/regions.geojson  contornos regionales simplificados para mapas (si hay geopandas)
"""
from __future__ import annotations

import numpy as np
import pandas as pd

import mf_common as c

STEP = "mf06"
BANDS = ["0-19", "20-39", "40-59", "60-79", "80+"]


def catalog() -> pd.DataFrame:
    frames = []
    for key in ("estab_vigentes", "estab_catalog"):
        p = c.SRC[key]
        if p.exists():
            frames.append(pd.read_csv(p, sep=";", dtype=str, encoding="utf-8"))
    d = pd.concat(frames).drop_duplicates("EstablecimientoCodigo")
    out = pd.DataFrame({
        "estab": pd.to_numeric(d["EstablecimientoCodigo"], errors="coerce"),
        "name": d["EstablecimientoGlosa"],
        "type": d["TipoEstablecimientoGlosa"],
        "dependency": d["DependenciaAdministrativa"],
        "level": d["NivelAtencionEstabglosa"],
        "service": d["SeremiSaludGlosa_ServicioDeSaludGlosa"],
        "comuna": pd.to_numeric(d["ComunaCodigo"], errors="coerce"),
        "lat": pd.to_numeric(d["Latitud"].str.replace(",", "."), errors="coerce"),
        "lon": pd.to_numeric(d["Longitud"].str.replace(",", "."), errors="coerce"),
        "status": d["EstadoFuncionamiento"].str.strip().str.capitalize(),
    }).dropna(subset=["estab"])
    out["estab"] = out["estab"].astype(int)
    bad = ~(out.lat.between(-56.5, -17) & out.lon.between(-76, -66))      # Chile continental e insular cercano
    out.loc[bad, ["lat", "lon"]] = np.nan
    t = out["type"].fillna("")
    out["type_group"] = np.select(
        [t.str.contains("CESFAM|Consultorio General", regex=True), t.str.contains("CECOSF"), t.str.contains("Posta"),
         t.str.contains("Hospital"), t.str.contains("COSAM")],
        ["CESFAM", "CECOSF", "Posta rural", "Hospital", "COSAM"], "Otro")
    return out


def harmonise_band(txt: pd.Series) -> pd.Series:
    lo = pd.to_numeric(txt.astype(str).str.extract(r"^(\d+)")[0], errors="coerce")
    return pd.cut(lo, [-1, 19, 39, 59, 79, 200], labels=BANDS).astype(str).replace("nan", np.nan)


def fonasa_centers() -> pd.DataFrame:
    frames = []
    for y in range(2019, 2026):
        p = c.SRC["fonasa_aps"] / f"Inscritos_APS_{y}12.csv"
        if not p.exists():
            continue
        try:
            d = pd.read_csv(p, dtype=str, encoding="utf-8")
        except UnicodeDecodeError:
            d = pd.read_csv(p, dtype=str, encoding="latin-1")
        d = d.rename(columns={"TRAMO": "TRAMO_FONASA"})
        d["n"] = pd.to_numeric(d["TOTAL_INSCRITOS"], errors="coerce").fillna(0)
        d["estab"] = pd.to_numeric(d["COD_CENTRO"].str.strip(), errors="coerce")
        d["sex"] = c.sex_std(d["SEXO"])
        d["band"] = harmonise_band(d["EDAD_TRAMO"])
        # los tramos decenales 2024+ se colapsan a los quinquenios comunes (0-19 ... 80+)
        d["band10"] = d["EDAD_TRAMO"].str.extract(r"^(\d+)")[0]
        d["year"] = y
        frames.append(d.groupby(["year", "estab", "sex", "band", "band10", "TRAMO_FONASA"], dropna=False)["n"].sum().reset_index())
    out = pd.concat(frames).rename(columns={"TRAMO_FONASA": "tramo"})
    out.to_csv(c.derived("denominators") / "fonasa_centros.csv.gz", index=False)
    c.log(STEP, f"FONASA por centro: {out.estab.nunique()} centros, {out.year.min()}-{out.year.max()}")
    return out


def prorate(fon: pd.DataFrame, cat: pd.DataFrame, pop: pd.DataFrame, lo_t: int, hi_t: int) -> pd.DataFrame:
    """Inscritas en [lo_t, hi_t] por centro: cada tramo FONASA se reparte con la estructura por edad simple
    de las mujeres de la comuna del centro (INE base 2017)."""
    w = pop[pop.sex == "Mujer"][["year", "comuna", "age", "pop"]]
    f = fon[(fon.sex == "Mujer")].copy()
    bounds = f["band10"].astype(float)
    f["lo"] = bounds
    f["hi"] = np.where(f["year"] >= 2024, bounds + 9, bounds + 19)
    f.loc[f["lo"] >= 80, "hi"] = 200
    f = f.dropna(subset=["lo"]).merge(cat[["estab", "comuna"]], on="estab", how="inner")
    f = f.groupby(["year", "estab", "comuna", "lo", "hi"])["n"].sum().reset_index()
    parts = []
    for (lo, hi), g in f.groupby(["lo", "hi"]):
        if hi < lo_t or lo > hi_t:
            continue
        ww = w[w.age.between(lo, min(hi, 200))]
        tot = ww.groupby(["year", "comuna"])["pop"].sum()
        tgt = ww[ww.age.between(max(lo, lo_t), min(hi, hi_t))].groupby(["year", "comuna"])["pop"].sum()
        g = g.merge((tgt / tot).rename("share").reset_index(), on=["year", "comuna"], how="left")
        parts.append(g.assign(part=g["n"] * g["share"].fillna(0))[["year", "estab", "part"]])
    return pd.concat(parts).groupby(["year", "estab"])["part"].sum().reset_index()


def regions_geojson() -> None:
    try:
        import geopandas as gpd
    except ImportError:
        c.log(STEP, "geopandas no disponible: mapas sin contornos regionales")
        return
    shp = c.SRC["regions_shp"]
    if not shp.exists():
        c.log(STEP, f"AVISO sin {shp}")
        return
    g = gpd.read_file(shp).to_crs(4326)
    g["geometry"] = g.geometry.simplify(0.01, preserve_topology=True)
    g = g.explode(index_parts=False)
    g = g[g.geometry.area > 0.0005]
    g = g[g.geometry.centroid.x > -80]                        # excluye islas oceánicas
    g[["geometry"]].to_file(c.derived("geo") / "regions.geojson", driver="GeoJSON")
    c.log(STEP, f"contornos regionales: {len(g)} polígonos")


def comunas_rm_geojson() -> None:
    """Límites comunales de la Región Metropolitana (WGS84, simplificados) para el acercamiento de la figura 5."""
    try:
        import geopandas as gpd
    except ImportError:
        c.log(STEP, "geopandas no disponible: sin límites comunales de la RM")
        return
    shp = c.SRC["comunas_shp"]
    if not shp.exists():
        c.log(STEP, f"AVISO sin {shp}")
        return
    g = gpd.read_file(shp)
    g = g[g["codregion"] == 13].to_crs(4326)[["cod_comuna", "Comuna", "Provincia", "geometry"]]
    g["geometry"] = g.geometry.simplify(0.001, preserve_topology=True)
    g.to_file(c.derived("geo") / "comunas_rm.geojson", driver="GeoJSON")
    c.log(STEP, f"comunas de la RM: {len(g)}")


def main() -> None:
    c.ensure_dirs()
    cat = catalog()
    fon = fonasa_centers()
    pop = c.pop_comuna()
    ctx = cat.copy()
    ctx["region13"] = c.region13(ctx["comuna"])
    f24 = fon[fon.year == 2024]
    ctx = ctx.merge(f24.groupby("estab")["n"].sum().rename("enrolled_2024"), on="estab", how="left")
    ta = f24[f24.tramo == "A"].groupby("estab")["n"].sum() / f24.groupby("estab")["n"].sum()
    ctx = ctx.merge((100 * ta).rename("pct_tramo_a"), on="estab", how="left")
    for s, k in (("Mujer", "f"), ("Hombre", "m")):
        z = fon[(fon.sex == s) & fon.band.isin(["60-79", "80+"])].groupby("estab")["n"].sum() / fon.year.nunique()
        ctx = ctx.merge(z.rename(f"enrolled_60plus_{k}_mean"), on="estab", how="left")
    w4564 = prorate(fon, cat, pop, 45, 64)
    w1549 = prorate(fon, cat, pop, 15, 49)
    w4564.to_csv(c.derived("denominators") / "fonasa_centros_women_45_64.csv.gz", index=False)
    w1549.to_csv(c.derived("denominators") / "fonasa_centros_women_15_49.csv.gz", index=False)
    ctx = ctx.merge(w4564[w4564.year == 2024].drop(columns="year").rename(columns={"part": "women_45_64_2024"}), on="estab", how="left")
    ctx = ctx.merge(w1549[w1549.year == 2024].drop(columns="year").rename(columns={"part": "women_15_49_2024"}), on="estab", how="left")
    ctx["has_enrolment"] = ctx["enrolled_2024"].fillna(0) > 0
    ctx = ctx.merge(c.load("comuna_context.csv")[["comuna", "comuna_name", "poverty_multi", "rural_share"]], on="comuna", how="left")
    c.save(ctx, "centers_context.csv")
    regions_geojson()
    comunas_rm_geojson()
    c.log(STEP, f"centros en catálogo: {len(ctx)}; con inscritos 2024: {int(ctx.has_enrolment.sum())}; "
                f"con coordenadas: {int(ctx.lat.notna().sum())}")


if __name__ == "__main__":
    main()
