"""Bind one English Methods/Results account to both Word and executable Quarto."""
from pathlib import Path
import argparse, base64, hashlib, html, json, re, shutil, subprocess, sys
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/access_diagnostic_extension_2026-10-29'
MAN=ROOT/'manuscript/access_diagnostic_extension_2026-10-29'
COMPONENTS=['rem','neuro','hospital','association']
SCIENTIFIC=Path('/Library/Frameworks/Python.framework/Versions/3.14/bin/python3')
PUBLIC_COMMANDS=[['rem_tables_figures.py'],['rem_report_content.py'],['neuro_reporting_figures.py'],['hospital_analysis.py','--aggregates-only'],['association_analysis.py'],['association_report_content.py']]
REFERENCES=[
 ('DEIS open data catalogue and annual REM files','https://deis.minsal.cl/#datosabiertos'),
 ('DEIS REM2025–2026 Series P manual version1.2, sections P1, P3 and P6','https://repositoriodeis.minsal.cl/ContenidoSitioWeb2020/REM/2025/SERIE/MANUAL_REM_P_2025_Version_1.2.pdf'),
 ('DEIS REM2025–2026 Series A BS BM D manual version1.3, sections A03, A05 and A29','https://repositoriodeis.minsal.cl/ContenidoSitioWeb2020/REM/2025/SERIE/Manual_Series_REM_2025_2026_SERIE_A_BS_BM_D_V1.3.pdf'),
 ('FONASA registered primary-care population by facility and year','https://public.tableau.com/views/ReporteInscritosCentrosAPS/ReporteAPS?:showVizHome=no'),
 ('FONASA GRD open data and financing portal','https://datosabiertos.fonasa.cl/dimensiones-financiamientos/'),
 ('DEIS hospital discharge data specification, including principal diagnosis and external cause','https://repositoriodeis.minsal.cl/deis/egresos_2003/Estructura_2003.htm'),
 ('DEIS WHO PAHO ICD10 tabular volume2018','https://repositoriodeis.minsal.cl/ContenidoSitioWeb2020/uploads/2020/12/CIE-10_2018_VOL1.pdf'),
 ('DEIS Chilean ICD10 tabular list August2026','https://repositoriodeis.minsal.cl/ContenidoSitioWeb2020/uploads/2021/03/Lista%20tabular%20CIE-10%20-%20agosto%202026.xlsx'),
 ('INE population projections by municipality age and sex, base2017','https://www.ine.gob.cl/estadisticas-por-tema/demografia-y-poblacion/estimaciones-y-proyecciones-de-poblacion'),
 ('MDSF municipal poverty estimates2024','https://observatorio.ministeriodesarrollosocial.gob.cl/pobreza-comunal-2024'),
 ('Biblioteca del Congreso Nacional Mapoteca vector boundaries','https://www.bcn.cl/siit/siit/mapas_vectoriales/')]

def tidy(text):
 text=str(text)
 text=re.sub(r'\b([a-z]{2,})(?=\d)',r'\1 ',text)
 text=re.sub(r'(?<=[A-Za-z])(?=[≥≤])',' ',text)
 text=re.sub(r';(?=\d)','; ',text)
 text=text.replace('between−1','between −1').replace('GRD45+','GRD age ≥45')
 text=text.replace('existing mf 19 diagnosis parquets','the previously prepared GRD diagnosis extract').replace('mf 19 files','prepared GRD diagnosis files')
 # Repair prose spacing without changing ICD, REM or file identifiers.
 text=re.sub(r'\b(aged|age|per|in|during|pooled|across|than|seed|version|volume|establishments|facilities|observations|records|years|year|of|for|from|by|and|between|with|was|were|comprised|ranged|December|August|October|accessed|nominal|Nominal|All|all|four|three|two|the|least|REM)(?=\d)',r'\1 ',text)
 text=re.sub(r'(?<=\d)(?=(?:facilities|clusters|municipalities|records|years|snapshots|permutations)\b)',' ',text)
 return text.replace('P=<','P<').replace('prepared prepared','prepared')

def display_value(value,column):
 value=str(value)
 if not re.fullmatch(r'[+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?',value):return tidy(value)
 n=float(value);c=column.lower()
 if 'code' in c:return value
 if 'year' in c:return str(int(n))
 if 'dispersion' in c:return f'{n:.1f}'
 if any(w in c for w in ['ratio','per 100','per100','/1,000','/1000','rate','moran','dispersion','minimum mht','maximum mht','observed / expected']):return f'{n:,.3f}' if any(w in c for w in ['ratio','moran','observed / expected']) else f'{n:,.2f}'
 if c in ['nominal p','holm p','permutation p']:return '<0.001' if 0<n<.001 else f'{n:.3f}'
 if any(w in c for w in ['expected','estimated','enrolment']) and not n.is_integer():return f'{n:,.1f}'
 if n.is_integer():return f'{int(n):,}'
 return f'{n:,.3f}'

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def rebuild_public():
 for command in PUBLIC_COMMANDS:
  result=subprocess.run([str(SCIENTIFIC if SCIENTIFIC.exists() else Path(sys.executable)),str(ROOT/'scripts/access_extension'/command[0]),*command[1:]],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
  if result.returncode:raise RuntimeError('Public rebuild failed in '+command[0]+'\n'+result.stderr[-8000:])
 return build()

def build():
 data={'title':'Hormonal care and neurodegenerative diagnostic recording in Chile','methods':[],'results':[],'figures':[],'tables':[]}
 data['methods'].append({'title':'Study purpose and relation to the two study parts','paragraphs':[
 'This health-services extension evaluated menopause-related care and diagnostic recording in Chile, then examined whether earlier hormonal-care recording was associated with later neurological caseload in facilities with usable observations. It extends the connected reproductive and neurodegenerative analyses in Part II; Part I supplies the separate descriptive burden context. The present Methods and Results report new raw-source re-extraction and public-aggregate analyses completed on29 October2026. Hospital discharges, coded public-hospital episodes, programme entries and December caseloads retain their own observation units and denominators.',
 'Realised service use and diagnostic recording are measurable in these administrative data. Unmet need, ability to obtain appropriate care when required, hormone concentrations, prescribing eligibility, adherence and clinical onset are not directly measured. Geographical analyses concern facility location and reporting visibility. General-access survey questions identified in the earlier feasibility work were not newly analysed in this administrative extension.']})
 for component in COMPONENTS:
  source=json.loads((OUT/component/(component+'_report_content.json')).read_text())
  for kind in ['methods','results']:
   for section in source[kind]:
    data[kind].append({'title':re.sub(r'[^A-Za-z0-9 ]',' ',tidy(section['title'])).strip(),'paragraphs':[tidy(p) for p in section['paragraphs']],'component':component})
  for f in source['figures']:
   item=dict(f);item['number']=len(data['figures'])+1;item['component']=component
   item['caption']=tidy(re.sub(r'^(?:(?:Hospital|Neurological)\s+)?(?:Figure|figure)\s*\d+\.?\s*','',item['caption']))
   item['alt']=tidy(item.get('alt',item['caption']))
   p=Path(item['path']);p=p if p.is_absolute() else ROOT/p
   item['path']=str(p.relative_to(ROOT));item['sha256']=sha(p)
   if 'formats' in item:
    item['formats']={ext:str(Path(value).relative_to(ROOT)) if Path(value).is_absolute() else value for ext,value in item['formats'].items()}
   data['figures'].append(item)
  for t in source['tables']:
   p=Path(t['csv_path']);p=p if p.is_absolute() else ROOT/p
   frame=pd.read_csv(p,dtype=str,keep_default_na=False)
   columns=[' '.join(tidy(c).split()) for c in frame.columns]
   rows=[[display_value(v,c) for v,c in zip(row,columns)] for row in frame.to_numpy().tolist()]
   item={**t,'number':len(data['tables'])+1,'title':tidy(t['title']),'note':tidy(t.get('note','')),'columns':columns,'rows':rows,'csv_sha256':sha(p),'component':component}
   item['csv_path']=str(p.relative_to(ROOT))
   if t['id']=='rem-national':
    item['columns']=['Year','Measure','All-source count','Source rows','Numeric cells','Blank cells','Matched facilities','Matched count','Estimated enrolled 45–64','Matched /1,000']
    item['column_widths_mm']=[12,34,22,20,20,20,25,23,45,36]
   if component=='neuro':item['columns']=[c.replace('Paired establishments','Paired facilities') for c in item['columns']]
   if t['id']=='rem-diagnostic-qc':
    item['columns']=['Year','Activity','Rows','Full age sets','Age sum errors','Partial > total','Mode fields','Full mode sets','Mode sum errors','Inactive fields']
    item['column_widths_mm']=[13,42,21,23,23,28,25,24,24,34]
   data['tables'].append(item)
 data['results'].insert(0,{'title':'Reading the connected administrative evidence','paragraphs':[
 'The results proceed from menopause-care recording and source visibility, through neurological programme completeness and hospital diagnostic coding, to the facility association analyses. The complete table and figure bank retains descriptive detail and sensitivity estimates for later manuscript selection. None of the sources is treated as interchangeable with another source’s clinical or population measurement.',
 'The new source audit supersedes earlier zero-filled or differently labelled REM summaries for the measures explicitly re-extracted here. Exact duplicate rows in2021 were removed, while conflicting keys were quarantined. A03 entry and follow-up assessments were separated, and the scope of A29 diagnostic services was harmonised only within compatible code years. Earlier project files remain versioned historical outputs; they should not be pooled with these corrected series without applying the same definitions.']})
 data['references']=[tidy(title)+'. '+url+' (accessed 29 October 2026).' for title,url in REFERENCES]
 for kind in ['methods','results']:
  for section in data[kind]:section['paragraphs']=[tidy(p) for p in section['paragraphs']]
 payload=json.dumps(data,ensure_ascii=False,sort_keys=True,separators=(',',':'))
 content_id=hashlib.sha256(payload.encode()).hexdigest()
 data['content_sha256']=content_id
 (OUT/'access_evidence.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
 word={'title':data['title'],'sections':[],'tables':data['tables'],'figures':data['figures'],'references':data['references']}
 for kind in ['methods','results']:
  blocks=[]
  for section in data[kind]:
   blocks.append({'type':'heading','text':section['title'],'level':2})
   blocks.extend({'type':'paragraph','text':p} for p in section['paragraphs'])
  word['sections'].append({'heading':kind.capitalize(),'blocks':blocks})
 bundle={'content_sha256':content_id,'languages':{'en':word}}
 (OUT/'review_bundle.json').write_text(json.dumps(bundle,ensure_ascii=False,indent=2))
 return data

def write_qmd(data):
 path=ROOT/'docs/access_diagnostic_recording_extension.qmd'
 archive=ROOT/'docs/archive/access_diagnostic_extension_proposal_2026-10-29.qmd'
 if path.exists() and 'Proposed extension' in path.read_text() and not archive.exists():
  archive.parent.mkdir(exist_ok=True);shutil.copy2(path,archive)
 lines=['---','title: "Hormonal care and neurodegenerative diagnostic recording in Chile"','subtitle: "Executed Methods and Results across REM DEIS and FONASA GRD"','lang: en','date: 2026-10-29','navbar: false','sidebar: false','format:','  html:','    toc: true','    toc-depth: 3','    code-fold: true','    code-summary: "Show reproducible analysis"','    code-tools: true','    code-copy: true','    embed-resources: true','    css: reproductive_life_course.css','execute:','  echo: true','  warning: false','  message: false','  error: false','  freeze: false','  cache: false','jupyter: python3','---','',
 '[Download the matching line-numbered Methods and Results Word document](../manuscript/access_diagnostic_extension_2026-10-29/Methods_Results_EN.docx)','',
 '[Part I descriptive article](descriptive_methods_results.qmd) · [Part II connected analysis](reproductive_life_course.qmd) · <a href="access_diagnostic_recording_extension_source.txt" download="access_diagnostic_recording_extension.qmd">Download executable QMD</a> · [Download figures tables and reproducible sources](../outputs/access_diagnostic_extension_2026-10-29/Access_Diagnostic_Recording_Assets_EN.zip)','',
 'This executed report replaces the earlier data-availability proposal. It contains newly re-extracted administrative evidence. The facility association is sensitive to programme intensity and one denominator-inconsistent provider; it does not establish an individual hormonal effect. All substantive prose, table cells and figure files below share one evidence bundle with the Word document.','',
 '```{python}','#| label: rebuild-public-administrative-evidence','#| output: asis',
 'from pathlib import Path','import sys, contextlib, io, json, html, base64','from IPython.display import display, Markdown, HTML',
 "PROJECT = next(p for p in [Path.cwd(), *Path.cwd().parents] if (p/'scripts/access_extension/access_report.py').exists())",
 "sys.path.insert(0, str(PROJECT/'scripts/access_extension'))",'import access_report as report',
 '# Public aggregate mode regenerates every display and refits the facility models.',
 '# Original-record refresh is a separate documented command requiring the data volume.',
 'with contextlib.redirect_stdout(io.StringIO()):','    evidence = report.rebuild_public()',
 'def section(kind, index):',"    for p in evidence[kind][index]['paragraphs']: display(Markdown(p))",
 'def table(index):',"    t=evidence['tables'][index]", "    import pandas as pd", "    frame=pd.DataFrame(t['rows'], columns=t['columns'])", "    display(HTML('<div class=\"table-responsive\">'+frame.to_html(index=False,escape=True)+'</div><p class=\"table-note\">'+html.escape(t['note'])+'</p>'))", "    display(Markdown('[Download source table](../'+t['csv_path']+')'))",
 'def figure(index):',"    f=evidence['figures'][index]", "    uri='data:image/png;base64,'+base64.b64encode((PROJECT/f['path']).read_bytes()).decode()", "    display(HTML('<img class=\"paper-figure\" src=\"'+uri+'\" alt=\"'+html.escape(f['alt'],quote=True)+'\" style=\"max-width:100%;height:auto\"><p class=\"figure-caption\">'+html.escape('Figure '+str(f['number'])+'. '+f['caption'])+'</p>'))", "    base=str(Path(f['path']).with_suffix(''))", "    display(Markdown('[Editable SVG](../'+base+'.svg) · [Vector PDF](../'+base+'.pdf) · [600 dpi PNG](../'+base+'.png)'))",'```','']
 for kind in ['methods','results']:
  lines+=['## '+kind.capitalize(),'']
  for i,s in enumerate(data[kind]):
   lines+=['### '+s['title'],'','```{python}',f'#| label: {kind}-{i+1}', '#| output: asis', f"section('{kind}', {i})",'```','']
 lines+=['## Tables','']
 for i,t in enumerate(data['tables']):lines+=['### Table '+str(t['number'])+'. '+t['title'],'','```{python}',f'#| label: table-{i+1}','#| output: asis',f'table({i})','```','']
 lines+=['## Figures','']
 for i,f in enumerate(data['figures']):lines+=['### Figure '+str(f['number']),'','```{python}',f'#| label: access-figure-cell-{i+1}','#| output: asis',f'figure({i})','```','']
 lines+=['## Original data and classification sources','','The scientific sources are the institutional datasets, coded annual dictionaries and manuals below. Derived files and computational metadata support reproducibility; they are not substitute scientific sources.','']
 lines += [f'- [{tidy(title)}]({url})' for title,url in REFERENCES]
 lines+=['','## Computational reproducibility','',
 'The default executable path uses saved public aggregate inputs and refits the facility models. It regenerates every reported table and figure. Original person-level hospital records and encrypted identifiers stay on the external data volume and are not included in this report or the downloadable package. The separate raw-refresh mode re-extracts source files and reproduces the public aggregate inputs; access to the same raw releases and the stated external data tree is required.','',
 'From the project root, use the Python environment recorded in the software manifest:','',
 '```{.bash}', 'python3 scripts/run_access_diagnostic_extension.py --html', '# Rebuild the matching Word document as well', 'python3 scripts/run_access_diagnostic_extension.py --word --html', '# Refresh original records only when the external data volume is available', 'python3 scripts/run_access_diagnostic_extension.py --refresh-raw --word --html','```','',
 'The raw path additionally uses the pre-existing FONASA denominator and public facility/context preparation described in the build instructions. Source hashes, dictionary mappings, denominator checks, duplicate decisions, coding exclusions and exact reporting eligibility remain inspectable. Public aggregation and raw-source refresh provide different reproducibility levels; independent replication requires obtaining the original releases rather than accepting derived data as their own validation.','',
 '```{python}','#| label: computational-source-inspector','#| output: asis',
 "display(Markdown('Evidence content SHA256: `'+evidence['content_sha256']+'`'))",
 "for file in ['association_analysis.py','association_report_content.py','rem_tables_figures.py','rem_report_content.py','neuro_reporting_figures.py','hospital_analysis.py']:",
 "    source=(PROJECT/'scripts/access_extension'/file).read_text()",
 "    display(HTML('<details><summary>Inspect '+html.escape(file)+'</summary><pre><code>'+html.escape(source)+'</code></pre></details>'))",'```','']
 path.write_text('\n'.join(lines));(ROOT/'docs/access_diagnostic_recording_extension_source.txt').write_bytes(path.read_bytes())

def main():
 p=argparse.ArgumentParser();p.add_argument('--qmd',action='store_true');a=p.parse_args();d=build()
 if a.qmd:write_qmd(d)
 print(json.dumps({'methods':len(d['methods']),'results':len(d['results']),'tables':len(d['tables']),'figures':len(d['figures']),'content_sha256':d['content_sha256']}))
if __name__=='__main__':main()
