"""Independent read-only reconstruction of the exploratory association inputs.

Only public establishment aggregates are read. The coordinating association
module is not imported and none of its files is modified. Audit outputs are
restricted to the neurological output directory.
"""
from pathlib import Path
import hashlib
import json
import platform

import numpy as np
import pandas as pd
import patsy
from scipy import stats
import statsmodels.api as sm

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'outputs/access_diagnostic_extension_2026-10-29'
OUT = BASE / 'neuro'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    raw_path = BASE / 'rem/facility_year_hormonal_care.csv'
    neuro_path = OUT / 'neuro_facility_year.csv.gz'
    raw = pd.read_csv(raw_path)
    neuro = pd.read_csv(neuro_path)
    assert not raw.duplicated(['estab', 'year']).any()
    assert not neuro.duplicated(['year', 'estab', 'sex', 'age_group', 'measure']).any()
    base = raw[raw.year.isin([2019, 2020, 2021])].copy()
    valid = (base.estimated_enrolled_women_45_64.gt(0)
             & base.mht_status.isin(['positive', 'explicit_zero'])
             & base.care_status.isin(['positive', 'explicit_zero']))
    valid_exposure = base[valid].copy()
    meta = raw.sort_values('year').groupby('estab').tail(1).set_index('estab')
    checks = []
    primary = None
    primary_cells = None
    for measure in ['dementia_caseload', 'parkinson_caseload']:
        for sex in ['Women', 'Men']:
            cells = neuro[(neuro.measure == measure) & (neuro.sex == sex)
                          & neuro.year.isin([2022, 2023, 2024, 2025])
                          & neuro.age_group.isin(['60-79', '80+'])].copy()
            cells = cells[cells.complete_identified & cells.enrolled.gt(0)
                          & cells.count_complete_identified.notna()]
            sizes = cells.groupby(['estab', 'year']).age_group.nunique()
            pairs = sizes[sizes == 2].reset_index()[['estab', 'year']]
            cells = cells.merge(pairs, on=['estab', 'year'], validate='many_to_one')
            # Reference population is all outcome-eligible establishment-years,
            # before the MHT restriction and before minimum-year selection.
            totals = cells.groupby(['year', 'age_group'])[['count_complete_identified', 'enrolled']].sum()
            reference = totals.count_complete_identified / totals.enrolled
            cells = cells.join(reference.rename('rate'), on=['year', 'age_group'])
            cells['expected_independent'] = cells.enrolled * cells.rate
            outcome = cells.groupby('estab').agg(
                outcome=('count_complete_identified', 'sum'), expected=('expected_independent', 'sum'),
                outcome_years=('year', 'nunique'), outcome_enrolment_sum=('enrolled', 'sum'))
            for sample, exposure_years, outcome_years in [('strict', 3, 4), ('relaxed', 2, 2)]:
                exposure = valid_exposure.groupby('estab').agg(
                    exposure_years=('year', 'nunique'), mht=('mht', 'sum'), care=('care', 'sum'),
                    exposure_enrolment_sum=('estimated_enrolled_women_45_64', 'sum'))
                exposure = exposure[exposure.exposure_years >= exposure_years]
                exposure['mht_per1000'] = 1000 * exposure.mht / exposure.exposure_enrolment_sum
                exposure['mht10'] = exposure.mht_per1000 / 10
                exposure['care_per100'] = 100 * exposure.care / exposure.exposure_enrolment_sum
                eligible_outcome = outcome[(outcome.outcome_years >= outcome_years) & outcome.expected.gt(0)]
                joined = exposure.join(eligible_outcome, how='inner')
                actual_path = BASE / f'association/cohort_{measure}_{sex.lower()}_{sample}.csv'
                actual = pd.read_csv(actual_path).set_index('estab')
                assert set(actual.index) == set(joined.index), (measure, sex, sample, 'facility mismatch')
                joined = joined.reindex(actual.index)
                errors = {name: float(np.max(np.abs(joined[name] - actual[name])))
                          for name in joined.columns}
                assert all(v < 1e-7 for v in errors.values()), (measure, sex, sample, errors)
                checks.append({'measure': measure, 'sex': sex, 'sample': sample,
                               'facilities': len(actual), 'municipalities': int(actual.comuna.nunique()),
                               'numeric_max_absolute_difference': max(errors.values()),
                               'all_facility_keys_identical': True,
                               'all_required_years_and_both_age_bands': True})
                if (measure, sex, sample) == ('dementia_caseload', 'Women', 'strict'):
                    primary = actual.copy()
                    primary_cells = cells[cells.estab.isin(primary.index)].copy()
    assert primary is not None
    covariate_cols = ['comuna', 'region13', 'type_group', 'poverty_multi', 'rural_share', 'lat', 'lon']
    for name in covariate_cols:
        expected = meta.loc[primary.index, name]
        observed = primary[name]
        if pd.api.types.is_numeric_dtype(expected):
            assert np.allclose(expected, observed, equal_nan=True), name
        else:
            assert expected.fillna('').eq(observed.fillna('')).all(), name
    numeric = ['outcome', 'expected', 'mht10', 'comuna', 'region13', 'type_group', 'poverty_multi', 'rural_share', 'log_size']
    model_data = primary.dropna(subset=numeric).copy()
    model_data['region13'] = model_data.region13.astype(int).astype(str)
    model_data['poverty10'] = model_data.poverty_multi / .1
    model_data['rural10'] = model_data.rural_share / .1
    y, x = patsy.dmatrices('outcome ~ mht10 + C(region13) + C(type_group) + poverty10 + rural10 + log_size',
                          model_data, return_type='dataframe')
    fitted = sm.GLM(y, x, family=sm.families.Poisson(), offset=np.log(model_data.expected)).fit(
        maxiter=200, tol=1e-10, cov_type='cluster',
        cov_kwds={'groups': model_data.comuna.to_numpy(), 'use_correction': True})
    clusters = model_data.comuna.nunique()
    beta, se = fitted.params['mht10'], fitted.bse['mht10']
    critical = stats.t.ppf(.975, clusters - 1)
    independent = {'facilities': len(model_data), 'municipal_clusters': int(clusters),
                   'parameters': x.shape[1], 'matrix_rank': int(np.linalg.matrix_rank(x)),
                   'beta': float(beta), 'cluster_se': float(se), 'rate_ratio': float(np.exp(beta)),
                   'ci_low': float(np.exp(beta - critical * se)), 'ci_high': float(np.exp(beta + critical * se)),
                   'p_nominal': float(2 * stats.t.sf(abs(beta / se), clusters - 1)),
                   'converged': bool(fitted.converged)}
    result = pd.read_csv(BASE / 'association/association_models.csv')
    row = result[(result.measure == 'dementia_caseload') & (result.sex == 'Women')
                 & (result['sample'] == 'strict') & (result.model == 'base')].iloc[0]
    independent['maximum_parameter_difference_from_coordinating_analysis'] = max(
        abs(independent[k] - row[k]) for k in ['beta', 'cluster_se', 'rate_ratio', 'ci_low', 'ci_high', 'p_nominal'])
    assert independent['maximum_parameter_difference_from_coordinating_analysis'] < 1e-7
    annual_bad = valid_exposure.assign(
        any_numerator_above_denominator=lambda d: d.mht.gt(d.estimated_enrolled_women_45_64)
        | d.care.gt(d.estimated_enrolled_women_45_64))
    bad_ids = set(annual_bad.loc[annual_bad.any_numerator_above_denominator, 'estab'])
    primary_bad = set(primary.index[primary.numerator_exceeds_denominator])
    flagged_only_annually = sorted((set(primary.index) & bad_ids) - primary_bad)
    counts = primary_cells.groupby('estab').agg(cells=('year', 'size'), years=('year', 'nunique'),
                                               raw_numeric_components=('raw_numeric_rows', 'sum'),
                                               accounting_components=('accounting_identified_rows', 'sum'))
    assert counts.cells.eq(8).all() and counts.years.eq(4).all()
    assert primary_cells.observed_component_months.eq(3).all()
    assert primary_cells.value_status.isin(['raw_numeric_complete', 'accounting_identified_complete']).all()
    snapshot = {'primary_age_year_cells': len(primary_cells), 'expected_per_establishment': 8,
                'all_have_three_stages': True, 'all_denominators_positive': bool(primary_cells.enrolled.gt(0).all()),
                'all_counts_identified': bool(primary_cells.complete_identified.all()),
                'primary_facilities_all_raw_numeric': int(counts.raw_numeric_components.eq(24).sum()),
                'primary_facilities_relying_on_accounting': int(counts.accounting_components.gt(0).sum()),
                'primary_facilities_pooled_numerator_above_denominator': len(primary_bad),
                'primary_facilities_annual_only_inconsistency': len(flagged_only_annually),
                'annual_only_public_facility_codes': flagged_only_annually}
    caveats = [
        'The offset is a source-internal sex-age-year standard over all eligible reporting establishment-years, before exposure selection. It is not a national disease-rate standard.',
        'Both exposure and outcome sums pool repeated December snapshots. They are not unique people or observed person-time, and no individual or hormonal treatment effect is identified.',
        'Exposure eligibility also requires a numeric climacteric-care cell. The resulting sample is selected on dual-programme reporting, not merely on MHT recording.',
        'Contextual covariates, provider type and location are the latest available facility-context mapping. They are descriptive contemporary adjustments, not historical confounder measurements.',
        'The municipal-cluster covariance is conditional on the internally estimated reference rates; reference-rate estimation uncertainty is not propagated.',
        'The primary association is highly sensitive to one denominator-inconsistent hospital and programme intensity; numerical reproduction is not evidence of clinical or causal validity.'
    ]
    if flagged_only_annually:
        caveats.append('The implemented numerator-denominator sensitivity screens pooled 2019–2021 sums. Additional facilities have an annual inconsistency hidden by pooling; an explicitly labelled any-year screen is a possible additional sensitivity.')
    inputs = [raw_path, neuro_path, ROOT / 'scripts/access_extension/association_analysis.py',
              ROOT / 'config/access_recording_extension_2026_10_29.yaml']
    audit = {'scope': 'Independent public-aggregate reconstruction; coordinating files were not edited.',
             'status': 'pass_with_interpretation_caveats', 'python': platform.python_version(),
             'cohort_checks': checks, 'primary_mean_model_and_library_cluster_covariance': independent,
             'primary_measurement_checks': snapshot, 'interpretation_caveats': caveats,
             'source_sha256': {str(p.relative_to(ROOT)): sha(p) for p in inputs}}
    (OUT / 'neuro_association_independent_audit.json').write_text(json.dumps(audit, indent=2) + '\n')
    print(json.dumps({'status': audit['status'], 'cohorts': len(checks), 'primary': independent, 'measurement': snapshot}, indent=2))


if __name__ == '__main__':
    main()
