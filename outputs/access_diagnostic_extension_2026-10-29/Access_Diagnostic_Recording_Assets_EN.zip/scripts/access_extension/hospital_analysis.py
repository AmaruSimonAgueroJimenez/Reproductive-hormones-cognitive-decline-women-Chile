#!/usr/bin/env python3
"""Hospital diagnostic-recording extension; aggregate-only report rebuild by default.

--refresh-private recomputes public summary cells from this extension's external
private episode-flag cache. It never exports identifiers or individual records.
"""
from pathlib import Path
import argparse,json,hashlib,sys,math
import numpy as np,pandas as pd,polars as pl
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from hospital_source_scan import GROUPS,OUT,PRIVATE,ROOT,EXACT_GROUPS
FOLDER=OUT/'figures'
AGE=['<40','40–44','45–54','55–64','65–74','75–84','≥85']
DAGE=['<40','40–49','50–59','60–69','70–79','≥80']
LABELS={'climacteric_n951':'N95.1: climacteric states','menopausal_disorders':'N95.1/N95.8/N95.9','artificial_menopause':'N95.3: artificial menopause','primary_ovarian_failure':'E28.3: primary ovarian failure','postprocedural_ovarian_failure':'E89.4: postprocedural ovarian failure','genital_absence_status':'Z90.7: genital absence status','menopause_clinical_composite':'Mixed clinical composite','postmenopausal_bleeding':'N95.0: postmenopausal bleeding','postmenopausal_atrophic_vaginitis':'N95.2: atrophic vaginitis','dementia':'Dementia','parkinsonism':'Parkinsonism','neurodegenerative_any':'Configured neurological composite'}
COL=['#216A94','#AD2D65','#128477','#A16A12','#754D86','#6B6B6B']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def csv(n):return pd.read_csv(OUT/n)
def save(df,n):df.to_csv(OUT/n,index=False)
def core(d):return (pl.col('dementia_any')==1)|(pl.col('parkinsonism_any')==1)
def first_tables():
 if not PRIVATE.is_dir():raise RuntimeError('Private external cache unavailable; no person summary refreshed.')
 ds=[pl.read_parquet(PRIVATE/f'grd_episode_flags_{y}.parquet') for y in range(2019,2025)]
 d=pl.concat(ds);allw=d.filter(pl.col('sex')=='Women');r=d.filter(pl.col('year')>=2021)
 # Name-independent empirical continuity and recorded-sex consistency.
 ids={y:set(r.filter((pl.col('year')==y)&(pl.col('id')!=''))['id'].to_list()) for y in range(2021,2025)}
 overlap=[{'year_a':y,'year_b':y+1,'unique_ids_a':len(ids[y]),'unique_ids_b':len(ids[y+1]),'overlap_ids':len(ids[y]&ids[y+1])} for y in range(2021,2024)]
 save(pd.DataFrame(overlap),'grd_identifier_overlap.csv')
 known=r.filter((pl.col('id')!='')&pl.col('sex').is_in(['Women','Men']))
 bad=known.group_by('id').agg(pl.col('sex').n_unique().alias('sex_count')).filter(pl.col('sex_count')>1).select('id')
 consistent=r.filter(pl.col('id')!='').join(bad,on='id',how='anti')
 cw=consistent.filter(pl.col('sex')=='Women')
 first=cw.sort(['year','date_in','hospital'],maintain_order=True).unique(subset='id',keep='first',maintain_order=True)
 first.write_parquet(PRIVATE/'first_observed_female_episode_2021_2024.parquet')
 # A code may recur in later years. Index means first eligible observed episode, not onset.
 samples={'Episodes 2019–2024':allw,'Episodes 2021–2024':allw.filter(pl.col('year')>=2021),'ID-consistent episodes 2021–2024':cw,'First observed episode per woman 2021–2024':first}
 co=[]
 groups=['climacteric_n951','menopausal_disorders','artificial_menopause','primary_ovarian_failure','postprocedural_ovarian_failure','menopause_clinical_composite','genital_absence_status']
 for unit,w in samples.items():
  for outcome,flag in [('Dementia or parkinsonism',core(w)),('Dementia',pl.col('dementia_any')==1),('Parkinsonism',pl.col('parkinsonism_any')==1)]:
   nout=int(w.select(flag.sum()).item())
   for g in groups:
    exp=pl.col(g+'_any')==1
    both=int(w.select((flag&exp).sum()).item());npos=int(w.select(exp.sum()).item())
    co.append({'unit':unit,'age_scope':'≥45','outcome':outcome,'code_group':g,'denominator':len(w),'code_positive':npos,'neurological_positive':nout,'both':both,'code_only':npos-both,'neurological_only':nout-both,'neither':len(w)-nout-npos+both})
 save(pd.DataFrame(co),'grd_corecording_2x2.csv')
 miss=r.filter((pl.col('sex')=='Women')&(pl.col('id')==''))
 badfemale=r.filter(pl.col('sex')=='Women').join(bad,on='id',how='semi')
 qc={'eligible_allsex_2021_2024_episodes':len(r),'female_2021_2024_episodes':r.filter(pl.col('sex')=='Women').height,'female_missing_id_episodes':len(miss),'sex_discordant_ids_allsex':len(bad),'female_sex_discordant_id_episodes':len(badfemale),'female_id_consistent_episodes':len(cw),'unique_first_female_episodes':len(first),'female_later_episodes_not_used_for_first_record':len(cw)-len(first),'first_record_date_missing':first.filter(pl.col('date_in').is_null()).height}
 (OUT/'grd_person_flow.json').write_text(json.dumps(qc,indent=2)+'\n')
 # Clinical coding and age; no individual-level model is attempted for sparse co-recording.
 age=[];profiles=[]
 for label,w in samples.items():
  wa=w.with_columns(pl.when(pl.col('age')<55).then(pl.lit('45–54')).when(pl.col('age')<65).then(pl.lit('55–64')).when(pl.col('age')<75).then(pl.lit('65–74')).when(pl.col('age')<85).then(pl.lit('75–84')).otherwise(pl.lit('≥85')).alias('age_band'))
  z=wa.group_by('age_band').agg(pl.len().alias('denominator'),*[pl.col(g+'_any').sum().alias(g+'_any') for g in groups]).to_pandas();z['unit']=label;age.append(z)
  for population,ww in [('All eligible women',w),('N95.1/N95.8/N95.9 coded',w.filter(pl.col('menopausal_disorders_any')==1)),('Dementia/parkinsonism coded',w.filter(core(w)))]:
   profiles.append({'unit':label,'population':population,'n':len(ww),'n_dx_p25':float(ww['n_dx'].quantile(.25,interpolation='linear')) if len(ww) else None,'n_dx_median':float(ww['n_dx'].median()) if len(ww) else None,'n_dx_p75':float(ww['n_dx'].quantile(.75,interpolation='linear')) if len(ww) else None,'age_median':float(ww['age'].median()) if len(ww) else None})
 save(pd.concat(age,ignore_index=True),'grd_age_by_observation_unit.csv');save(pd.DataFrame(profiles),'grd_diagnostic_depth_profiles.csv')
 # Hospital distribution summaries retain zero-recording hospitals. No hospital codes enter public files.
 h=pl.read_parquet(PRIVATE/'grd_hospital_year_counts.parquet').to_pandas();hout=[]
 for y,s in h.groupby('year'):
  s=s[s.hospital.fillna('').ne('')&s.denominator.ge(1000)].copy()
  for g in ['menopausal_disorders','menopause_clinical_composite','genital_absence_status']:
   rate=s[g+'_any']/s.denominator*10000
   hout.append({'year':int(y),'code_group':g,'female_episode_threshold':1000,'hospitals':len(s),'hospitals_with_positive_code':int(s[g+'_any'].gt(0).sum()),'female_episodes':int(s.denominator.sum()),'coded_episodes':int(s[g+'_any'].sum()),'rate_p10':float(rate.quantile(.1)),'rate_p25':float(rate.quantile(.25)),'rate_median':float(rate.median()),'rate_p75':float(rate.quantile(.75)),'rate_p90':float(rate.quantile(.9)),'rate_maximum':float(rate.max())})
 save(pd.DataFrame(hout),'grd_hospital_distribution.csv')
 # Age>110 is an audit flag, not silently removed from the primary episode denominator.
 sens=[]
 for label,w in [('Primary age ≥45',allw),('Age 45–110 sensitivity',allw.filter(pl.col('age')<=110))]:
  sens.append({'age_filter':label,'denominator':len(w),**{g+'_any':int(w[g+'_any'].sum()) for g in groups}})
 save(pd.DataFrame(sens),'grd_extreme_age_sensitivity.csv')
 print('Private-cache summaries refreshed: no identifiers exported.',flush=True)

# ---- Public-aggregate figure/report rebuild ----
def export(fig,name):
 FOLDER.mkdir(parents=True,exist_ok=True)
 for ext in ['svg','pdf','png']:fig.savefig(FOLDER/(name+'.'+ext),dpi=600,facecolor='white',**({'metadata':{'CreationDate':None,'ModDate':None}} if ext=='pdf' else {}))
 plt.close(fig)
def axes4(titles,height=130):
 fig,axs=plt.subplots(2,2,figsize=(170/25.4,height/25.4),layout='constrained')
 for i,ax in enumerate(axs.flat):
  ax.set_title(chr(65+i)+'  '+titles[i],loc='left',fontweight='bold',pad=6)
  ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.18);ax.set_axisbelow(True)
 return fig,axs.flat

def rebuild():
 plt.rcParams.update({'font.family':'Arial','font.size':8,'axes.titlesize':9,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','svg.hashsalt':'hospital-access-extension-20261029','lines.linewidth':1.3,'lines.markersize':3})
 deis=csv('deis_female_age_sector.csv');grd=csv('grd_female_45plus_year.csv');qc_d=csv('deis_source_qc.csv');qc_g=csv('grd_source_qc.csv');co=csv('grd_corecording_2x2.csv');hospital=csv('grd_hospital_distribution.csv');profile=csv('grd_diagnostic_depth_profiles.csv');flow=json.loads((OUT/'grd_person_flow.json').read_text());manifest=json.loads((OUT/'hospital_source_manifest.json').read_text());audit=json.loads((OUT/'code_audit/code_validity_audit.json').read_text())
 annual=deis.groupby('year').sum(numeric_only=True).reset_index();recent=deis[deis.year.ge(2019)]
 save(annual,'deis_female_annual.csv')
 allgroups=['climacteric_n951','menopausal_disorders','artificial_menopause','primary_ovarian_failure','postprocedural_ovarian_failure','genital_absence_status','menopause_clinical_composite','postmenopausal_bleeding','postmenopausal_atrophic_vaginitis','dementia','parkinsonism']
 totals=[]
 for source,frame,suffix,scope in [('DEIS',deis,'principal','Women, all ages, 2001–2024'),('DEIS',recent,'principal','Women, all ages, 2019–2024'),('GRD',grd,'principal','Women age ≥45, 2019–2024'),('GRD',grd,'any','Women age ≥45, 2019–2024')]:
  den=int(frame.denominator.sum())
  for g in allgroups:totals.append({'source':source,'scope':scope,'position':suffix,'code_group':g,'denominator':den,'n':int(frame[g+'_'+suffix].sum()),'per_10000':frame[g+'_'+suffix].sum()/den*10000})
 totals=pd.DataFrame(totals);save(totals,'hospital_code_totals.csv')
 # Fig H1: source-specific denominators, no pooling or invented age boundaries.
 fig,axs=axes4(['DEIS: broad menopausal principal code','DEIS: age and sector, 2019–2024','GRD age ≥45: diagnostic position','GRD age ≥45: component counts'])
 ax=next(axs)
 for i,(sector,z) in enumerate(deis.groupby('sector')):
  if sector=='Unknown':continue
  a=z.groupby('year').sum(numeric_only=True);ax.plot(a.index,a.menopausal_disorders_principal/a.denominator*10000,marker=['o','s'][i%2],label=sector,color=COL[i],linestyle=['-','--'][i%2])
 ax.set(xlabel='Discharge file year',ylabel='Per 10,000 female discharges');ax.legend(frameon=False);ax.xaxis.set_major_locator(MaxNLocator(5,integer=True))
 ax=next(axs)
 for i,(sector,z) in enumerate(recent.groupby('sector')):
  if sector=='Unknown':continue
  a=z.groupby('age_band').sum(numeric_only=True).reindex(DAGE);ax.plot(np.arange(len(DAGE)),a.menopausal_disorders_principal/a.denominator*10000,marker=['o','s'][i%2],linestyle=['-','--'][i%2],color=COL[i],label=sector)
 ax.set(xticks=np.arange(len(DAGE)),xticklabels=DAGE,xlabel='Source-supported age band',ylabel='Per 10,000 female discharges');ax.legend(frameon=False)
 ax=next(axs)
 for s,col,marker in [('principal',COL[0],'o'),('any',COL[1],'s')]:ax.plot(grd.year,grd['menopausal_disorders_'+s]/grd.denominator*10000,marker=marker,color=col,label=s.capitalize())
 ax.set(xlabel='GRD file year',ylabel='Per 10,000 female episodes');ax.legend(frameon=False)
 ax=next(axs);gs=['climacteric_n951','artificial_menopause','primary_ovarian_failure','postprocedural_ovarian_failure'];vals=[int(grd[g+'_any'].sum()) for g in gs]
 ax.barh(np.arange(4),vals,color=COL[:4]);ax.set(yticks=np.arange(4),yticklabels=['N95.1','N95.3','E28.3','E89.4'],xlabel='Any-position coded episodes');ax.invert_yaxis()
 for i,v in enumerate(vals):ax.text(v+max(vals)*.025,i,str(v),va='center',fontsize=8)
 ax.set_xlim(0,max(vals)*1.22)
 export(fig,'Hospital_Figure1_recording_sources')
 # Fig H2: all counts are transparent; sparse clinical joint recording receives no effect model.
 fig,axs=axes4(['GRD: observed clinical code co-recording','GRD: broad genital-status co-recording','Age profile of broad menopausal codes','Diagnostic depth: median and IQR'])
 main=co[co.unit.eq('Episodes 2019–2024')&co.outcome.eq('Dementia or parkinsonism')]
 ax=next(axs);g='menopausal_disorders';r=main[main.code_group.eq(g)].iloc[0];x=np.arange(2);den=np.array([r.neurological_positive,r.denominator-r.neurological_positive]);n=np.array([r.both,r.code_only]);ax.bar(x,n/den*10000,color=[COL[1],COL[0]],width=.6)
 for i in x:ax.text(i,n[i]/den[i]*10000+.12,f'{int(n[i])}/{int(den[i]):,}',ha='center',fontsize=6.5)
 ax.set(xticks=x,xticklabels=['Dementia or\nparkinsonism code','Neither core\nneurological code'],ylabel='N95.1/8/9 per 10,000 episodes');ax.margins(y=.25)
 ax=next(axs);r=main[main.code_group.eq('genital_absence_status')].iloc[0];den=np.array([r.neurological_positive,r.denominator-r.neurological_positive]);n=np.array([r.both,r.code_only]);ax.bar(x,n/den*10000,color=[COL[1],COL[0]],width=.6)
 for i in x:ax.text(i,n[i]/den[i]*10000+2,f'{int(n[i])}/{int(den[i]):,}',ha='center',fontsize=6.5)
 ax.set(xticks=x,xticklabels=['Dementia or\nparkinsonism code','Neither core\nneurological code'],ylabel='Z90.7 per 10,000 episodes');ax.margins(y=.25)
 ax=next(axs);aa=csv('grd_age_by_observation_unit.csv')
 for i,unit in enumerate(['Episodes 2021–2024','First observed episode per woman 2021–2024']):
  z=aa[aa.unit.eq(unit)].set_index('age_band').reindex(AGE[2:]);ax.plot(np.arange(5),z.menopausal_disorders_any/z.denominator*10000,marker=['o','s'][i],color=COL[i],linestyle=['-','--'][i],label=['Episodes','First observed episode'][i])
 ax.set(xticks=np.arange(5),xticklabels=AGE[2:],xlabel='Age at observed episode (years)',ylabel='N95.1/8/9 per 10,000 observations');ax.legend(frameon=False)
 ax=next(axs);z=profile[profile.unit.eq('Episodes 2019–2024')]
 for i,row in enumerate(z.itertuples()):ax.errorbar(row.n_dx_median,i,xerr=[[row.n_dx_median-row.n_dx_p25],[row.n_dx_p75-row.n_dx_median]],fmt=['o','s','^'][i],color=COL[i],capsize=3)
 ax.set(yticks=np.arange(3),yticklabels=['All eligible women','N95.1/8/9 coded','Dementia/parkinsonism'],xlabel='Number of diagnostic positions used');ax.invert_yaxis();ax.xaxis.set_major_locator(MaxNLocator(integer=True))
 export(fig,'Hospital_Figure2_corecording')
 # Fig H3: provider variation and observation-unit sensitivity, all descriptive.
 fig,axs=axes4(['Hospitals with a broad menopausal code','Hospital recording-rate distribution','Episode versus first-person summary','Unclassified recorded sex'])
 ax=next(axs);z=hospital[hospital.code_group.eq('menopausal_disorders')];ax.plot(z.year,z.hospitals_with_positive_code/z.hospitals*100,marker='o',color=COL[0]);ax.set(xlabel='GRD file year',ylabel='Hospitals recording ≥1 code (%)',ylim=(0,100))
 for row in z.itertuples():ax.annotate(f'{row.hospitals_with_positive_code}/{row.hospitals}',(row.year,row.hospitals_with_positive_code/row.hospitals*100),xytext=(0,6),textcoords='offset points',ha='center',fontsize=6)
 ax=next(axs);ax.plot(z.year,z.rate_median,marker='o',color=COL[0],label='Median');ax.fill_between(z.year,z.rate_p25,z.rate_p75,color=COL[0],alpha=.16,label='IQR');ax.plot(z.year,z.rate_p90,ls='--',marker='s',color=COL[1],label='90th percentile');ax.set(xlabel='GRD file year',ylabel='N95.1/8/9 per 10,000 female episodes');ax.legend(frameon=False)
 ax=next(axs);z=co[co.outcome.eq('Dementia or parkinsonism')&co.code_group.eq('menopausal_disorders')&co.unit.isin(['ID-consistent episodes 2021–2024','First observed episode per woman 2021–2024'])].copy();xx=np.arange(len(z));ax.bar(xx,z.code_positive/z.denominator*10000,color=COL[:2],width=.6)
 for i,row in enumerate(z.itertuples()):ax.text(i,row.code_positive/row.denominator*10000+.12,f'{row.code_positive}/{row.denominator:,}',ha='center',fontsize=6.5)
 ax.set(xticks=xx,xticklabels=['ID-consistent\nepisodes','First observed\nepisode per woman'],ylabel='N95.1/8/9 per 10,000 observations');ax.margins(y=.25)
 ax=next(axs);ax.plot(qc_d.year,qc_d.sex_unknown/qc_d.all_records*100,marker='o',color=COL[0],label='DEIS sex unclassified');ax.plot(qc_g.year,qc_g.sex_unknown/qc_g.all_records*100,marker='s',color=COL[1],label='GRD sex unclassified');ax.set(xlabel='Source file year',ylabel='Unclassified recorded sex (%)');ax.legend(frameon=False,fontsize=6.5);ax.xaxis.set_major_locator(MaxNLocator(5,integer=True))
 export(fig,'Hospital_Figure3_heterogeneity_qc')
 build_metadata(deis,grd,co,flow,totals,qc_d,qc_g,manifest,audit)
 print('Hospital figures and English evidence metadata rebuilt from public aggregates.',flush=True)

def build_metadata(deis,grd,co,flow,totals,qc_d,qc_g,manifest,audit):
 def fmt(x):return f'{int(x):,}'
 def val(frame,col):return int(frame[col].sum())
 nw=val(grd,'denominator');nd=val(deis,'denominator');recent=deis[deis.year>=2019]
 coreco=co[co.unit.eq('Episodes 2019–2024')&co.outcome.eq('Dementia or parkinsonism')]
 r=coreco[coreco.code_group.eq('menopausal_disorders')].iloc[0]
 rs=coreco[coreco.code_group.eq('genital_absence_status')].iloc[0]
 first=co[co.unit.eq('First observed episode per woman 2021–2024')&co.outcome.eq('Dementia or parkinsonism')&co.code_group.eq('menopausal_disorders')].iloc[0]
 # Presentation-ready tables retain exact source-derived counts.
 tables=[]
 rows=[]
 for g in ['climacteric_n951','menopausal_disorders','artificial_menopause','primary_ovarian_failure','postprocedural_ovarian_failure','genital_absence_status','postmenopausal_bleeding','postmenopausal_atrophic_vaginitis']:
  rows.append([LABELS[g],fmt(recent[g+'_principal'].sum()),fmt(grd[g+'_principal'].sum()),fmt(grd[g+'_any'].sum())])
 tables.append(dict(id='hospital-code-counts',title='Recorded code frequencies in the common 2019–2024 window',columns=['Recorded group','DEIS principal, all female ages','GRD principal, female ≥45','GRD any position, female ≥45'],rows=rows,note=f'DEIS denominator {fmt(recent.denominator.sum())} female discharges; GRD denominator {fmt(nw)} female episodes. Age scopes and source coverage differ. Components and composites can overlap. Z90.7 is broad acquired genital-organ absence; it is not a BSO or hormone-exposure proxy. N95.0 and N95.2 are additional recorded-condition comparators, outside the primary broad N95.1/8/9 definition.'))
 rows=[]
 for rr in coreco.itertuples():
  if rr.code_group in ['climacteric_n951','menopausal_disorders','menopause_clinical_composite','genital_absence_status']:
   rows.append([LABELS[rr.code_group],fmt(rr.both),fmt(rr.code_only),fmt(rr.neurological_only),fmt(rr.neither)])
 tables.append(dict(id='hospital-corecording',title='Same-episode co-recording among GRD women aged ≥45, 2019–2024',columns=['Recorded group','Both','Group only','Dementia/parkinsonism only','Neither'],rows=rows,note=f'The denominator is {fmt(nw)} episodes, not unique people. Dementia/parkinsonism denotes a code in any available diagnostic position in the same episode. These unadjusted two-by-two cells describe selected hospital records and cannot estimate disease risk, treatment effects or unmet need. No clinical regression was fitted because joint clinical cells were sparse.'))
 rows=[]
 for unit in ['Episodes 2021–2024','ID-consistent episodes 2021–2024','First observed episode per woman 2021–2024']:
  z=co[co.unit.eq(unit)&co.outcome.eq('Dementia or parkinsonism')&co.code_group.eq('menopausal_disorders')].iloc[0]
  rows.append([unit,fmt(z.denominator),fmt(z.code_positive),fmt(z.both),f'{z.code_positive/z.denominator*10000:.2f}'])
 tables.append(dict(id='hospital-person-sensitivity',title='Observation-unit sensitivity for broad menopause-code recording, age ≥45',columns=['Observation unit','Denominator','N95.1/8/9 coded','Also dementia/parkinsonism','Per 10,000 observations'],rows=rows,note=f'Comparable observed-ID window 2021–2024. {fmt(flow["female_missing_id_episodes"])} female episodes had no usable identifier; {fmt(flow["sex_discordant_ids_allsex"])} identifiers in the all-sex eligible frame had discordant recorded sex, involving {fmt(flow["female_sex_discordant_id_episodes"])} female episodes. These episodes remain in the full episode summary and are excluded from the ID-consistent and first-person summaries. First observed episode means the first eligible episode in the available window, not lifetime first attendance, menopause onset or incident neurological disease.'))
 qcrows=[]
 for y in range(2019,2025):
  dd=qc_d[qc_d.year.eq(y)].iloc[0];gg=qc_g[qc_g.year.eq(y)].iloc[0]
  qcrows.append([str(y),fmt(dd.all_records),fmt(dd.women),fmt(dd.sex_unknown),fmt(gg.all_records),fmt(gg.female_45plus),fmt(gg.female_45plus_id_missing)])
 tables.append(dict(id='hospital-source-qc',title='Source totals and eligibility audit, 2019–2024',columns=['Year','DEIS all discharges','DEIS women','DEIS sex unclassified','GRD all episodes','GRD women ≥45','GRD women ≥45 ID missing'],rows=qcrows,note='The full DEIS scan covers 2001–2024. Unclassified sex is retained in source QC, and is not imputed from the diagnosis. The dominant non-classifiable DEIS value is the literal asterisk. GRD episode summaries do not exclude missing identifiers. Missing/negative ages are retained in QC and excluded only by the explicit age≥45 eligibility rule. Age>110 is flagged and a separate sensitivity is supplied. Raw GRD45+ counts and every analysed code-group numerator reconcile with the independently prepared mf19 files.'))
 # Exact source-supported age/sector table, without synthesising45–64 from decade bands.
 rows=[]
 for age in DAGE:
  for sector in ['SNSS','Non-SNSS']:
   z=recent[recent.age_band.eq(age)&recent.sector.eq(sector)];den=int(z.denominator.sum());n=int(z.menopausal_disorders_principal.sum())
   rows.append([age,sector,fmt(den),fmt(n),f'{n/den*10000:.3f}' if den else '—'])
 tables.append(dict(id='hospital-deis-age-sector',title='National principal menopause-code recording by available age band and sector, 2019–2024',columns=['Age band','Sector','Female discharges','N95.1/8/9 principal','Per 10,000 discharges'],rows=rows,note='SNSS denotes establishments belonging to the National Health Services System; Non-SNSS is the source non-belonging category and should not be equated with a fully characterised insurance/private-ownership group. The female denominator includes only records with classifiable female sex. Decade age bands are retained; 45–64 cannot be reconstructed for 2019–2023. The source sex-unclassified records are reported separately.'))
 methods=[{'id':'hospital-source-design','title':'Hospital source scope and operational diagnostic definitions','paragraphs':[
  'This extension used the full national DEIS principal-diagnosis hospital-discharge files for 2001–2024 and full FONASA public-hospital GRD episode files for 2019–2024. DEIS covers public and private establishments. GRD retains hospital stays, major ambulatory surgery and other coded activities; the primary GRD population was women aged45 years or older at the recorded admission. The sources were analysed separately, without patient linkage between DEIS and GRD and without an individual medication history.',
  'The primary narrow recorded menopause definition was N95.1. The broader menopause/perimenopause definition was N95.1, N95.8 or N95.9. N95.3, E28.3 and E89.4 were retained as separate artificial-menopause, primary-ovarian-failure and postprocedural-ovarian-failure codes. A clearly labelled mixed clinical composite used these six codes without Z90.7. Z90.7 was a separate acquired-genital-organ-absence status, with no assumption of ovarian bilaterality, operation date or MHT use. N95.0 and N95.2 were separate additional recorded-condition comparators. Codes were verified against the DEIS-hosted WHO/PAHO2018 tabular volume and August2026 Chilean dictionary; this verifies code validity and does not establish uniform historical recording.',
  'Codes were uppercased and punctuation removed. Clinical four-character groups were matched exactly, while established neurological groups used their configured ICD10 prefixes. Dementia included F00–F03, G30, G31.0, G31.1 and G31.8; parkinsonism included G20–G23. The principal code was the first GRD diagnosis, and any-position flags used all35 diagnostic positions. In DEIS, only DIAG1 was analysed: DIAG2 is an external-cause field and was not treated as a comorbidity.'
 ]},{'id':'hospital-denominators','title':'Denominators, repeated records and descriptive analysis','paragraphs':[
  'DEIS ratios used female discharges within the same source year, supported age band and establishment-sector category. Ages were retained as <40,40–49,50–59,60–69,70–79 and≥80 years; no45–64 band was manufactured from decade bands. Region-of-residence and sector aggregates remain available separately. Counts per10,000 records describe recording among discharges or episodes and do not estimate population prevalence, access to treatment or disease incidence.',
  'GRD episode denominators retained all eligible female episodes, including those without an identifier. Raw complete-source eligibility and all code-group numerators at age≥45 were independently reconciled to existing mf19 diagnosis parquets. Source-level unknown sex, missing age, missing identifiers and discharge-condition distributions were preserved in QC. Age>110 was flagged and examined as a sensitivity, without silently deleting those observations.',
  'The first-person sensitivity used2021–2024, evaluated empirical adjacent-year ID overlap despite the2024 column-name change, and excluded missing identifiers and identifiers with discordant observed female/male sex in the full eligible all-sex frame. For each remaining person, the first eligible female-coded observed episode was selected by file year, admission date and hospital, preserving source-file order for remaining ties. Later episodes did not contribute to that sensitivity. This first record is not a lifetime first event or clinical onset.',
  'Co-recording was tabulated using complete two-by-two same-episode cells for menopause-related and dementia/parkinsonism codes, including the complement with neither core neurological code. Sparse joint clinical counts did not support a clinically interpretable adjusted regression or longitudinal effect model, so none was fitted. Hospital variation was summarised among providers with at least1,000 eligible female episodes in a year, retaining providers with zero codes. Quantile bands show distributional spread, not confidence intervals. Diagnostic-depth whiskers show IQRs. All plotted rates are observed aggregate ratios, without inferential confidence intervals or significance testing. No multiplicity-adjusted confirmatory claim is made.'
 ]}]
 sections=[{'id':'hospital-recording-results','title':'Hospital recording of menopause-related conditions','paragraphs':[
  f'The national DEIS files contained {fmt(qc_d.all_records.sum())} discharges in2001–2024, including {fmt(nd)} with classifiable female sex. The GRD files contained {fmt(qc_g.all_records.sum())} episodes in2019–2024; the primary female age≥45 denominator was {fmt(nw)} episodes. DEIS source QC retained {fmt(qc_d.sex_unknown.sum())} records with unclassified sex; the asterisk was the dominant raw value. These records were not reassigned to women from their diagnosis.',
  f'In GRD women aged≥45, the broad N95.1/N95.8/N95.9 group appeared in {fmt(grd.menopausal_disorders_any.sum())} episodes in any position and {fmt(grd.menopausal_disorders_principal.sum())} as principal diagnosis. Separate any-position counts were {fmt(grd.artificial_menopause_any.sum())} for N95.3, {fmt(grd.primary_ovarian_failure_any.sum())} for E28.3 and {fmt(grd.postprocedural_ovarian_failure_any.sum())} for E89.4. Z90.7 appeared in {fmt(grd.genital_absence_status_any.sum())} episodes, but this broad status is not an individual hormone-exposure or BSO measure.',
  f'The broad N95 group co-occurred with a dementia or parkinsonism code in {fmt(r.both)} episodes, among {fmt(r.neurological_positive)} core-neurological coded episodes and {fmt(r.denominator-r.neurological_positive)} other eligible episodes. The first-observed-episode sensitivity retained {fmt(first.denominator)} women, with {fmt(first.code_positive)} broad N95-coded first episodes and {fmt(first.both)} joint records. These sparse joint cells, source selection and coding-depth differences prevent a hormonal-effect interpretation.',
  'Principal-only national discharges and any-position public-hospital episodes capture different recording processes. A low hospital frequency of a menopause code does not measure low menopausal symptom burden, lack of outpatient care, untreated symptoms or MHT availability. Provider variation may reflect case mix, clinical services, coding depth and reporting practice; it does not by itself establish access differences.'
 ]}]
 captions=[
  'Hospital figure1. Source-specific menopause-related diagnostic recording. A: annual DEIS principal N95.1/N95.8/N95.9 codes per10,000 female discharges,2001–2024, by SNSS membership. B: pooled2019–2024 DEIS ratios within source-supported decade age bands. C: principal versus any-position GRD N95.1/8/9 recording per10,000 female episodes at age≥45,2019–2024. D: separate any-position GRD component counts at age≥45. N95.1 is a subset of the broad group; the artificial and ovarian-failure codes retain their own definitions. Each panel retains its numerator, age scope and source denominator. Lines join observed annual aggregates; no inferential intervals or fitted trends are shown. SNSS membership is an establishment-sector field, not a complete insurance or ownership classification. These are hospital-recording frequencies, not clinical menopause prevalence, outpatient access or MHT use.',
  'Hospital figure2. Same-episode co-recording and ascertainment context among GRD women aged≥45. A: broad N95.1/N95.8/N95.9 recording per10,000 episodes with versus without a dementia/parkinsonism code; labels give numerator/denominator. B: the same display for broad acquired-genital-organ-absence status Z90.7, which is not a BSO or hormone-treatment proxy. A–B use all eligible2019–2024 episodes and are unadjusted descriptive ratios. C: age profiles using2021–2024 episodes and one first eligible observed episode per woman after identifier/sex-consistency checks. D: median number of used diagnosis positions with25th–75th percentile whiskers, for all eligible women, broad N95-coded episodes and dementia/parkinsonism-coded episodes in2019–2024. These whiskers are IQRs, not confidence intervals. Different age distributions, hospital selection and diagnostic intensity can influence co-recording. Sparse joint clinical cells did not support an adjusted clinical-effect model; none was fitted.',
  'Hospital figure3. Provider heterogeneity, observation unit and source completeness. A: percentage of GRD hospitals with at least one broad N95.1/N95.8/N95.9 record among providers with≥1,000 eligible female episodes aged≥45 in that year; labels give positive/eligible hospital counts. Zero-recording providers are retained. B: unweighted hospital distribution of broad N95 recording ratios per10,000 female episodes, showing median, IQR and90th percentile; these are provider distributions, not confidence intervals or performance thresholds. C: broad N95 recording among ID-consistent2021–2024 episodes versus one first observed episode per woman, with numerators and denominators. D: source records with unclassified recorded sex as a proportion of all records; the DEIS series covers2001–2024 and GRD2019–2024. Unclassified sex was not imputed from diagnosis. All displays describe the available records and selected hospital populations; they do not quantify unmet menopausal care or individual hormone exposure.'
 ]
 # Keep readable English word spacing in source narrative.
 fixes={'aged45':'aged 45','age≥':'age ≥','per10,000':'per 10,000','all35':'all 35','WHO/PAHO2018':'WHO/PAHO 2018','August2026':'August 2026','ICD10':'ICD-10','<40,40':'<40, 40','49,50':'49, 50','59,60':'59, 60','69,70':'69, 70','and≥':'and ≥','no45':'no 45','used2021':'used 2021','the2024':'the 2024','least1,000':'least 1,000','in2001':'in 2001','in2019':'in 2019','with25th':'with 25th','and90th':'and 90th','≥1,000':'≥1,000','eligible2019':'eligible 2019','by SNSS':'by SNSS',',2001':', 2001',',2019':', 2019','pooled2019':'pooled 2019','using2021':'using 2021','eligible2021':'eligible 2021','GRD2019':'GRD 2019','aged≥45':'aged ≥45','Age>110':'Age >110','age>110':'age >110','DEIS2019':'DEIS 2019','DEIS series covers2001':'DEIS series covers 2001','decade bands. The source':'decade bands. The source','all35':'all 35','per10,000':'per 10,000','used2021':'used 2021','≥45':'≥45','at age≥45':'at age ≥45','covers2001':'covers 2001','GRD2019':'GRD 2019','aged≥45':'aged ≥45','Age>110':'Age >110','age>110':'age >110'}
 def clean(x):
  if isinstance(x,str):
   for a,b in fixes.items():x=x.replace(a,b)
   return x
  if isinstance(x,list):return [clean(v) for v in x]
  if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
  return x
 figures=[]
 for i,name in enumerate(['Hospital_Figure1_recording_sources','Hospital_Figure2_corecording','Hospital_Figure3_heterogeneity_qc']):
  figures.append({'id':'hospital-'+str(i+1),'path':str((FOLDER/(name+'.png')).relative_to(ROOT)),'caption':clean(captions[i]),'alt':['Four panels show national principal-code frequencies, age-sector patterns and public-hospital diagnostic-position differences.','Four panels show sparse clinical same-episode co-recording, anatomical-status context, age patterns and diagnostic-depth distributions.','Four panels show provider recording variation, observation-unit sensitivity and unclassified source sex.'][i],'formats':{ext:str((FOLDER/(name+'.'+ext)).relative_to(ROOT)) for ext in ['png','svg','pdf']},'sources':['DEIS national discharges: https://deis.minsal.cl/#datosabiertos','FONASA GRD: https://public.tableau.com/views/PropuestaTableroGRD/PropuestaTableroGRD?:showVizHome=no']})
 payload=clean({'status':'completed-source-refreshed','language':'en','methods':methods,'sections':sections,'tables':tables,'figures':figures,'source_manifest':'outputs/access_diagnostic_extension_2026-10-29/hospital/hospital_source_manifest.json','code_audit':'outputs/access_diagnostic_extension_2026-10-29/hospital/code_audit/code_validity_audit.json','data_tables':[str(p.relative_to(ROOT)) for p in sorted(OUT.glob('*.csv'))],'code_definition_sources':audit['sources'],'claim_boundaries':['No individual MHT medication history.','No population clinical prevalence or incidence.','No causal hormone effect or surgery effect.','No inference of unmet care or outpatient access from low hospital coding.','Z90.7 does not identify BSO.','Age at recorded episode does not identify menopause onset.','No clinical association model fitted because joint cells were sparse.'],'reproduction_commands':['python3.14 scripts/access_extension/hospital_source_scan.py --refresh-source','python3.14 scripts/access_extension/hospital_analysis.py --refresh-private','python3.14 scripts/access_extension/hospital_analysis.py --aggregates-only']})
 for i,t in enumerate(payload['tables'],1):
  table_path=OUT/f'hospital_table_{i}.csv'
  pd.DataFrame(t['rows'],columns=t['columns']).to_csv(table_path,index=False)
  t['csv_path']=str(table_path.relative_to(ROOT));t['landscape']=True
 report={'language':'en','methods':payload['methods'],'results':payload['sections'],'figures':payload['figures'],'tables':[{k:t[k] for k in ['id','title','csv_path','note','landscape']} for t in payload['tables']]}
 (OUT/'hospital_report_content.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 (OUT/'hospital_extension.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
 (OUT/'hospital_methods_results.txt').write_text('\n\n'.join(s['title']+'\n'+'\n\n'.join(s['paragraphs']) for s in payload['methods']+payload['sections'])+'\n')

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--refresh-private',action='store_true');p.add_argument('--aggregates-only',action='store_true');a=p.parse_args()
 if a.refresh_private:first_tables()
 rebuild()
