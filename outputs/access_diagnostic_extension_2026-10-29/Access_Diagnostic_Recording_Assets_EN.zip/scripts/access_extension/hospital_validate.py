#!/usr/bin/env python3
"""Independent arithmetic, schema, source-manifest and output checks (aggregates only).

--check-private also audits the eligible first-person cache on the external disk.
No identifier or individual value is ever written to the project.
"""
from pathlib import Path
import argparse,json,hashlib,re
import numpy as np,pandas as pd
from PIL import Image
import pyarrow.parquet as pq
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/access_diagnostic_extension_2026-10-29/hospital'
PRIVATE=Path('/Volumes/Datos/Asesorias_Data/derived/Reproductive-hormones-cognitive-decline-women-Chile/access_extension/hospital')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(n):return pd.read_csv(OUT/n)
def main():
 p=argparse.ArgumentParser();p.add_argument('--check-private',action='store_true');a=p.parse_args()
 d=load('deis_source_qc.csv');g=load('grd_source_qc.csv');da=load('deis_female_age_sector.csv');ga=load('grd_female_45plus_year.csv');bysex=load('deis_principal_by_recorded_sex.csv')
 checks=[]
 assert len(d)==24 and set(d.year)==set(range(2001,2025))
 assert len(g)==6 and set(g.year)==set(range(2019,2025))
 assert int(d.all_records.sum())==38818057;assert int(g.all_records.sum())==5808535
 assert (d.women+d.men+d.sex_unknown).equals(d.all_records)
 assert (g.women+g.men+g.sex_unknown).equals(g.all_records)
 assert int(da.denominator.sum())==int(d.women.sum())==22644329
 assert int(ga.denominator.sum())==int(g.female_45plus.sum())==1496044
 assert bysex.groupby('year').denominator.sum().to_dict()==d.set_index('year').all_records.to_dict()
 assert da.groupby('year').denominator.sum().to_dict()==d.set_index('year').women.to_dict()
 assert set(da.age_band)<=set(['<40','40–49','50–59','60–69','70–79','≥80','Unknown'])
 checks+=['Full-year coverage and all-source volumes','Recorded-sex partitions and source denominators','Source-supported DEIS age bands']
 for frame in [da,ga,bysex]:
  for c in frame.columns:
   if c.endswith('_principal') or c.endswith('_any'):assert frame[c].between(0,frame.denominator).all(),c
 for c in ga.columns:
  if c.endswith('_principal'):assert (ga[c]<=ga[c[:-10]+'_any']).all(),c
 assert int(ga.menopausal_disorders_any.sum())==1080
 assert int(ga.menopausal_disorders_principal.sum())==63
 assert int(ga.genital_absence_status_any.sum())==33684
 checks+=['All numerator/denominator bounds and principal≤any positions']
 co=load('grd_corecording_2x2.csv')
 assert (co[['both','code_only','neurological_only','neither']].sum(axis=1)==co.denominator).all()
 assert (co.both+co.code_only==co.code_positive).all()
 assert (co.both+co.neurological_only==co.neurological_positive).all()
 base=co[co.code_group.eq('menopausal_disorders')&co.outcome.eq('Dementia or parkinsonism')].set_index('unit')
 assert int(base.loc['Episodes 2019–2024','both'])==16
 assert int(base.loc['Episodes 2021–2024','both'])==15
 assert int(base.loc['First observed episode per woman 2021–2024','both'])==10
 assert int(base.loc['First observed episode per woman 2021–2024','denominator'])==645328
 flow=json.loads((OUT/'grd_person_flow.json').read_text())
 assert flow['female_2021_2024_episodes']-flow['female_missing_id_episodes']-flow['female_sex_discordant_id_episodes']==flow['female_id_consistent_episodes']
 assert flow['female_id_consistent_episodes']-flow['unique_first_female_episodes']==flow['female_later_episodes_not_used_for_first_record']
 checks+=['Complete two-by-two identities','Episode/window/first-person distinction','Missing-ID and recorded-sex consistency accounting']
 rec=load('grd_mf19_reconciliation.csv')
 assert (rec.raw_all_45plus==rec.mf19_all_45plus).all() and (rec.raw_female_45plus==rec.mf19_female_45plus).all()
 for c in rec.filter(like='_match'):assert rec[c].all()
 checks+=['Independent raw versus mf19 reconciliation, all six years and configured groups']
 content=json.loads((OUT/'hospital_extension.json').read_text());report=json.loads((OUT/'hospital_report_content.json').read_text())
 assert len(content['figures'])==3 and len(content['tables'])==5
 figcheck=[]
 for f in content['figures']:
  p=ROOT/f['path'];im=Image.open(p);assert im.width>=4015 and im.info.get('dpi',(0,0))[0]>=599
  dims={'width_px':im.width,'height_px':im.height,'dpi':im.info.get('dpi')}
  for ext in ['png','pdf','svg']:assert (ROOT/f['formats'][ext]).is_file()
  assert 'confidence interval' in f['caption'] or 'inferential' in f['caption']
  figcheck.append({'path':f['path'],'sha256':sha(p),**dims,'svg_editable_text':'<text' in (ROOT/f['formats']['svg']).read_text()})
 for t in content['tables']:
  f=pd.read_csv(ROOT/t['csv_path'],dtype=str,keep_default_na=False)
  assert f.columns.tolist()==t['columns'] and f.values.tolist()==t['rows'],t['id']
 assert report['results']==content['sections'] and report['methods']==content['methods']
 checks+=['Five table exports match exact presentation cells','Report interchange matches source narrative','Three170mm-class 600dpi figures with PDF/SVG and editable SVG text']
 if a.check_private:
  import polars as pl
  f=pl.read_parquet(PRIVATE/'first_observed_female_episode_2021_2024.parquet')
  assert len(f)==flow['unique_first_female_episodes'] and f['id'].n_unique()==len(f)
  assert f['id'].null_count()==0 and f.filter(pl.col('id')=='').height==0
  assert f['age'].min()>=45 and set(f['sex'])=={'Women'}
  checks+=['External-only first-person cache: unique nonmissing IDs, female eligibility and ages']
 manifest=json.loads((OUT/'hospital_source_manifest.json').read_text());assert len(manifest['sources'])==36
 script=ROOT/manifest['script'];assert sha(script)==manifest['script_sha256']
 for f in OUT.glob('*.csv'):
  cols=pd.read_csv(f,nrows=0).columns
  assert not set(cols)&{'id','ID_BENEFICIARIO','CIP_ENCRIPTADO','date_in','FECHA_NACIMIENTO'},f
 checks+=['36 source-file hashes and source-script identity recorded','No patient identifier/date-of-birth columns in public CSVs']
 result={'status':'pass','checks':checks,'figures':figcheck,'clinical_effect_model':'not_fitted; sparse joint clinical recording, selected hospital population and no MHT history','private_checked':a.check_private,'source_file_count':len(manifest['sources']),'scripts':[{ 'path':str(p.relative_to(ROOT)),'sha256':sha(p)} for p in sorted((ROOT/'scripts/access_extension').glob('hospital_*.py'))]}
 (OUT/'hospital_validation.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
 if a.check_private:(OUT/'hospital_private_validation.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({'status':'pass','checks':len(checks),'figures':len(figcheck),'tables':5,'first_person_n':flow['unique_first_female_episodes'],'model_fitted':False},indent=2))
if __name__=='__main__':main()
