"""Audit official annual coded REM templates without editing historical analyses."""
from pathlib import Path
import hashlib,json,os,re,unicodedata
import openpyxl
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
DATA=Path(os.environ.get('ASESORIAS_DATA_ROOT','/Volumes/Datos/Asesorias_Data'))
OUT=ROOT/'outputs/access_diagnostic_extension_2026-10-29/rem'
TARGETS={'A03':['03600180','03600190','03600210','03600220','03600230'],
 'A05':['01080090'],'A29':['29101711','29101712','29101713','29101160','29101210'],
 'P1':['P1030301','P1060040','P1060050','P1060060','P1700101','P1700102','P1700103','P1200340']}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def code(v):
 if v is None:return ''
 if isinstance(v,(int,float)):return str(int(v)).zfill(8)
 return str(v).strip()
def clean(v):return ' '.join(str(v).split())
def run():
 OUT.joinpath('dictionary_audit').mkdir(parents=True,exist_ok=True)
 proof=[];table=[];files=[]
 for year in range(2019,2026):
  af=next(f for f in (DATA/f'REM/SerieA/metadata/diccionarios/{year}').glob('*') if re.search(r'(^|[ _])SA[ _-]',f.name,re.I) and f.suffix in ['.xlsx','.xlsm'])
  pf=next(f for f in (DATA/f'REM/SerieP/diccionarios/{year}').glob('*') if f.suffix in ['.xlsx','.xlsm'])
  for path,sheets in [(af,['A03','A05','A29']),(pf,['P1'])]:
   files.append({'year':year,'path':str(path),'sha256':sha(path)})
   book=openpyxl.load_workbook(path,read_only=True,data_only=True)
   for sn in sheets:
    source_rows=list(book[sn].iter_rows())
    rows=[[cell.value for cell in row] for row in source_rows]
    for i,r in enumerate(rows):
     c=code(r[0])
     if c not in TARGETS[sn]:continue
     cells=[{'cell':f'{openpyxl.utils.get_column_letter(j+1)}{i+1}','value':clean(v)} for j,v in enumerate(r[:35]) if v is not None]
     cols=[x for x in cells if re.fullmatch('COL[0-9]{2}',x['value'])]
     if not cols:continue  # Ignore a duplicate ID listed only as deleted/reference material.
     for x in cols:
      column_letters=openpyxl.utils.cell.coordinate_from_string(x['cell'])[0]
      cell=source_rows[i][openpyxl.utils.cell.column_index_from_string(column_letters)-1]
      x['locked']=cell.protection.locked
      x['fill_colour_type']=cell.fill.fgColor.type
      x['fill_colour']=cell.fill.fgColor.index
     before=[]
     for k in range(max(0,i-7),i):
      if code(rows[k][0]) in TARGETS[sn]:continue
      nonempty=[{'cell':f'{openpyxl.utils.get_column_letter(j+1)}{k+1}','value':clean(v)} for j,v in enumerate(rows[k][:35]) if v is not None]
      if nonempty:before.append(nonempty)
     item={'year':year,'sheet':sn,'code':c,'label':clean(r[1]),'source':str(path),'row':i+1,'data_cells':cols,'preceding_header_cells':before}
     proof.append(item);table.append({'year':year,'sheet':sn,'code':c,'source_label':clean(r[1]),'row':i+1,'coded_columns':';'.join(x['value'] for x in cols),'source_file':path.name})
   book.close()
 payload={'status':'Annual local official coded templates opened and read','years':list(range(2019,2026)),'files':files,'records':proof}
 (OUT/'dictionary_audit/annual_mapping_proof.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False))
 pd.DataFrame(table).to_csv(OUT/'dictionary_audit/annual_code_inventory.csv',index=False)
 for p in proof:
  if p['code'] in ['03600180','01080090','29101711','P1030301']:
   print(p['year'],p['sheet'],p['code'],[(x['cell'],x['value']) for x in p['data_cells']],p['preceding_header_cells'][-3:])
 return payload
if __name__=='__main__':run()
