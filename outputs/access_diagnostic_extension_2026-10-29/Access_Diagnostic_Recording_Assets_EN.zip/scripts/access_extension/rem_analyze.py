"""Rebuild menopause-care descriptive aggregates from source-preserving REM caches.

No absent row or blank source cell is imputed as zero. Outputs contain only
public-facility aggregates; historical reports are never overwritten.
"""
from pathlib import Path
import hashlib,json,os,sys
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(Path(__file__).parent))
from rem_extract import DATA,PRIVATE,OUT
DERIVED=DATA/'derived/Reproductive-hormones-cognitive-decline-women-Chile'
CORE={'P1030301':'care','P1060040':'mrs_assessed','P1060050':'mrs_high','P1060060':'mht'}
P1={**CORE,'P1700101':'mrs_entry','P1700102':'mrs_followup','P1700103':'mrs_improved_low','P1200340':'workshop'}
A03={'03600180':'mrs_applications','03600190':'mrs_high_assessments','03600210':'mrs_somatic','03600220':'mrs_psychological','03600230':'mrs_urogenital'}
A29={'29101711':'gyn_climacteric','29101712':'fsh_climacteric','29101713':'ultrasound_climacteric','29101160':'legacy_climacteric_package','29101210':'legacy_fsh'}
def save(d,name):d.to_csv(OUT/name,index=False)
def countstatus(v,present=True):
 if not present:return 'absent_row'
 if pd.isna(v):return 'blank_cell'
 return 'explicit_zero' if v==0 else 'positive' if v>0 else 'invalid_negative'
def raw(year,serie):
 d=pd.read_csv(PRIVATE/f'raw_selected_{serie}_{year}.csv.gz',dtype=str,keep_default_na=False)
 duplicate=d.duplicated();dup=d.loc[duplicate].copy();d=d.loc[~duplicate].copy()
 key=list(d.columns[:5]);conflict=d.duplicated(key,keep=False);bad=d.loc[conflict].copy();d=d.loc[~conflict].copy()
 if len(bad):bad.to_csv(PRIVATE/f'conflicting_keys_{serie}_{year}.csv.gz',index=False)
 for c in [*list(d.columns[:4]),'IdRegion','IdComuna']:
  d[c]=pd.to_numeric(d[c],errors='coerce')
 for c in [f'Col{i:02d}' for i in range(1,51)]:
  parsed=pd.to_numeric(d[c],errors='coerce')
  assert not (parsed.isna()&d[c].str.strip().ne('')).any(), f'Unexpected nonnumeric source value: {serie} {year} {c}'
  d[c]=parsed
 assert not d[[f'Col{i:02d}' for i in range(1,51)]].lt(0).any().any()
 return d,dup,bad
def denominators():
 """Direct December FONASA bands, apportioned without zero-filling missing shares."""
 pop=pd.read_csv(DERIVED/'denominators/pop_comuna_single.csv.gz')
 pop=pop[(pop.sex=='Mujer')&pop.year.between(2019,2025)&pop.age.between(40,79)]
 ctx=pd.read_csv(ROOT/'outputs/multifuente/tables/centers_context.csv')
 maps=ctx[['estab','comuna']].drop_duplicates('estab').rename(columns={'comuna':'catalogue_comuna'})
 allframes=[];proof=[]
 for y in range(2019,2026):
  f=DATA/f'FONASA/APS/Inscritos_APS_{y}12.csv'
  try:d=pd.read_csv(f,dtype=str,encoding='utf8')
  except UnicodeDecodeError:d=pd.read_csv(f,dtype=str,encoding='latin1')
  d=d[d.SEXO.str.strip().str.lower().eq('mujeres')].copy()
  d['year']=y;d['estab']=pd.to_numeric(d.COD_CENTRO.str.strip(),errors='coerce')
  d['n']=pd.to_numeric(d.TOTAL_INSCRITOS,errors='coerce')
  bounds=d.EDAD_TRAMO.str.extract(r'^(\d+)\s*a\s*(\d+)')
  d['lo']=pd.to_numeric(bounds[0],errors='coerce');d['hi']=pd.to_numeric(bounds[1],errors='coerce')
  d=d[d.lo.le(64)&d.hi.ge(45)].copy()
  assert d.n.notna().all() and d.n.ge(0).all(), 'Invalid target-age FONASA count'
  proof.append({'year':y,'source':str(f),'observed_bands':sorted(d.EDAD_TRAMO.unique()),'age_bounds_parsed_from_labels':True})
  d=d.groupby(['year','estab','lo','hi'],as_index=False).n.sum(min_count=1).merge(maps,on='estab',how='left')
  parts=[]
  for (lo,hi),g in d.groupby(['lo','hi']):
   p=pop[pop.year.eq(y)&pop.age.between(lo,hi)]
   den=p.groupby('comuna').pop.sum();num=p[p.age.between(max(45,lo),min(64,hi))].groupby('comuna').pop.sum()
   share=(num/den).rename('share').reset_index().rename(columns={'comuna':'catalogue_comuna'})
   g=g.merge(share,on='catalogue_comuna',how='left');g['part']=g.n*g.share
   parts.append(g)
  p=pd.concat(parts);g=p.groupby(['year','estab'],as_index=False).agg(estimated_enrolled_women_45_64=('part',lambda z:z.sum(min_count=1)),missing_age_share=('share',lambda z:z.isna().any()),raw_age_band_enrolment=('n','sum'))
  g.loc[g.missing_age_share,'estimated_enrolled_women_45_64']=np.nan
  allframes.append(g)
 result=pd.concat(allframes,ignore_index=True)
 result.to_csv(PRIVATE/'fonasa_women_45_64_rebuilt.csv.gz',index=False)
 (OUT/'fonasa_age_mapping.json').write_text(json.dumps(proof,indent=2))
 return result,ctx
def build():
 OUT.mkdir(parents=True,exist_ok=True)
 proof=json.loads((OUT/'dictionary_audit/annual_mapping_proof.json').read_text())
 allowed={(x['year'],x['sheet'],x['code']) for x in proof['records']}
 for code in ['29101712','29101713']:
  item=next(x for x in proof['records'] if x['year']==2025 and x['code']==code)
  cells={x['value']:x for x in item['data_cells']}
  assert all(cells[c].get('locked') and cells[c].get('fill_colour')==22 for c in ['COL06','COL08']), 'Recheck 2025 A29 structural modality mapping'
 records=[];dups=[];quarantine=[];legacy=[]
 for y in range(2019,2026):
  for serie in ['P','A']:
   d,dup,bad=raw(y,serie)
   for frame,label in [(dup,'identical_duplicate_removed'),(bad,'conflicting_key_quarantined')]:
    for c,g in frame.groupby('CodigoPrestacion'):
     du={'year':y,'serie':serie,'code':c,'disposition':label,'rows':len(g)}
     for col in ['Col01','Col02','Col03']:du[col+'_sum']=pd.to_numeric(g[col],errors='coerce').sum(min_count=1)
     dups.append(du)
   if serie=='P':d=d[d.Mes.eq(12)]
   for c,g in d.groupby('CodigoPrestacion'):
    if c in P1:sheet='P1';metric=P1[c]
    elif c in A03:sheet='A03';metric=A03[c]
    elif c in A29:sheet='A29';metric=A29[c]
    elif c=='01080090':sheet='A05';metric='programme_entries'
    else:continue
    if (y,sheet,c) not in allowed:
     quarantine.append({'year':y,'sheet':sheet,'code':c,'rows':len(g),'reason':'Not mapped in annual coded template'});continue
    mapping=[]
    if sheet=='P1':
     mapping=[('45-64','snapshot','Col01' if y<2025 else 'Col02')]
     if y==2025:mapping.append(('<45','snapshot','Col01'))
    elif sheet=='A03':mapping=[('source-defined climacteric ages','entry','Col01'),('source-defined climacteric ages','followup_no_mht','Col02'),('source-defined climacteric ages','followup_mht','Col03')]
    elif sheet=='A05':mapping=[('unstratified','total','Col01')]
    elif metric.startswith('legacy_'):mapping=[('unstratified','legacy_total','Col01')]
    elif y<2025:
     mapping=[('all reported ages','total','Col01'),('45-64','age_specific','Col02'),('65+','age_specific','Col03'),('all reported ages','institutional_in_person','Col04'),('all reported ages','institutional_remote','Col05'),('all reported ages','purchased_in_person','Col06'),('all reported ages','purchased_remote','Col07')]
    else:
     mapping=[('all reported ages','total','Col01'),('40-44','age_specific','Col02'),('45-64','age_specific','Col03'),('65+','age_specific','Col04'),('all reported ages','institutional_in_person','Col05'),('all reported ages','institutional_remote','Col06'),('all reported ages','purchased_in_person','Col07'),('all reported ages','purchased_remote','Col08')]
     # 2025 A29 coded template: FSH/ultrasound remote cells are grey and locked.
     # A numeric-looking COL label in a disabled cell is not an observed variable.
     if metric in ['fsh_climacteric','ultrasound_climacteric']:
      mapping=[x for x in mapping if x[1] not in ['institutional_remote','purchased_remote']]
    for age,context,col in mapping:
     z=g[['Mes','IdEstablecimiento','IdComuna','IdRegion',col]].rename(columns={'Mes':'month','IdEstablecimiento':'estab','IdComuna':'source_comuna','IdRegion':'source_region',col:'value'}).copy()
     z=z.assign(year=y,serie=serie,sheet=sheet,code=c,metric=metric,age_scope=age,context=context,source_column=col)
     z['cell_status']=np.where(z.value.isna(),'blank_cell',np.where(z.value.eq(0),'explicit_zero','positive'))
     records.append(z)
 rawlong=pd.concat(records,ignore_index=True)
 # Codes identify public facilities and aggregate cells only, never individual people.
 rawlong.to_csv(PRIVATE/'hormonal_source_cells.csv.gz',index=False)
 save(pd.DataFrame(dups),'duplicate_and_conflict_audit.csv');save(pd.DataFrame(quarantine),'unmapped_code_quarantine.csv')
 den,ctx=denominators()
 p=rawlong[(rawlong.sheet=='P1')&(rawlong.age_scope=='45-64')]
 assert not p.duplicated(['year','estab','metric']).any()
 pairs=pd.concat([den[['year','estab']],p[['year','estab']]]).drop_duplicates()
 wide=pairs.merge(den,on=['year','estab'],how='left')
 for metric in P1.values():
  z=p[p.metric.eq(metric)][['year','estab','value','cell_status']].rename(columns={'value':metric,'cell_status':metric+'_status'})
  wide=wide.merge(z,on=['year','estab'],how='left');wide[metric+'_status']=wide[metric+'_status'].fillna('absent_row')
  if metric in ['mrs_entry','mrs_followup','mrs_improved_low']:wide.loc[wide.year.lt(2025),metric+'_status']='not_in_template'
 ccols=['estab','comuna','comuna_name','region13','type_group','lat','lon','poverty_multi','rural_share','pct_tramo_a','enrolled_2024']
 wide=wide.merge(ctx[ccols],on='estab',how='left')
 wide['denominator_status']=np.where(wide.estimated_enrolled_women_45_64.isna(),'unavailable',np.where(wide.estimated_enrolled_women_45_64.gt(0),'positive','zero'))
 for metric in CORE.values():wide[metric+'_per1000']=1000*wide[metric]/wide.estimated_enrolled_women_45_64.where(wide.estimated_enrolled_women_45_64.gt(0))
 save(wide,'facility_year_hormonal_care.csv')
 # Full-universe status counts retain absent, blank and zero as separate categories.
 summaries=[];national=[]
 for (y,metric),g in p.groupby(['year','metric']):
  v=g.value
  for status,n in g.cell_status.value_counts().items():summaries.append({'year':y,'metric':metric,'status':status,'facilities':int(n),'universe':'P1 row represented'})
  eligible=wide[wide.year.eq(y)&wide.estimated_enrolled_women_45_64.gt(0)]
  for status,n in eligible[metric+'_status'].value_counts().items():summaries.append({'year':y,'metric':metric,'status':status,'facilities':int(n),'universe':'Positive FONASA denominator'})
  matched=wide[wide.year.eq(y)&wide.estimated_enrolled_women_45_64.gt(0)&wide[metric].notna()]
  national.append({'year':y,'metric':metric,'all_numeric_recorded_count':v.sum(min_count=1),'source_rows':len(g),'numeric_cells':int(v.notna().sum()),'explicit_zero_cells':int(v.eq(0).sum()),'blank_cells':int(v.isna().sum()),'matched_facilities':len(matched),'matched_count':matched[metric].sum(min_count=1),'matched_estimated_enrolment':matched.estimated_enrolled_women_45_64.sum(),'matched_rate_per1000':1000*matched[metric].sum(min_count=1)/matched.estimated_enrolled_women_45_64.sum()})
 save(pd.DataFrame(summaries),'p1_source_status_by_year.csv');save(pd.DataFrame(national),'p1_national_recording.csv')
 acts=rawlong[rawlong.serie.eq('A')]
 group=['year','sheet','code','metric','age_scope','context']
 annual=acts.groupby(group,dropna=False).agg(recorded_count=('value',lambda x:x.sum(min_count=1)),source_cells=('value','size'),numeric_cells=('value','count'),explicit_zero_cells=('value',lambda x:x.eq(0).sum()),blank_cells=('value',lambda x:x.isna().sum()),represented_facilities=('estab','nunique'),calendar_months=('month','nunique')).reset_index()
 save(annual,'annual_activity_counts.csv')
 facility=acts.groupby(group+['estab'],dropna=False).agg(recorded_count=('value',lambda x:x.sum(min_count=1)),represented_months=('month','nunique'),numeric_months=('value','count'),explicit_zero_months=('value',lambda x:x.eq(0).sum()),blank_months=('value',lambda x:x.isna().sum())).reset_index()
 save(facility,'facility_year_activity_counts.csv')
 # Matched source-cell high-score ratios; contexts are selected populations, not treatment comparisons.
 idcols=['year','estab','month','context','age_scope']
 a=acts[acts.metric.eq('mrs_applications')][idcols+['value']].rename(columns={'value':'applications'})
 h=acts[acts.metric.eq('mrs_high_assessments')][idcols+['value']].rename(columns={'value':'high'})
 matched=a.merge(h,on=idcols,how='outer');matched['joint_numeric']=matched.applications.notna()&matched.high.notna();matched['high_exceeds_applications']=matched.joint_numeric&matched.high.gt(matched.applications)
 matched.to_csv(PRIVATE/'mrs_context_cell_matching.csv.gz',index=False)
 ratios=[]
 for (y,context),g in matched.groupby(['year','context']):
  q=g[g.joint_numeric&g.applications.gt(0)]
  screened=q[q.high.le(q.applications)]
  ratios.append({'year':y,'context':context,'joint_numeric_cells':int(g.joint_numeric.sum()),'positive_application_matched_cells':len(q),'applications':q.applications.sum(),'high':q.high.sum(),'high_per100_applications':100*q.high.sum()/q.applications.sum() if q.applications.sum()>0 else np.nan,'high_above_applications_cells':int(g.high_exceeds_applications.sum()),'unmatched_or_blank_cells':int((~g.joint_numeric).sum()),'screened_cells':len(screened),'screened_applications':screened.applications.sum(),'screened_high':screened.high.sum(),'screened_high_per100':100*screened.high.sum()/screened.applications.sum() if screened.applications.sum()>0 else np.nan})
 save(pd.DataFrame(ratios),'mrs_context_matched_ratios.csv')
 # Publish sufficient QC aggregates so figures and tables rebuild without private cells.
 aq=[]
 for (y,m),g in acts[acts.sheet.eq('A29')&~acts.metric.str.startswith('legacy')].groupby(['year','metric']):
  p=g.pivot(index=['year','estab','month'],columns=['age_scope','context'],values='value')
  total=p[('all reported ages','total')]
  ages=['45-64','65+'] if y<2025 else ['40-44','45-64','65+']
  ag=p[[(x,'age_specific') for x in ages]];full=ag.notna().all(axis=1)&total.notna();known=ag.sum(axis=1,min_count=1)
  mode=p.loc[:,p.columns.get_level_values(1).isin(['institutional_in_person','institutional_remote','purchased_in_person','purchased_remote'])];mf=mode.notna().all(axis=1)&total.notna()
  aq.append({'year':y,'metric':m,'source_cells':len(p),'all_age_total_numeric':int(total.notna().sum()),'all_age_components_numeric':int(full.sum()),'complete_age_sum_disagrees':int((full&known.ne(total)).sum()),'known_partial_age_sum_exceeds_total':int((total.notna()&known.gt(total)).sum()),'applicable_mode_columns':len(mode.columns),'all_mode_components_numeric':int(mf.sum()),'complete_mode_sum_disagrees':int((mf&mode.sum(axis=1).ne(total)).sum()),'structurally_inapplicable_modes':'Institutional remote; purchased remote' if y==2025 and m!='gyn_climacteric' else 'None identified in inspected coded template','mode_interpretation':'Institutional/purchased explicit in 2025; historical unqualified/purchased columns retained separately; mode sums are a descriptive source screen, not an imposed partition'})
 save(pd.DataFrame(aq),'a29_age_modality_consistency.csv')
 # Compare new core source totals with the frozen legacy table, without changing it.
 old=pd.read_csv(ROOT/'outputs/multifuente/tables/mht_national.csv').set_index('year')
 nat=pd.DataFrame(national);comparison=[]
 for code,metric in CORE.items():
  oldcol={'care':'en_control','mrs_assessed':'mrs_aplicada','mrs_high':'mrs_elevado','mht':'thm'}[metric]
  for _,r in nat[nat.metric.eq(metric)].iterrows():
   ov=float(old.loc[int(r.year),oldcol]);comparison.append({'year':int(r.year),'metric':metric,'legacy_count':ov,'deduplicated_source_numeric_count':r.all_numeric_recorded_count,'difference':r.all_numeric_recorded_count-ov,'explanation':'Exact source-row deduplication and numeric-cell preservation; age column checked against each annual template'})
 save(pd.DataFrame(comparison),'legacy_p1_comparison.csv')
 # 2025 new rows are separate overlapping history indicators, not a disjoint partition.
 new=rawlong[rawlong.sheet.eq('P1')&rawlong.year.eq(2025)]
 save(new.groupby(['metric','age_scope']).agg(recorded_count=('value',lambda x:x.sum(min_count=1)),numeric_facilities=('value','count'),blank_facilities=('value',lambda x:x.isna().sum()),explicit_zero_facilities=('value',lambda x:x.eq(0).sum())).reset_index(),'p1_2025_new_rows.csv')
 qs=[]
 for y,g in wide.groupby('year'):
  for numerator,denominator in [('mrs_assessed','care'),('mrs_high','mrs_assessed'),('mrs_improved_low','mrs_followup')]:
   joint=g[numerator].notna()&g[denominator].notna()
   qs.append({'year':y,'comparison':numerator+' <= '+denominator,'joint_numeric_facilities':int(joint.sum()),'violations':int((joint&g[numerator].gt(g[denominator])).sum()),'status':'Source consistency screen, not automatic clinical correction'})
 save(pd.DataFrame(qs),'p1_consistency_screens.csv')
 # Same-year municipality totals include only valid matched denominator cells for each metric.
 municipal=[]
 for metric in CORE.values():
  z=wide[wide.estimated_enrolled_women_45_64.gt(0)&wide[metric].notna()&wide.comuna.notna()]
  m=z.groupby(['year','comuna'],as_index=False).agg(recorded_count=(metric,'sum'),estimated_enrolled_women_45_64=('estimated_enrolled_women_45_64','sum'),represented_facilities=('estab','nunique'))
  m['metric']=metric;m['per1000']=1000*m.recorded_count/m.estimated_enrolled_women_45_64;municipal.append(m)
 save(pd.concat(municipal,ignore_index=True),'municipality_year_matched_hormonal_care.csv')
 # Compare recomputed denominators with previous derived age-apportioned values.
 previous=pd.read_csv(DERIVED/'denominators/fonasa_centros_women_45_64.csv.gz').rename(columns={'part':'previous_estimated'})
 dc=den.merge(previous,on=['year','estab'],how='outer');dc['difference']=dc.estimated_enrolled_women_45_64-dc.previous_estimated
 save(dc.groupby('year').agg(paired_centres=('difference','count'),absolute_difference_sum=('difference',lambda z:z.abs().sum()),maximum_absolute_difference=('difference',lambda z:z.abs().max()),new_missing=('estimated_enrolled_women_45_64',lambda z:z.isna().sum())).reset_index(),'denominator_comparison.csv')
 audit={'years':list(range(2019,2026)),'source':'Original annual REM coded templates and raw Series A/P cells; FONASA December enrolment and municipal INE age structure','zero_policy':'Explicit numeric zero retained; blank numeric cells and absent rows stay separate, no zero imputation','duplicates':'Identical complete raw rows removed once; remaining conflicting natural keys quarantined, never arbitrarily selected','national_counts':'Sums of observed numeric cells only; no claim of complete reporting or unique people across repeated snapshots/activities','p1_2025_age_column':'Col02 for45–64; Col01 for under45. Other demographic columns are overlapping subsets.','a03_context':'Col01 entry, Col02 follow-up without MHT, Col03 follow-up with MHT, annual templates2021–25; context groups are selected and not causal treatment contrasts','a29_period':'2023–24 age45–64 Col02;2025 age45–64 Col03 with new40–44 Col02. Legacy2021–22 package/FSH scope retained separately','age_denominators':'Direct FONASA labels parsed and age-apportioned using municipal INE female structure; missing shares remain missing','private_source_cells':str(PRIVATE/'hormonal_source_cells.csv.gz'),'facility_year_output':'facility_year_hormonal_care.csv','facility_year_rows':len(wide),'legacy_core_total_differences':pd.DataFrame(comparison).query('difference != 0').to_dict('records')}
 (OUT/'rem_analysis_audit.json').write_text(json.dumps(audit,indent=2,allow_nan=False));print(json.dumps(audit,indent=2))
 return wide,rawlong
if __name__=='__main__':build()
