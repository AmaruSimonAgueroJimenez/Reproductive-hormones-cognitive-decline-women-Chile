"""Build the extension Word with readable repeated tables and adjacent definitions."""
from pathlib import Path
import json,sys,platform
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
import build_descriptive_docx as core

original_table=core.add_table
def table_with_definition(doc,entry,lang):
 note=entry.get('note','');copy=dict(entry);copy['note']=''
 original_table(doc,copy,lang)
 if entry['id'] in ['rem-national','rem-contexts','neuro-selected-caseload','association-table-sensitivity-women','association-table-sensitivity-men']:
  # Keep the established type size while preventing nearly empty continuation
  # pages for these five dense tables. Cell margins remain explicit and positive.
  for row in doc.tables[-1].rows:
   for cell in row.cells:
    for side in ['top','bottom']:
     for item in cell._tc.xpath('./w:tcPr/w:tcMar/w:'+side):item.set(core.qn('w:w'),'55')
 if note:
  # Define a long table before its first row; no definition-only spill page.
  p=core.paragraph(doc,note,'Caption',size=10)
  p.paragraph_format.keep_with_next=True;p.paragraph_format.keep_together=True
  doc.tables[-1]._tbl.addprevious(p._p)
core.add_table=table_with_definition

def main():
 out=ROOT/'outputs/access_diagnostic_extension_2026-10-29'
 dest=ROOT/'manuscript/access_diagnostic_extension_2026-10-29'
 bundle=json.loads((out/'review_bundle.json').read_text())
 result=core.build('en',bundle['languages']['en'],dest/'Methods_Results_EN.docx',bundle['content_sha256'])
 result['table_definitions']='Placed between table title and first row; repeated headers on continuation pages'
 (dest/'docx_build_manifest.json').write_text(json.dumps(result,indent=2))
 print(result['path'])
if __name__=='__main__':main()
