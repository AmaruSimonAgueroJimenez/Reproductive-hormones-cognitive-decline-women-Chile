"""Paper panels and English evidence tables for the new REM source audit."""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from matplotlib.lines import Line2D

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(Path(__file__).parent))
from rem_extract import OUT
sys.path.insert(0,str(ROOT/'scripts/paper'))
import p18_descriptive_review_figures as style

BLUE='#216A94';PURPLE='#A83266';TEAL='#168275';BROWN='#92651D'
LABELS={'care':'Climacteric care','mrs_assessed':'MRS assessed','mrs_high':'Elevated MRS','mht':'MHT recorded','mrs_entry':'MRS at entry','mrs_followup':'MRS at follow-up','mrs_improved_low':'Improved / low follow-up MRS','workshop':'Educational workshop'}
CTX={'entry':'At programme entry','followup_no_mht':'Follow-up without MHT','followup_mht':'Follow-up with MHT'}
ACT={'programme_entries':'New programme entries','gyn_climacteric':'Gynaecological consultation','fsh_climacteric':'FSH blood test','ultrasound_climacteric':'Transvaginal / rectal ultrasound','legacy_climacteric_package':'Legacy climacteric package','legacy_fsh':'Legacy FSH test'}
def save(d,name):d.to_csv(OUT/name,index=False)
def export(fig,name,caption,alt):
 p=OUT/'figures'/name;p.parent.mkdir(exist_ok=True)
 metadata={'png':{'Software':'Matplotlib '+matplotlib.__version__},'pdf':{'CreationDate':None,'ModDate':None},'svg':{'Date':None}}
 for ext in ['png','pdf','svg']:fig.savefig(p.with_suffix('.'+ext),dpi=600,facecolor='white',bbox_inches=None,metadata=metadata[ext])
 fig.savefig(p.with_name(p.name+'_preview').with_suffix('.png'),dpi=150,facecolor='white',bbox_inches=None);plt.close(fig)
 return {'path':str(p.with_suffix('.png').relative_to(ROOT)),'caption':caption,'alt':alt,'source_data':str(OUT.relative_to(ROOT)),'width_mm':180,'dpi':600}
def build():
 style.style();matplotlib.rcParams.update({'svg.fonttype':'none','svg.hashsalt':'REM-access-2026-10-29','pdf.fonttype':42,'font.size':7.5,'axes.titlesize':8,'legend.fontsize':6.3})
 wide=pd.read_csv(OUT/'facility_year_hormonal_care.csv');a=pd.read_csv(OUT/'annual_activity_counts.csv',dtype={'code':str});r=pd.read_csv(OUT/'mrs_context_matched_ratios.csv');n=pd.read_csv(OUT/'p1_national_recording.csv');status=pd.read_csv(OUT/'p1_source_status_by_year.csv')
 # All public rendering inputs are sufficient statistics, not private source caches.
 assert {'screened_high_per100','screened_applications','screened_high'}.issubset(r.columns)
 # Reporting coverage is source visibility, not a clinical provider denominator.
 f=pd.read_csv(OUT/'facility_year_activity_counts.csv',dtype={'code':str})
 coverage=f.groupby(['year','metric','age_scope','context']).agg(represented_facilities=('estab','nunique'),twelve_numeric_months=('numeric_months',lambda z:z.eq(12).sum()),median_numeric_months=('numeric_months','median'),minimum_numeric_months=('numeric_months','min')).reset_index();save(coverage,'activity_reporting_coverage.csv')
 # Source-level additive checks are published by the separate raw-refresh step.
 qc=pd.read_csv(OUT/'a29_age_modality_consistency.csv')
 # English lookup tables contain substantive counts and reporting scope together.
 activity=a[(a.context.eq('total')|a.context.eq('entry')|a.context.eq('legacy_total'))&a.metric.isin(['programme_entries','mrs_applications',*ACT])].copy()
 activity['Activity']=activity.metric.map(ACT).fillna('MRS applications at programme entry')
 activity=activity.rename(columns={'year':'Year','recorded_count':'Observed numeric count','age_scope':'Age scope','represented_facilities':'Reporting facilities','blank_cells':'Blank source cells','calendar_months':'Calendar months represented'})
 save(activity[['Year','Activity','Age scope','Observed numeric count','Reporting facilities','Blank source cells','Calendar months represented']],'table_activity_counts_en.csv')
 mr=r.copy();mr['Context']=mr.context.map(CTX)
 save(mr[['year','Context','applications','high','high_per100_applications','screened_high_per100','positive_application_matched_cells','high_above_applications_cells','unmatched_or_blank_cells']].rename(columns={'year':'Year','applications':'Matched application count','high':'Matched high-score count','high_per100_applications':'High-score ratio per100','screened_high_per100':'Ratio after count-order screen','positive_application_matched_cells':'Matched facility-month cells','high_above_applications_cells':'Count-order violations','unmatched_or_blank_cells':'Unmatched or blank cells'}),'table_mrs_context_en.csv')
 new=pd.read_csv(OUT/'p1_2025_new_rows.csv');new['Measure']=new.metric.map(LABELS)
 save(new[['Measure','age_scope','recorded_count','numeric_facilities','blank_facilities','explicit_zero_facilities']].rename(columns={'age_scope':'Age group','recorded_count':'Observed recorded count','numeric_facilities':'Numeric reporting facilities','blank_facilities':'Blank source cells','explicit_zero_facilities':'Explicit-zero facilities'}),'table_2025_p1_measures_en.csv')
 st=status[status.universe.eq('Positive FONASA denominator')].copy();st['Measure']=st.metric.map(LABELS)
 st=st.pivot_table(index=['year','Measure'],columns='status',values='facilities',fill_value=0).reset_index()
 save(st.rename(columns={'year':'Year','positive':'Positive','explicit_zero':'Explicit zero','blank_cell':'Blank source cell','absent_row':'Absent source row'}),'table_source_status_en.csv')
 old=pd.read_csv(OUT/'legacy_p1_comparison.csv');old['Measure']=old.metric.map(LABELS)
 save(old[old.difference.ne(0)][['year','Measure','legacy_count','deduplicated_source_numeric_count','difference']].rename(columns={'year':'Year','legacy_count':'Legacy frozen count','deduplicated_source_numeric_count':'New deduplicated count','difference':'New minus legacy'}),'table_legacy_deduplication_en.csv')
 nn=n.copy();nn['Measure']=nn.metric.map(LABELS)
 save(nn[['year','Measure','all_numeric_recorded_count','source_rows','numeric_cells','blank_cells','matched_facilities','matched_count','matched_estimated_enrolment','matched_rate_per1000']].rename(columns={'year':'Year','all_numeric_recorded_count':'All-source numeric count','source_rows':'Represented source rows','numeric_cells':'Numeric source cells','blank_cells':'Blank source cells','matched_facilities':'Numeric facilities with positive enrolment','matched_count':'Matched numerator','matched_estimated_enrolment':'Matched estimated female enrolment 45–64','matched_rate_per1000':'Matched records per 1,000'}),'table_p1_national_en.csv')
 da=a[a.metric.isin(['gyn_climacteric','fsh_climacteric','ultrasound_climacteric'])&a.context.eq('age_specific')].copy();da['Activity']=da.metric.map(ACT)
 save(da[['year','Activity','age_scope','recorded_count','represented_facilities','numeric_cells','blank_cells']].rename(columns={'year':'Year','age_scope':'Age group','recorded_count':'Observed numeric activity count','represented_facilities':'Represented facilities','numeric_cells':'Numeric facility-month cells','blank_cells':'Blank facility-month cells'}),'table_diagnostic_age_en.csv')
 qce=qc.copy();qce['Activity']=qce.metric.map(ACT)
 save(qce[['year','Activity','source_cells','all_age_components_numeric','complete_age_sum_disagrees','known_partial_age_sum_exceeds_total','applicable_mode_columns','all_mode_components_numeric','complete_mode_sum_disagrees','structurally_inapplicable_modes']].rename(columns={'year':'Year','source_cells':'Represented facility-month rows','all_age_components_numeric':'Complete numeric age components','complete_age_sum_disagrees':'Complete age-sum disagreements','known_partial_age_sum_exceeds_total':'Known age sums above total','applicable_mode_columns':'Applicable modality columns','all_mode_components_numeric':'Complete numeric modality components','complete_mode_sum_disagrees':'Modality-sum disagreements','structurally_inapplicable_modes':'Structurally inapplicable modalities'}),'table_diagnostic_qc_en.csv')
 schemas=[('P1 core care/MRS/MHT','P1030301; P1060040; P1060050; P1060060','2019–2025','45–64','Snapshot; 2025 Col02, earlier Col01'),('P1 entry/follow-up/improved MRS','P1700101; P1700102; P1700103','2025','<45 and 45–64','Overlapping previous-year histories'),('A03 MRS applications/high/domains','03600180; 03600190; 03600210; 03600220; 03600230','2021–2025','Source-defined climacteric ages','Entry; follow-up without MHT; follow-up with MHT'),('A05 programme entries','01080090','2019–2025','Unstratified','Annual activity flow, not diagnosis onset'),('A29 climacteric consultation/FSH/ultrasound','29101711; 29101712; 29101713','2023–2025','45–64 and 65+; adds 40–44 in 2025','Age 45–64: Col02 in 2023–24, Col03 in 2025'),('Legacy A29 package/FSH','29101160; 29101210','2021–2022','Unstratified','Different source scope, kept separate')]
 save(pd.DataFrame(schemas,columns=['Component','Codes','Mapped years','Age scope','Interpretation']),'table_annual_mapping_en.csv')
 figures=[]
 # Figure1: activity, explicit source contexts and diagnostic-service age restriction.
 fig,axs=plt.subplots(2,2,figsize=(180/25.4,150/25.4),layout='constrained')
 for ax,l,t in zip(axs.flat,'ABCD',['New climacteric programme entries','MRS application contexts','High-score recording, 2025','Climacteric diagnostic services']):style.label(ax,l,t)
 z=a[a.metric.eq('programme_entries')&a.context.eq('total')];axs[0,0].plot(z.year,z.recorded_count/1000,'o-',c=BLUE);axs[0,0].set(ylabel='Observed entries (thousands)',xlabel='Year',ylim=(0,None));axs[0,0].set_xticks([2019,2021,2023,2025])
 for (c,col,mk) in [('entry',BLUE,'o'),('followup_no_mht',PURPLE,'s'),('followup_mht',TEAL,'^')]:
  z=a[a.metric.eq('mrs_applications')&a.context.eq(c)];axs[0,1].plot(z.year,z.recorded_count/1000,marker=mk,c=col,label=CTX[c])
 axs[0,1].set(ylabel='Observed applications (thousands)',xlabel='Year',ylim=(0,None));axs[0,1].set_xticks([2021,2023,2025]);axs[0,1].legend(loc='upper left',fontsize=5.8)
 rr=r[r.year.eq(2025)].set_index('context').reindex(['entry','followup_no_mht','followup_mht']);yy=np.arange(3)
 axs[1,0].scatter(rr.high_per100_applications,yy-.06,c=BLUE,marker='o',s=24,label='All numeric pairs');axs[1,0].scatter(rr.screened_high_per100,yy+.06,c=PURPLE,marker='s',s=22,label='After count-order screen');axs[1,0].set_yticks(yy,[CTX[c] for c in rr.index],fontsize=6.5);axs[1,0].invert_yaxis();axs[1,0].set(xlabel='High-score assessments /100 applications',xlim=(0,100));axs[1,0].legend(loc='upper left',fontsize=5.8)
 for metric,col,mk in [('gyn_climacteric',BLUE,'o'),('fsh_climacteric',PURPLE,'s'),('ultrasound_climacteric',TEAL,'^')]:
  z=a[a.metric.eq(metric)&a.age_scope.eq('45-64')&a.context.eq('age_specific')];axs[1,1].plot(z.year,z.recorded_count/1000,marker=mk,c=col,label=ACT[metric])
 axs[1,1].set(ylabel='Observed activity at age 45–64 (thousands)',xlabel='Year',ylim=(0,None));axs[1,1].set_xticks([2023,2024,2025]);axs[1,1].legend(loc='lower left',fontsize=5.5)
 cap='Source-verified menopause programme activity. A: annual A05 programme entries (01080090), without an age-specific denominator. B: annual A03 Menopause Rating Scale (MRS) applications at programme entry and follow-up with or without recorded menopausal hormone therapy (MHT), 2021–2025; no corresponding A03G rows were mapped in the inspected 2019–2020 templates. C: 2025 high-MRS/application ratios from facility-month pairs with numeric counts and positive applications. Squares exclude pairs with high-score counts above applications as a sensitivity screen. The three assessment contexts are selected populations and cannot estimate MHT effects. D: A29 consultations, follicle-stimulating hormone (FSH) blood tests and transvaginal/rectal ultrasound at ages 45–64; the source age column changes from Col02 in 2023–2024 to Col03 in 2025. Legacy 2021–2022 package/FSH codes have different scope. Counts sum observed numeric cells after exact-row deduplication and conflict quarantine. Blank cells and absent rows remain unobserved; reporting facilities change over time. Activity is not a patient-linked pathway, and repeated records may concern the same woman. Reporting and selection uncertainty is not quantified by sampling intervals. Sources: annual DEIS REM coded templates and original Series A files.'
 figures.append(export(fig,'Figure_REM1_activity_contexts',cap,'Four panels show programme entries, assessment contexts, paired high-score recording with a count-order sensitivity, and age 45–64 diagnostic-service activity. Source scope and observation counts differ between panels.'))
 # Figure2: source visibility and overlapping new2025 P1 fields.
 fig,axs=plt.subplots(2,2,figsize=(180/25.4,150/25.4),layout='constrained')
 for ax,l,t in zip(axs.flat,'ABCD',['December P1 recorded counts','MHT recording status','New P1 histories in 2025','New-field visibility in 2025']):style.label(ax,l,t)
 for metric,col,mk in [('care',BLUE,'o'),('mrs_assessed',TEAL,'^'),('mrs_high',BROWN,'D'),('mht',PURPLE,'s')]:
  z=n[n.metric.eq(metric)];axs[0,0].plot(z.year,z.all_numeric_recorded_count/1000,c=col,marker=mk,label=LABELS[metric])
  short={'care':'Care','mrs_assessed':'MRS assessed','mrs_high':'High MRS','mht':'MHT'}[metric]
  axs[0,0].text(2025.18,z.all_numeric_recorded_count.iloc[-1]/1000,short,c=col,fontsize=5.9,va='center')
 axs[0,0].set(ylabel='Recorded counts (thousands)',xlabel='December snapshot year',ylim=(0,None),xlim=(2018.7,2027.2));axs[0,0].set_xticks([2019,2021,2023,2025])
 colors={'positive':BLUE,'explicit_zero':'#E5E5E5','blank_cell':'#D09A39','absent_row':'#6A6A6A'};hatches={'positive':'','explicit_zero':'..','blank_cell':'///','absent_row':'xx'};labs={'positive':'Positive','explicit_zero':'Explicit zero','blank_cell':'Blank cell','absent_row':'Absent row'}
 ss=status[(status.metric=='mht')&(status.universe=='Positive FONASA denominator')].pivot(index='year',columns='status',values='facilities').fillna(0);bottom=np.zeros(len(ss))
 for k in colors:
  vals=ss.get(k,pd.Series(0,index=ss.index));axs[0,1].bar(ss.index,vals,bottom=bottom,color=colors[k],hatch=hatches[k],label=labs[k],edgecolor='white',linewidth=.2);bottom+=vals
 axs[0,1].set(ylabel='Facilities with positive estimated enrolment',xlabel='Year');axs[0,1].set_xticks([2019,2021,2023,2025]);axs[0,1].legend(fontsize=5.5,loc='center left',bbox_to_anchor=(1.01,.5))
 measure=['mrs_entry','mrs_followup','mrs_improved_low'];q=new[new.age_scope.eq('45-64')].set_index('metric').loc[measure]
 axs[1,0].barh(np.arange(3),q.recorded_count/1000,color=[BLUE,TEAL,PURPLE]);axs[1,0].set_yticks(np.arange(3),[LABELS[m] for m in measure],fontsize=6.6);axs[1,0].invert_yaxis();axs[1,0].set(xlabel='Separate histories at age 45–64 (thousands)',xlim=(0,110))
 for i,val in enumerate(q.recorded_count):axs[1,0].text(val/1000+1,i,f'{val:,.0f}',va='center',fontsize=7)
 bottom=np.zeros(3)
 for k in colors:
  vals=[]
  for m in measure:
   zz=status[(status.year==2025)&(status.metric==m)&(status.universe=='Positive FONASA denominator')&(status.status==k)];vals.append(zz.facilities.sum())
  axs[1,1].barh(np.arange(3),vals,left=bottom,color=colors[k],hatch=hatches[k],edgecolor='white',linewidth=.2);bottom+=vals
 axs[1,1].set_yticks(np.arange(3),['Entry MRS','Follow-up MRS','Improved/low MRS'],fontsize=6.7);axs[1,1].invert_yaxis();axs[1,1].set(xlabel='Enrolled facilities in 2025')
 cap='December source recording and new P1 history fields. A: deduplicated P1 counts at ages 45–64, 2019–2025, using Col02 in 2025 and Col01 earlier. Exact duplicate removal changes the frozen 2021 totals by 53 care, 10 assessed, five high-MRS and two MHT records. B: MHT source status among facilities with positive same-year estimated female enrolment at ages 45–64; explicit zero, blank cell and absent row remain separate. C: new 2025 entry-MRS, follow-up-MRS and improved/low follow-up fields. These overlapping assessment histories are not a disjoint cascade or treatment-response comparison. D: visibility of those fields among the 2025 enrolled facilities. Blank or absent observations cannot identify women who did not receive care. Enrolment derives from FONASA age bands apportioned using municipal INE female age structure; missing age shares remain missing. Counts can repeat women across snapshots and do not establish access, need or effectiveness. Sources: annual DEIS REM coded templates, original Series P files, FONASA and INE.'
 figures.append(export(fig,'Figure_REM2_recording_visibility',cap,'Four panels show core recorded caseload, separate source-status categories, new 2025 assessment histories and their reporting visibility. Missing rows are retained as missing rather than zero.'))
 # Figure3: updated maps retain all denominator-eligible facilities and visibly separate missingness.
 geo=wide[wide.year.eq(2025)&wide.estimated_enrolled_women_45_64.gt(0)&wide.lat.between(-56.5,-17)&wide.lon.between(-76,-66)].copy()
 reg=style.rings(style.GEO/'regions.geojson');com=style.rings(style.GEO/'comunas_rm.geojson')
 fig,axs=plt.subplots(2,2,figsize=(180/25.4,205/25.4),gridspec_kw={'height_ratios':[2.3,1]},layout='constrained')
 for col,(metric,scale,title,vmin,vmax) in enumerate([('care',100,'Care records /100',.1,100),('mht',1000,'MHT records /1,000',.1,1000)]):
  geo[metric+'_map_rate']=scale*geo[metric]/geo.estimated_enrolled_women_45_64
  for row in range(2):
   ax=axs[row,col];style.map_base(ax,reg,com,zoom=row==1)
   missing=geo[geo[metric+'_status'].eq('absent_row')];blank=geo[geo[metric+'_status'].eq('blank_cell')];zero=geo[geo[metric+'_status'].eq('explicit_zero')];positive=geo[geo[metric+'_status'].eq('positive')]
   ax.scatter(missing.lon,missing.lat,c='#9A9A9A',marker='x',s=5 if row==0 else 15,linewidths=.4,zorder=2)
   ax.scatter(blank.lon,blank.lat,c='#B47818',marker='+',s=9 if row==0 else 22,linewidths=.65,zorder=4)
   ax.scatter(zero.lon,zero.lat,facecolors='white',edgecolors='black',marker='s',s=10 if row==0 else 26,linewidths=.6,zorder=5)
   im=ax.scatter(positive.lon,positive.lat,c=positive[metric+'_map_rate'],cmap='viridis',norm=LogNorm(vmin,vmax),s=7 if row==0 else 19,edgecolors='black',linewidths=.12,alpha=.85,zorder=3)
   ax.set_title('ABCD'[row*2+col]+'  '+(title if row==0 else 'Santiago enlargement'),loc='left',fontsize=8,fontweight='bold')
  cb=fig.colorbar(im,ax=axs[:,col],orientation='horizontal',shrink=.9,pad=.025,extend='both');cb.ax.tick_params(labelsize=6);cb.set_label(title+' estimated enrolled, log scale',fontsize=6.7)
 fig.legend(handles=[Line2D([],[],marker='x',ls='',c='#777',label='Absent source row'),Line2D([],[],marker='+',ls='',c='#B47818',label='Blank age cell'),Line2D([],[],marker='s',ls='',mfc='white',mec='black',label='Explicit zero')],loc='outside lower center',ncol=3,fontsize=6.5,frameon=False)
 save(geo,'map_2025_facility_values.csv')
 cap=f'Facility geography of recorded menopause care and source visibility in 2025. A–B: December care records per 100 and MHT records per 1,000 estimated enrolled women aged 45–64. C–D: Santiago enlargements with the same respective scales. The mapped universe contains {len(geo):,} facilities with positive same-year age-specific enrolment and usable mainland catalogue coordinates, including facilities without a source row. Coloured circles indicate positive numeric values, open squares explicit zeros, plus signs blank age cells in represented rows, and grey crosses absent rows. No unobserved value is set to zero. Positive colour scales are logarithmic; observations beyond their limits use the end colours. Differences can reflect care, reporting, provider selection, age-denominator estimation and geography, rather than measured access or underdiagnosis. Catalogue locations identify facilities, not residence or travel time. WGS84 coordinates, latitude-adjusted aspect ratios and approximate 250 km/10 km scale bars are used. Oceanic and Antarctic territories are omitted. Sources: DEIS REM, FONASA, INE and the public facility catalogue; boundaries from Biblioteca del Congreso Nacional de Chile, Mapoteca.'
 figures.append(export(fig,'Figure_REM3_geography_source_status',cap,'National and Santiago facility maps show positive care and MHT recording rates while distinguishing absent source rows, blank cells and explicit zeros.'))
 (OUT/'figure_manifest.json').write_text(json.dumps(figures,indent=2,ensure_ascii=False))
 print(json.dumps({'figures':len(figures),'map_facilities':len(geo),'tables_created':len(list(OUT.glob('table_*_en.csv')))},indent=2))
 return figures
if __name__=='__main__':build()
