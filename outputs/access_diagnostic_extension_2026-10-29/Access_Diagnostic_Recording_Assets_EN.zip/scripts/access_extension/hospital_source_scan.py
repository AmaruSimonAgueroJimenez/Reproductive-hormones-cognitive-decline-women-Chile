#!/usr/bin/env python3
"""Aggregate DEIS discharges and full GRD for the menopause-recording extension.

Only aggregate tables enter the project. Episode/person intermediates are written
exclusively to the mounted external-volume hospital directory. Existing pipelines
and trusted outputs are never mutated. Run --refresh-source to scan raw files.
"""
from pathlib import Path
import argparse,json,hashlib,platform,sys,time,re
import numpy as np
import polars as pl
import pyarrow as pa
import pyarrow.csv as pacsv
import pandas as pd
ROOT=Path(__file__).resolve().parents[2]
DATA=Path('/Volumes/Datos/Asesorias_Data')
DER=DATA/'derived/Reproductive-hormones-cognitive-decline-women-Chile'
PRIVATE=DER/'access_extension/hospital'
OUT=ROOT/'outputs/access_diagnostic_extension_2026-10-29/hospital'
GROUPS={
 'climacteric_n951':['N951'],
 'menopausal_disorders':['N951','N958','N959'],
 'artificial_menopause':['N953'],
 'primary_ovarian_failure':['E283'],
 'postprocedural_ovarian_failure':['E894'],
 'genital_absence_status':['Z907'],
 'menopause_clinical_composite':['N951','N958','N959','N953','E283','E894'],
 'postmenopausal_bleeding':['N950'],
 'postmenopausal_atrophic_vaginitis':['N952'],
 'dementia':['F00','F01','F02','F03','G30','G310','G311','G318'],
 'parkinsonism':['G20','G21','G22','G23'],
 'neurodegenerative_any':['F00','F01','F02','F03','G30','G31','G10','G11','G12','G13','G14','G20','G21','G22','G23','G24','G25','G26']}
CLINICAL=list(GROUPS)[:7]
EXACT_GROUPS=set(list(GROUPS)[:9])
INVALID_ID=['','0','-1','NA','NAN','NULL','DESCONOCIDO','SIN INFORMACION','SIN INFORMACIÓN']

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def source_record(p,kind,year):
 return dict(path=str(p),kind=kind,year=year,bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns,sha256=sha(p))
def code(col):return pl.col(col).fill_null('').str.to_uppercase().str.replace_all(r'[^A-Z0-9]','')
def sex(col):
 x=pl.col(col).fill_null('').str.strip_chars().str.to_uppercase()
 return pl.when(x.is_in(['2','2.0','MUJER','MUJERES','F','FEMENINO'])).then(pl.lit('Women')).when(x.is_in(['1','1.0','HOMBRE','HOMBRES','H','MASCULINO'])).then(pl.lit('Men')).otherwise(pl.lit('Unknown'))
def age_band(col='age',boundary45=True):
 x=pl.col(col)
 if boundary45:
  return pl.when(x.is_null()).then(pl.lit('Unknown')).when(x<40).then(pl.lit('<40')).when(x<45).then(pl.lit('40–44')).when(x<55).then(pl.lit('45–54')).when(x<65).then(pl.lit('55–64')).when(x<75).then(pl.lit('65–74')).when(x<85).then(pl.lit('75–84')).otherwise(pl.lit('≥85'))
 return pl.when(x.is_null()).then(pl.lit('Unknown')).when(x<40).then(pl.lit('<40')).when(x<50).then(pl.lit('40–49')).when(x<60).then(pl.lit('50–59')).when(x<70).then(pl.lit('60–69')).when(x<80).then(pl.lit('70–79')).otherwise(pl.lit('≥80'))
def read_selected(p,cols,sep,encoding):
 return pl.from_arrow(pacsv.read_csv(p,read_options=pacsv.ReadOptions(encoding=encoding,use_threads=True),parse_options=pacsv.ParseOptions(delimiter=sep),convert_options=pacsv.ConvertOptions(include_columns=cols,column_types={k:pa.string() for k in cols},strings_can_be_null=True)))
def header(p,sep,encoding):
 with p.open(encoding=encoding) as f:return f.readline().rstrip('\r\n').split(sep)
def save(d,name):
 if isinstance(d,pl.DataFrame):d.write_csv(OUT/name)
 else:d.to_csv(OUT/name,index=False)
def counts(d,cols):return d.group_by(cols).len().sort(cols)
def flags(d,principal,joined=None):
 expr=[]
 for g,cc in GROUPS.items():
  rx='^(?:'+'|'.join(cc)+')'+('$' if g in EXACT_GROUPS else '')
  expr.append(pl.col(principal).str.contains(rx).cast(pl.Int64).alias(g+'_principal'))
  if joined:expr.append(pl.col(joined).str.contains(r'\|(?:'+'|'.join(cc)+')'+(r'\|' if g in EXACT_GROUPS else '')).cast(pl.Int64).alias(g+'_any'))
 return d.with_columns(expr)
def summary_flags(d,by,suffixes):
 v=[g+'_'+s for g in GROUPS for s in suffixes]
 return d.group_by(by).agg(pl.len().alias('denominator'),*[pl.col(c).sum().alias(c) for c in v]).sort(by)

def scan_deis(years):
 agg=[];qc=[];domains=[];sources=[];detailed=[];sexcode=[]
 for y in years:
  t=time.time();p=DATA/'DEIS/Egresos'/f'{y}.csv'
  if not p.exists():p=DATA/'DEIS/egresos'/f'{y}.csv'
  hdr=header(p,';','latin1');sector=next(c for c in hdr if c.startswith('PERTENENCIA'))
  cols=[sector,'SEXO','GRUPO_EDAD','REGION_RESIDENCIA','COMUNA_RESIDENCIA','PREVISION','DIAG1','CONDICION_EGRESO','ANO_EGRESO']
  d=read_selected(p,cols,';','latin1').rename({sector:'sector_raw','SEXO':'sex_raw','GRUPO_EDAD':'age_raw','REGION_RESIDENCIA':'region_raw','COMUNA_RESIDENCIA':'municipality_raw','PREVISION':'insurance_raw','DIAG1':'dx1','CONDICION_EGRESO':'discharge_raw','ANO_EGRESO':'record_year'})
  d=d.with_columns(sex('sex_raw').alias('sex'),code('dx1').alias('dx1'),pl.lit(y).alias('year'))
  age=pl.col('age_raw').fill_null('').str.to_uppercase()
  lo=age.str.extract(r'(\d+)',1).cast(pl.Float64,strict=False)
  lo=pl.when(age.str.contains('MENOR|DIAS|DÍAS|MES')).then(0).otherwise(lo)
  sec=pl.col('sector_raw').fill_null('').str.to_uppercase().str.strip_chars()
  d=d.with_columns(lo.alias('age_lower'),pl.when(sec.str.starts_with('PERTENECIENTE')).then(pl.lit('SNSS')).when(sec.str.starts_with('NO PERTENECIENTE')).then(pl.lit('Non-SNSS')).otherwise(pl.lit('Unknown')).alias('sector'),pl.col('region_raw').fill_null('Unknown').str.strip_chars().replace('', 'Unknown').alias('region'))
  d=d.with_columns(age_band('age_lower',False).alias('age_band'))
  q={'source':'DEIS','year':y,'all_records':len(d),'women':d.filter(pl.col('sex')=='Women').height,'men':d.filter(pl.col('sex')=='Men').height,'sex_unknown':d.filter(pl.col('sex')=='Unknown').height,'age_unclassified':d.filter(pl.col('age_band')=='Unknown').height,'principal_code_missing':d.filter(pl.col('dx1')=='').height,'year_mismatch':d.filter(pl.col('record_year').cast(pl.Int64,strict=False)!=y).height}
  qc.append(q)
  for name in ['sex_raw','age_raw','sector_raw','discharge_raw','insurance_raw']:
   dom=counts(d,[name]).rename({name:'category','len':'n'}).with_columns(pl.lit(name).alias('field'),pl.lit(y).alias('year'),pl.lit('DEIS').alias('source'));domains.append(dom.select(['source','year','field','category','n']))
  allflags=flags(d,'dx1')
  sexcode.append(summary_flags(allflags,['year','sex'],['principal']))
  w=allflags.filter(pl.col('sex')=='Women')
  agg.append(summary_flags(w,['year','age_band','sector'],['principal']))
  detailed.append(summary_flags(w,['year','region','sector'],['principal']))
  n95=w.filter(pl.col('dx1').str.starts_with('N95')).group_by('dx1').len().with_columns(pl.lit(y).alias('year'));save(n95,f'deis_n95_subcodes_{y}.csv')
  sources.append(source_record(p,'DEIS national principal-diagnosis discharges',y))
  print(f'DEIS {y}: {len(d):,} records, {len(w):,} women; {time.time()-t:.1f}s',flush=True)
 save(pl.concat(agg),'deis_female_age_sector.csv');save(pl.concat(detailed),'deis_female_region_sector.csv');save(pd.DataFrame(qc),'deis_source_qc.csv');save(pl.concat(domains),'deis_field_domains.csv');save(pl.concat(sexcode),'deis_principal_by_recorded_sex.csv')
 return sources

def scan_grd(years):
 sources=[];annual=[];ageparts=[];hospital=[];qcs=[];domains=[];checks=[];codeds=[];tokens=[]
 PRIVATE.mkdir(parents=True,exist_ok=True)
 for y in years:
  t=time.time();p=DATA/'GRD'/f'GRD_PUBLICO_{y}.csv';hdr=header(p,'|','utf8');idc='ID_BENEFICIARIO' if 'ID_BENEFICIARIO' in hdr else 'CIP_ENCRIPTADO'
  dx=sorted([c for c in hdr if re.fullmatch(r'DIAGNOSTICO\d+',c)],key=lambda c:int(c[11:]))
  base=[idc,'SEXO','FECHA_NACIMIENTO','FECHA_INGRESO','FECHAALTA','TIPOALTA','TIPO_ACTIVIDAD','COD_HOSPITAL']
  d=read_selected(p,base+dx,'|','utf8')
  birth=pl.coalesce(pl.col('FECHA_NACIMIENTO').str.strptime(pl.Date,'%Y-%m-%d',strict=False),pl.col('FECHA_NACIMIENTO').str.strptime(pl.Date,'%d-%m-%Y',strict=False))
  din=pl.coalesce(pl.col('FECHA_INGRESO').str.strptime(pl.Date,'%Y-%m-%d',strict=False),pl.col('FECHA_INGRESO').str.strptime(pl.Date,'%d-%m-%Y',strict=False))
  norm=[code(c) for c in dx]
  joined=pl.concat_str([pl.lit('|'),pl.concat_str(norm,separator='|'),pl.lit('|')],separator='')
  ident=pl.col(idc).fill_null('').str.strip_chars()
  d=d.with_columns(sex('SEXO').alias('sex'),((din-birth).dt.total_days()/365.25).alias('age'),din.alias('date_in'),pl.lit(y).alias('year'),joined.alias('dx'),code(dx[0]).alias('dx1'),pl.sum_horizontal([(x!='').cast(pl.Int16) for x in norm]).alias('n_dx'),pl.when(ident.str.to_uppercase().is_in(INVALID_ID)).then(pl.lit('')).otherwise(ident).alias('id'),pl.col('COD_HOSPITAL').fill_null('').str.strip_chars().alias('hospital'))
  act=pl.col('TIPO_ACTIVIDAD').fill_null('').str.to_uppercase().str.strip_chars()
  d=d.with_columns(age_band().alias('age_band'),pl.when(act.str.starts_with('HOSP')).then(pl.lit('Hospital stay')).when(act.str.contains('AMBUL|CMA')).then(pl.lit('Major ambulatory surgery')).otherwise(pl.lit('Other or missing')).alias('activity'))
  q={'source':'GRD','year':y,'all_records':len(d),'women':d.filter(pl.col('sex')=='Women').height,'men':d.filter(pl.col('sex')=='Men').height,'sex_unknown':d.filter(pl.col('sex')=='Unknown').height,'age_missing':d.filter(pl.col('age').is_null()).height,'female_age_missing':d.filter((pl.col('sex')=='Women')&pl.col('age').is_null()).height,'female_age_negative':d.filter((pl.col('sex')=='Women')&(pl.col('age')<0)).height,'female_age_over110':d.filter((pl.col('sex')=='Women')&(pl.col('age')>110)).height,'id_missing_all':d.filter(pl.col('id')=='').height,'identifier_column':idc,'diagnostic_positions':len(dx)}
  for name in ['SEXO','TIPO_ACTIVIDAD','TIPOALTA']:
   dom=counts(d,[name]).rename({name:'category','len':'n'}).with_columns(pl.lit(name).alias('field'),pl.lit(y).alias('year'),pl.lit('GRD').alias('source'));domains.append(dom.select(['source','year','field','category','n']))
  d=flags(d,'dx1','dx')
  candidate=d.filter(pl.col('dx').str.contains(r'\|(?:N95|E283|E894|Z907)')).select(dx).unpivot().with_columns(code('value').alias('code')).filter(pl.col('code').str.contains(r'^(?:N95|E283|E894|Z907)')).group_by('code').len().with_columns(pl.lit(y).alias('year'));tokens.append(candidate)
  # Private cache includes ALL sex-coded eligible episodes, allowing sex-discordance checks.
  keep=['id','year','sex','age','date_in','hospital','activity','n_dx','TIPOALTA','dx1']+[g+'_'+s for g in GROUPS for s in ['principal','any']]
  eligible=d.filter(pl.col('age')>=45)
  eligible.select(keep).write_parquet(PRIVATE/f'grd_episode_flags_{y}.parquet',compression='zstd')
  w=d.filter(pl.col('sex')=='Women');main=w.filter(pl.col('age')>=45)
  q.update(female_45plus=len(main),female_45plus_id_missing=main.filter(pl.col('id')=='').height)
  qcs.append(q)
  annual.append(summary_flags(main,['year'],['principal','any']))
  ageparts.append(summary_flags(w,['year','age_band','activity'],['principal','any']))
  hospital.append(summary_flags(main,['year','hospital'],['principal','any']))
  # Aggregate diagnostic-depth/case-recording cells, never identifiers.
  main=main.with_columns(pl.when(pl.col('n_dx')==1).then(pl.lit('1')).when(pl.col('n_dx')<=3).then(pl.lit('2–3')).when(pl.col('n_dx')<=6).then(pl.lit('4–6')).otherwise(pl.lit('≥7')).alias('coding_depth'))
  codeds.append(summary_flags(main,['year','age_band','coding_depth','activity'],['principal','any']))
  oldpath=DER/'grd_dx'/f'grd_dx_{y}.parquet'
  old=pd.read_parquet(oldpath,columns=['sex','dx1','dx','id']);ow=old[old.sex.eq('Mujer')]
  ck={'year':y,'raw_all_45plus':len(eligible),'mf19_all_45plus':len(old),'raw_female_45plus':len(main),'mf19_female_45plus':len(ow)}
  assert len(eligible)==len(old) and len(main)==len(ow),(y,ck)
  for g,codes in GROUPS.items():
   n=int(ow.dx.str.contains(r'\|(?:'+'|'.join(codes)+')'+(r'\|' if g in EXACT_GROUPS else ''),regex=True,na=False).sum());n2=int(main[g+'_any'].sum());assert n==n2,(y,g,n,n2);ck[g+'_any_match']=True
  checks.append(ck)
  sources.extend([source_record(p,'Full GRD episode file',y),source_record(oldpath,'Existing mf19 all-sex age45+ diagnoses, independent count reconciliation',y)])
  print(f'GRD {y}: {len(d):,} episodes; {len(main):,} women45+; mf19 reconciliation passed; {time.time()-t:.1f}s',flush=True)
 save(pl.concat(annual),'grd_female_45plus_year.csv');save(pl.concat(ageparts),'grd_female_allage_activity.csv');save(pl.concat(codeds),'grd_female_coding_depth.csv');save(pd.DataFrame(qcs),'grd_source_qc.csv');save(pl.concat(domains),'grd_field_domains.csv');save(pd.DataFrame(checks),'grd_mf19_reconciliation.csv');save(pl.concat(tokens),'grd_candidate_code_token_occurrences.csv')
 # Hospital identifiers describe institutions, not people. Retain their aggregate source file privately.
 pl.concat(hospital).write_parquet(PRIVATE/'grd_hospital_year_counts.parquet')
 return sources

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--refresh-source',action='store_true');p.add_argument('--deis-years',default='2001-2024');p.add_argument('--grd-years',default='2019-2024');a=p.parse_args()
 if not a.refresh_source:raise SystemExit('No scan performed. Supply --refresh-source for authorized external-volume reads.')
 if not DATA.is_dir():raise SystemExit('External source volume is unavailable; no result regenerated.')
 OUT.mkdir(parents=True,exist_ok=True)
 parse=lambda s:list(range(int(s.split('-')[0]),int(s.split('-')[-1])+1))
 sources=scan_deis(parse(a.deis_years))+scan_grd(parse(a.grd_years))
 manifest={'created_at':pd.Timestamp.now(tz='UTC').isoformat(),'sources':sources,'private_intermediates':str(PRIVATE),'script':str(Path(__file__).relative_to(ROOT)),'script_sha256':sha(Path(__file__)),'python':sys.version,'polars':pl.__version__,'pandas':pd.__version__,'pyarrow':pa.__version__,'groups':GROUPS,'scope':'DEIS national principal diagnoses at source-supported age bands; GRD women45+ primary and other age bands descriptive context; no medication history.'}
 (OUT/'hospital_source_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 print('Source scan complete; only aggregates were written to the repository.',flush=True)
if __name__=='__main__':main()
