"""Exploratory facility recording associations, using audited REM counts only.

Public aggregate inputs; no individual records. Rules are documented in
config/access_recording_extension_2026_10_29.yaml before model estimation.
"""
from pathlib import Path
import json, hashlib, platform, sys
import numpy as np
import pandas as pd
import scipy
from scipy import stats
import statsmodels.api as sm
import patsy
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, FuncFormatter, NullLocator

ROOT=Path(__file__).resolve().parents[2]
BASE=ROOT/'outputs/access_diagnostic_extension_2026-10-29'
OUT=BASE/'association';OUT.mkdir(parents=True,exist_ok=True)
YEARS=range(2022,2026)
COLORS={'Women':'#0072B2','Men':'#D55E00'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':7.5,'axes.labelsize':7.5,
 'axes.titlesize':8,'axes.spines.top':False,'axes.spines.right':False,
 'xtick.labelsize':6.5,'ytick.labelsize':6.5,'pdf.fonttype':42,'ps.fonttype':42,
 'svg.fonttype':'none','savefig.facecolor':'white'})

def save(df,name):
 df.to_csv(OUT/name,index=False)

def export(fig,name,caption,alt):
 for ext in ['png','svg','pdf']:fig.savefig(OUT/(name+'.'+ext),dpi=600)
 plt.close(fig)
 return {'path':str((OUT/(name+'.png')).relative_to(ROOT)),'caption':caption,'alt':alt}

def exposure(raw,min_years):
 a=raw[raw.year.between(2019,2021)].copy()
 a['valid']=a.estimated_enrolled_women_45_64.gt(0)&a.mht_status.isin(['positive','explicit_zero'])&a.care_status.isin(['positive','explicit_zero'])
 a['annual_numerator_flag']=a.mht.gt(a.estimated_enrolled_women_45_64)|a.care.gt(a.estimated_enrolled_women_45_64)
 v=a[a.valid].groupby('estab').agg(any_year_numerator_flag=('annual_numerator_flag','any'),exposure_years=('year','nunique'),mht=('mht','sum'),care=('care','sum'),exposure_enrolment_sum=('estimated_enrolled_women_45_64','sum'))
 v=v[v.exposure_years.ge(min_years)].copy()
 v['mht_per1000']=1000*v.mht/v.exposure_enrolment_sum
 v['mht10']=v.mht_per1000/10
 v['care_per100']=100*v.care/v.exposure_enrolment_sum
 v['numerator_exceeds_denominator']=v.mht.gt(v.exposure_enrolment_sum)|v.care.gt(v.exposure_enrolment_sum)
 meta=raw.sort_values('year').drop_duplicates('estab',keep='last').set_index('estab')
 cols=['comuna','comuna_name','region13','type_group','poverty_multi','rural_share','lat','lon']
 return v.join(meta[cols])

def eligible(neuro,measure,sex,years):
 b=neuro[neuro.measure.eq(measure)&neuro.sex.eq(sex)&neuro.year.isin(years)&neuro.age_group.isin(['60-79','80+'])].copy()
 b=b[b.complete_identified&b.enrolled.gt(0)&b.count_complete_identified.notna()]
 keys=b.groupby(['estab','year']).age_group.nunique()
 keys=keys[keys.eq(2)].reset_index()[['estab','year']]
 return b.merge(keys,on=['estab','year'],validate='many_to_one')

def make_outcome(neuro,measure,sex,years,min_years):
 b=eligible(neuro,measure,sex,years)
 # Internal standard is all eligible reporting facilities in each source stratum,
 # before selecting on hormonal exposure. It is descriptive, not a population rate.
 ref=b.groupby(['year','age_group']).agg(reference_count=('count_complete_identified','sum'),reference_enrolled=('enrolled','sum')).reset_index()
 ref['reference_rate']=ref.reference_count/ref.reference_enrolled
 ref['measure']=measure;ref['sex']=sex
 b=b.merge(ref[['year','age_group','reference_rate']],on=['year','age_group'],validate='many_to_one')
 b['expected']=b.enrolled*b.reference_rate
 c=b.groupby('estab').agg(outcome=('count_complete_identified','sum'),expected=('expected','sum'),outcome_years=('year','nunique'),outcome_enrolment_sum=('enrolled','sum'),accounting_rows=('accounting_identified_rows','sum'),raw_numeric_rows=('raw_numeric_rows','sum'))
 c=c[c.outcome_years.ge(min_years)&c.expected.gt(0)].copy()
 e80=b[b.age_group.eq('80+')].groupby('estab').enrolled.sum()
 c['share80']=e80/c.outcome_enrolment_sum
 c['observed_expected']=c.outcome/c.expected
 c['log_size']=np.log(c.outcome_enrolment_sum/c.outcome_years)
 return c,ref

def model(frame,formula,label,measure,sex,sample):
 c=frame.copy()
 need=['outcome','expected','mht10','comuna','region13','type_group','poverty_multi','rural_share','log_size']
 if 'care_per100' in formula:need+=['care_per100']
 if 'baseline_log' in formula:need+=['baseline_log']
 c=c.dropna(subset=need)
 c['region13']=c.region13.astype(int).astype(str)
 c['poverty10']=c.poverty_multi/.1;c['rural10']=c.rural_share/.1
 if c.comuna.nunique()<30:
  return {'measure':measure,'sex':sex,'sample':sample,'model':label,'facilities':len(c),'municipal_clusters':c.comuna.nunique(),'parameters':np.nan,'matrix_rank':np.nan,'status':'not_fitted','reason':'fewer_than_30_clusters'},None,None
 y,x=patsy.dmatrices(formula,c,return_type='dataframe')
 n,p=x.shape;g=c.comuna.nunique();rank=np.linalg.matrix_rank(x)
 row={'measure':measure,'sex':sex,'sample':sample,'model':label,'facilities':n,'municipal_clusters':g,'parameters':p,'matrix_rank':rank,'status':'not_fitted'}
 if g<30 or rank<p or n<=p:
  row['reason']='fewer_than_30_clusters' if g<30 else 'rank_deficient_or_saturated'
  return row,None,None
 fitted=sm.GLM(y,x,family=sm.families.Poisson(),offset=np.log(c.expected)).fit(maxiter=200,tol=1e-10)
 if not fitted.converged:
  row['reason']='nonconvergent';return row,None,None
 mu=np.asarray(fitted.mu);xx=np.asarray(x);yy=np.asarray(y).ravel()
 bread=np.linalg.inv(xx.T@(mu[:,None]*xx))
 score=xx*(yy-mu)[:,None]
 sums=pd.DataFrame(score).groupby(np.asarray(c.comuna)).sum().to_numpy()
 correction=g/(g-1)*(n-1)/(n-p)
 covariance=bread@(sums.T@sums)@bread*correction
 # Independent library sandwich check on the same converged mean model.
 checked=sm.GLM(y,x,family=sm.families.Poisson(),offset=np.log(c.expected)).fit(maxiter=200,tol=1e-10,cov_type='cluster',cov_kwds={'groups':np.asarray(c.comuna),'use_correction':True})
 cov_error=float(np.max(np.abs(covariance-np.asarray(checked.cov_params()))))
 if cov_error>1e-6:raise AssertionError(('sandwich mismatch',cov_error))
 j=x.columns.get_loc('mht10');beta=float(fitted.params.iloc[j]);se=float(np.sqrt(covariance[j,j]));critical=stats.t.ppf(.975,g-1)
 row.update(status='fitted',beta=beta,cluster_se=se,rate_ratio=np.exp(beta),ci_low=np.exp(beta-critical*se),ci_high=np.exp(beta+critical*se),p_nominal=2*stats.t.sf(abs(beta/se),g-1),pearson_dispersion=float(np.sum((yy-mu)**2/mu)/(n-p)),outcome_records=float(c.outcome.sum()),expected_records=float(c.expected.sum()),covariance_max_abs_difference=cov_error,iterations=fitted.fit_history['iteration'],exposure_median=float(c.mht_per1000.median()),exposure_min=float(c.mht_per1000.min()),exposure_max=float(c.mht_per1000.max()))
 c['fitted']=mu;c['pearson_residual']=(yy-mu)/np.sqrt(mu)
 c['measure']=measure;c['sex']=sex;c['sample']=sample;c['model']=label
 return row,c,(fitted,x,covariance)

BASE_FORMULA='outcome ~ mht10 + C(region13) + C(type_group) + poverty10 + rural10 + log_size'

def spatial_diagnostic(c):
 # Municipal residual sums avoid assigning independent observations to providers
 # sharing the same administrative context. Geographic centroids are facility means.
 a=c.dropna(subset=['lat','lon']).groupby('comuna').agg(observed=('outcome','sum'),fitted=('fitted','sum'),lat=('lat','mean'),lon=('lon','mean'))
 a=a[a.lat.between(-56,-17)&a.lon.between(-76,-66)]
 if len(a)<10:return {'status':'too_few_municipalities'}
 z=(a.observed-a.fitted)/np.sqrt(a.fitted);z=z.to_numpy();z-=z.mean()
 rad=np.deg2rad(a[['lat','lon']].to_numpy());dlat=rad[:,0,None]-rad[None,:,0];dlon=rad[:,1,None]-rad[None,:,1]
 dist=2*6371*np.arcsin(np.minimum(1,np.sqrt(np.sin(dlat/2)**2+np.cos(rad[:,0,None])*np.cos(rad[None,:,0])*np.sin(dlon/2)**2)))
 np.fill_diagonal(dist,np.inf);w=np.zeros_like(dist)
 for i in range(len(a)):w[i,np.argsort(dist[i])[:4]]=1
 w=np.maximum(w,w.T);s=w.sum();n=len(z)
 def calc(v):return n/s*(v@w@v)/(v@v)
 obs=calc(z);rng=np.random.default_rng(20261029);perms=np.array([calc(rng.permutation(z)) for _ in range(999)])
 p=(1+np.sum(abs(perms-perms.mean())>=abs(obs-perms.mean())))/1000
 return {'status':'calculated','municipalities':n,'moran_I':float(obs),'permutation_p_two_sided':float(p),'permutations':999,'seed':20261029,'weights':'symmetrised four-nearest-neighbour graph, binary weights; great-circle distances; facility-mean municipal coordinates'}

def main():
 raw=pd.read_csv(BASE/'rem/facility_year_hormonal_care.csv')
 neuro=pd.read_csv(BASE/'neuro/neuro_facility_year.csv.gz')
 assert not raw.duplicated(['year','estab']).any()
 assert not neuro.duplicated(['year','estab','sex','age_group','measure']).any()
 rows=[];flows=[];references=[];frames={};checks=[]
 for measure in ['dementia_caseload','parkinson_caseload']:
  for sex in ['Women','Men']:
   for sample,exyrs,oyrs in [('strict',3,4),('relaxed',2,2)]:
    ex=exposure(raw,exyrs);out,ref=make_outcome(neuro,measure,sex,YEARS,oyrs);references.append(ref)
    c=ex.join(out,how='inner');c.index.name='estab'
    flows.append({'measure':measure,'sex':sex,'sample':sample,'exposure_eligible_facilities':len(ex),'outcome_eligible_facilities':len(out),'intersection_facilities':len(c),'municipalities':c.comuna.nunique(),'numerator_exceeds_denominator':int(c.numerator_exceeds_denominator.sum())})
    save(c.reset_index(),f'cohort_{measure}_{sex.lower()}_{sample}.csv')
    for label,form in [('base',BASE_FORMULA),('programme_intensity',BASE_FORMULA+' + care_per100')]:
     r,cf,fit=model(c,form,label,measure,sex,sample);rows.append(r)
     if cf is not None:frames[(measure,sex,sample,label)]=cf
    if sample=='strict':
     baseline,bref=make_outcome(neuro,measure,sex,range(2019,2022),3)
     baseline['baseline_log']=np.log1p(1000*baseline.outcome/baseline.outcome_enrolment_sum)
     cb=c.join(baseline[['baseline_log']],how='inner')
     # Same subset both before and after baseline adjustment.
     for label,form in [('baseline_subset_unadjusted',BASE_FORMULA),('baseline_adjusted',BASE_FORMULA+' + baseline_log')]:
      r,cf,fit=model(cb,form,label,measure,sex,sample);rows.append(r)
      if cf is not None:frames[(measure,sex,sample,label)]=cf
     # Exclude flagged inconsistent numerator/denominator pairs only as sensitivity.
     r,cf,fit=model(c[~c.numerator_exceeds_denominator],BASE_FORMULA,'denominator_consistent',measure,sex,sample);rows.append(r)
     if cf is not None:frames[(measure,sex,sample,'denominator_consistent')]=cf
     for label,subset in [('exclude_any_year_flag',c[~c.any_year_numerator_flag]),('raw_numeric_only',c[c.accounting_rows.eq(0)])]:
      r,cf,fit=model(subset,BASE_FORMULA,label,measure,sex,sample);rows.append(r)
      if cf is not None:frames[(measure,sex,sample,label)]=cf
 for key,c in frames.items():
  if key[2:] == ('strict','base'):
   checks.append({'measure':key[0],'sex':key[1],**spatial_diagnostic(c)})
 res=pd.DataFrame(rows)
 # Explicit secondary family: women Parkinson, men dementia, men Parkinson in
 # the strict base model. Other specifications are labelled sensitivity analyses.
 sel=res['sample'].eq('strict')&res.model.eq('base')&~(res.measure.eq('dementia_caseload')&res.sex.eq('Women'))&res.status.eq('fitted')
 res['p_holm_secondary_family']=np.nan
 res.loc[sel,'p_holm_secondary_family']=multipletests(res.loc[sel,'p_nominal'],method='holm')[1]
 save(res,'association_models.csv');save(pd.DataFrame(flows),'association_sample_flow.csv')
 save(pd.concat(references).drop_duplicates(),'internal_expected_count_reference.csv')
 (OUT/'spatial_diagnostics.json').write_text(json.dumps(checks,indent=2))
 # Sex contrast on exactly paired strict facilities; fully sex-interacted design.
 sex_contrasts=[]
 for measure in ['dementia_caseload','parkinson_caseload']:
  a=frames.get((measure,'Women','strict','base'));b=frames.get((measure,'Men','strict','base'))
  if a is None or b is None:continue
  ids=a.index.intersection(b.index)
  pair=pd.concat([a.loc[ids],b.loc[ids]])
  # Explicit split design makes the exposure coefficients separately identifiable.
  pair['female']=(pair.sex=='Women').astype(int);pair['male']=1-pair.female
  for sex in ['female','male']:
   for col in ['mht10','poverty10','rural10','log_size']:
    source=pair[col] if col in pair else pair['poverty_multi']/.1 if col=='poverty10' else pair.rural_share/.1
    pair[f'{sex}_{col}']=pair[sex]*source
  formula='outcome ~ 0 + C(sex):C(region13) + C(sex):C(type_group) + female_mht10 + male_mht10 + female_poverty10 + male_poverty10 + female_rural10 + male_rural10 + female_log_size + male_log_size'
  y,x=patsy.dmatrices(formula,pair,return_type='dataframe');n,p=x.shape;g=pair.comuna.nunique()
  rr={'measure':measure,'paired_facilities':len(ids),'municipal_clusters':g,'parameters':p,'status':'not_fitted'}
  if g>=30 and np.linalg.matrix_rank(x)==p:
   f=sm.GLM(y,x,family=sm.families.Poisson(),offset=np.log(pair.expected)).fit(maxiter=200,tol=1e-10,cov_type='cluster',cov_kwds={'groups':pair.comuna.to_numpy(),'use_correction':True})
   contrast=np.zeros(p);contrast[x.columns.get_loc('female_mht10')]=1;contrast[x.columns.get_loc('male_mht10')]=-1
   beta=float(contrast@f.params);se=float(np.sqrt(contrast@f.cov_params()@contrast));crit=stats.t.ppf(.975,g-1)
   rr.update(status='fitted',ratio_of_rate_ratios=np.exp(beta),ci_low=np.exp(beta-crit*se),ci_high=np.exp(beta+crit*se),p_nominal=2*stats.t.sf(abs(beta/se),g-1))
  else:rr['reason']='rank_or_cluster_gate'
  sex_contrasts.append(rr)
 sc=pd.DataFrame(sex_contrasts)
 if 'p_nominal' in sc:sc['p_holm_two_contrasts']=multipletests(sc.p_nominal,method='holm')[1]
 save(sc,'paired_sex_contrasts.csv')
 # Quarterly descriptions are facility strata of the exposure, without inference.
 primary=frames.get(('dementia_caseload','Women','strict','base'))
 figures=[]
 if primary is not None:
  c=primary.copy();c['exposure_quartile']=pd.qcut(c.mht_per1000,4,labels=['Q1','Q2','Q3','Q4'])
  q=c.groupby('exposure_quartile',observed=True).agg(facilities=('mht10','size'),mht_min=('mht_per1000','min'),mht_max=('mht_per1000','max'),recorded=('outcome','sum'),expected=('expected','sum'))
  q['observed_expected']=q.recorded/q.expected;save(q.reset_index(),'primary_exposure_quartiles.csv')
  fig,axs=plt.subplots(2,2,figsize=(180/25.4,160/25.4),layout='constrained')
  ax=axs[0,0];display=res[res['sample'].eq('strict')&res.model.eq('base')&res.status.eq('fitted')].copy()
  for i,r in enumerate(display.itertuples()):
   ax.errorbar(r.rate_ratio,i,xerr=[[r.rate_ratio-r.ci_low],[r.ci_high-r.rate_ratio]],fmt='o' if r.sex=='Women' else 's',color=COLORS[r.sex],capsize=2,ms=4)
  ax.axvline(1,color='#666',lw=.7,ls='--');ax.set_yticks(range(len(display)),[f'{r.sex}: '+r.measure.replace('_caseload','').capitalize()+f' (n={r.facilities})' for r in display.itertuples()]);ax.invert_yaxis();ax.set_xscale('log');ax.xaxis.set_major_locator(FixedLocator([1,1.01,1.02,1.03,1.04]));ax.xaxis.set_major_formatter(FuncFormatter(lambda v,p:f'{v:.2f}'));ax.xaxis.set_minor_locator(NullLocator());ax.set_xlabel('Adjusted recording ratio per 10 MHT\nrecords /1,000');ax.set_title('A  Strict facility comparisons',loc='left',fontweight='bold')
  ax=axs[0,1];ax.scatter(c.mht_per1000,c.observed_expected,s=11,facecolors='none',edgecolors=COLORS['Women'],lw=.6);ax.axhline(1,color='#777',lw=.7,ls='--');ax.set_xscale('symlog',linthresh=1);ax.set_yscale('symlog',linthresh=1);ax.set_xlim(0,1800);ax.set_ylim(0,180);ax.set_xticks([0,1,10,100,1000]);ax.xaxis.set_major_formatter(FuncFormatter(lambda v,p:f'{v:g}'));ax.set_yticks([0,1,10,100]);ax.yaxis.set_major_formatter(FuncFormatter(lambda v,p:f'{v:g}'));ax.set(xlabel='Earlier MHT records /1,000 women aged 45–64\nLog scale above 1; linear from 0 to 1',ylabel='Later dementia observed / expected');ax.set_title('B  Female dementia facility ratios',loc='left',fontweight='bold')
  ax=axs[1,0];ax.bar(q.index.astype(str),q.observed_expected,color=COLORS['Women'],width=.65);ax.axhline(1,color='#555',ls='--',lw=.7);ax.set(xlabel='Facility MHT recording quartile',ylabel='Pooled observed / expected');ax.set_ylim(0,max(1.15,float(q.observed_expected.max())*1.2));ax.set_title('C  Grouped exposure and caseload',loc='left',fontweight='bold')
  for i,r in enumerate(q.itertuples()):ax.text(i,r.observed_expected+.03,f'n={r.facilities}',ha='center',fontsize=6.5)
  ax=axs[1,1];ax.scatter(c.fitted,c.pearson_residual,s=12,facecolors='none',edgecolors='#333',lw=.6);ax.axhline(0,color='#777',ls='--',lw=.7);ax.set(xlabel='Fitted repeated caseload records',ylabel='Pearson residual');ax.set_title('D  Primary model residuals',loc='left',fontweight='bold')
  caption='Earlier menopausal hormone therapy recording and later neurological caseload in selected reporting facilities. A: adjusted Poisson mean-model ratios per10 additional MHT records per1,000 estimated enrolled women aged45–64 in pooled2019–2021 December snapshots; outcomes are female or male dementia and Parkinson caseload records at age60+ summed across four2022–2025 December snapshots. Points and nominal95% municipal-cluster t intervals use df=municipal clusters−1. Models include regional and facility-type indicators, contemporary municipal multidimensional poverty and rural share, and log mean older-person enrolment; offsets use source-internal sex/age/year expected counts. Sex-specific models have separately selected samples and are not formal sex contrasts. B–D: the strict female-dementia sample, showing unadjusted facility observed/expected ratios, grouped exposure-quartile ratios without sampling intervals, and primary-model Pearson residuals. Both axes in B use symmetric log scaling, linear between−1 and1, to retain the extreme denominator-inconsistent hospital and the smaller facility values together. Quartile boundaries and component counts are in the source table. Repeated stocks are not unique women, incident diagnoses or person-time. Reporting and denominator restrictions select the analysed providers; these ecological comparisons do not identify an individual MHT effect.'
  figures.append(export(fig,'Figure_ASSOC1_recording_associations',caption,'Four panels show adjusted recording associations with cluster intervals, unadjusted facility ratios, pooled quartile ratios and model residuals.'))
  fig,axs=plt.subplots(2,1,figsize=(180/25.4,190/25.4),layout='constrained')
  for ax,measure in zip(axs,['dementia_caseload','parkinson_caseload']):
   z=res[res.measure.eq(measure)&res.sex.eq('Women')&res.status.eq('fitted')].copy()
   z=z[~z.model.eq('denominator_consistent')|z.facilities.ne(z[z.model.eq('base')&z['sample'].eq('strict')].facilities.iloc[0])]
   labels=[]
   for i,r in enumerate(z.itertuples()):
    labels.append(f'{r.sample}: {r.model.replace('denominator_consistent','exclude pooled flags').replace('exclude_any_year_flag','exclude any-year flags').replace('raw_numeric_only','raw numeric only').replace('_',' ')}\n{r.facilities} facilities; {r.municipal_clusters} clusters')
    ax.errorbar(r.rate_ratio,i,xerr=[[r.rate_ratio-r.ci_low],[r.ci_high-r.rate_ratio]],fmt='o',ms=4,color=COLORS['Women'],capsize=2)
   ax.axvline(1,c='#555',ls='--',lw=.7);ax.set_xscale('log');ax.set_yticks(range(len(z)),labels);ax.invert_yaxis();ax.xaxis.set_major_locator(FixedLocator([.925,.95,.975,1,1.025,1.05,1.075,1.10]));ax.xaxis.set_major_formatter(FuncFormatter(lambda v,p:f'{v:.3f}'));ax.xaxis.set_minor_locator(NullLocator());ax.set_xlabel('Adjusted recording ratio per 10 MHT records /1,000');ax.set_title(('A  Dementia' if measure=='dementia_caseload' else 'B  Parkinson')+' in women',loc='left',fontweight='bold')
  figures.append(export(fig,'Figure_ASSOC2_sensitivities','Sensitivity of female facility recording associations to reporting selection and programme intensity. Both panels show Poisson mean-model ratios and nominal95% municipal-cluster t intervals per10 additional earlier MHT records per1,000 estimated enrolled women aged45–64. Strict samples require three exposure years and four outcome snapshots; relaxed samples require at least two years in each window and therefore represent a different selected population. Programme-intensity models additionally include earlier climacteric-care records per100 estimated enrolled women. Baseline models are displayed only when all three2019–2021 same-outcome snapshots and all covariates support a full-rank model with at least30 municipal clusters; the unadjusted baseline subset uses exactly the same facilities as the baseline-adjusted model. The source table records specifications withheld by these gates. The any-year source-flag sensitivity was added after independent audit of the initial fits and is explicitly post hoc. Raw-numeric-only models exclude exact accounting identification; female and male dementia subsets have fewer than30 municipal clusters and are withheld. Intervals do not correct for all exploratory comparisons. Changes between differently selected samples cannot be attributed solely to covariate adjustment.','Two forest panels compare female dementia and Parkinson recording models across reporting-window and adjustment sensitivities.'))
 save(pd.DataFrame([{'measure':m,'sex':s,'facilities':len(c),'municipalities':c.comuna.nunique(),'mean_abs_residual':c.pearson_residual.abs().mean()} for (m,s,sa,mo),c in frames.items() if sa=='strict' and mo=='base']),'model_diagnostics_summary.csv')
 summary={'analysis_scope':'exploratory ecological service-recording associations','python':platform.python_version(),'pandas':pd.__version__,'numpy':np.__version__,'scipy':scipy.__version__,'statsmodels':sm.__version__ if hasattr(sm,'__version__') else __import__('statsmodels').__version__,'model_specifications':len(res),'fitted':int(res.status.eq('fitted').sum()),'withheld':res[res.status.ne('fitted')].fillna('').to_dict('records'),'primary':res[(res.measure=='dementia_caseload')&(res.sex=='Women')&(res['sample']=='strict')&(res.model=='base')].fillna('').to_dict('records'),'spatial_diagnostics':checks,'input_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [BASE/'rem/facility_year_hormonal_care.csv',BASE/'neuro/neuro_facility_year.csv.gz',ROOT/'config/access_recording_extension_2026_10_29.yaml']}}
 (OUT/'association_audit.json').write_text(json.dumps(summary,indent=2))
 (OUT/'figure_manifest.json').write_text(json.dumps(figures,indent=2))
 print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
