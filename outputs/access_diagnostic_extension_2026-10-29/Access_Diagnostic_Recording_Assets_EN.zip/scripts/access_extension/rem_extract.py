"""New raw REM extraction preserving explicit zero, blank cells and absent rows.

All source-derived caches remain on the authorised external volume. The cache
includes the small neurological code set used by the parallel neurological audit.
"""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,time
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
DATA=Path(os.environ.get('ASESORIAS_DATA_ROOT','/Volumes/Datos/Asesorias_Data'))
PRIVATE=DATA/'derived/Reproductive-hormones-cognitive-decline-women-Chile/access_extension/rem'
OUT=ROOT/'outputs/access_diagnostic_extension_2026-10-29/rem'
CODES={'A':['03600180','03600190','03600210','03600220','03600230','01080090',
 '29101711','29101712','29101713','29101160','29101210','05901801','05901802','05901803'],
 'P':['P1030301','P1060040','P1060050','P1060060','P1700101','P1700102','P1700103','P1200340',
 'P6222300','P6230100','P6230200','P3140200']}
def cache(year,serie,force=False):
 PRIVATE.mkdir(parents=True,exist_ok=True);OUT.mkdir(parents=True,exist_ok=True)
 source=DATA/f'REM/Serie{serie}/Serie{serie}_{year}.csv'
 target=PRIVATE/f'raw_selected_{serie}_{year}.csv.gz';meta=target.with_suffix('.metadata.json')
 stat=source.stat();signature={'bytes':stat.st_size,'mtime_ns':stat.st_mtime_ns}
 if target.exists() and meta.exists() and not force:
  old=json.loads(meta.read_text())
  if old.get('source_signature')==signature and old.get('codes')==CODES[serie]:return old
 with source.open(encoding='latin1') as f:header=f.readline().strip().split(';')
 assert header[:7]==['Mes','IdServicio','Ano','IdEstablecimiento','CodigoPrestacion','IdRegion','IdComuna']
 assert header[7:]==[f'Col{i:02d}' for i in range(1,51)]
 pattern=r'^(?:[^;]*;){4}(?:'+'|'.join(CODES[serie])+');'
 temp=PRIVATE/f'scan_{serie}_{year}.tmp'
 with temp.open('wb') as f:
  p=subprocess.run(['rg','--text','--no-heading','--no-filename','--no-line-number',pattern,str(source)],stdout=f,stderr=subprocess.PIPE)
 assert p.returncode in [0,1],p.stderr.decode()
 if temp.stat().st_size:
  frame=pd.read_csv(temp,sep=';',header=None,names=header,dtype=str,keep_default_na=False,encoding='latin1')
 else:frame=pd.DataFrame(columns=header)
 assert frame.CodigoPrestacion.isin(CODES[serie]).all()
 frame.to_csv(target,index=False,compression='gzip');temp.unlink()
 key=header[:5]
 numeric=frame[header[7:]].apply(pd.to_numeric,errors='coerce')
 result={'year':year,'serie':serie,'source':str(source),'source_signature':signature,'codes':CODES[serie],
 'cache':str(target),'rows':len(frame),'codes_observed':sorted(frame.CodigoPrestacion.unique()),
 'months':sorted(pd.to_numeric(frame.Mes,errors='coerce').dropna().astype(int).unique().tolist()),
 'duplicate_key_rows':int(frame.duplicated(key,keep=False).sum()),
 'duplicate_full_rows':int(frame.duplicated().sum()),
 'explicit_zero_cells':int(numeric.eq(0).sum().sum()),'blank_cells':int(frame[header[7:]].eq('').sum().sum()),
 'negative_numeric_cells':int(numeric.lt(0).sum().sum()),'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
 meta.write_text(json.dumps(result,indent=2));print(f'Cached {serie} {year}: {len(frame):,} rows, zero/blank retained',flush=True)
 return result
def run(force=False):
 records=[]
 for year in range(2019,2026):
  for serie in ['P','A']:records.append(cache(year,serie,force))
 (OUT/'raw_source_audit.json').write_text(json.dumps(records,indent=2))
 print('All 14 shared raw-selected caches ready',flush=True)
 return records
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--force',action='store_true');a=p.parse_args();run(a.force)
