"""Summarise prepared neurological REM reporting and generate an English report block.

Reads the frozen canonical aggregates; does not rewrite model inputs or fit models.
"""
from __future__ import annotations

import hashlib
import json
import platform
from pathlib import Path

import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'outputs/access_diagnostic_extension_2026-10-29/neuro'
FIG = OUT / 'figures'
LABELS = {'dementia_caseload': 'Dementia caseload', 'parkinson_caseload': 'Parkinson caseload', 'dementia_entries': 'Dementia entries'}


def relative(path):
    return str(Path(path).relative_to(ROOT))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def eligibility(f):
    z = f[f.age_group.isin(['60-79', '80+'])].copy()
    z['eligible'] = z.complete_identified & z.enrolled.gt(0)
    g = z.groupby(['year', 'estab', 'sex', 'measure']).agg(n_age=('age_group', 'size'), both_ages=('eligible', 'all')).reset_index()
    g = g[g.n_age.eq(2) & g.both_ages]
    g.to_csv(OUT / 'neuro_both_age_bands_eligible_facility_year.csv', index=False)
    q = g[g.year.between(2022, 2025)].groupby(['estab', 'sex', 'measure']).year.nunique().rename('identified_years').reset_index()
    q.to_csv(OUT / 'neuro_both_age_bands_2022_2025_coverage.csv', index=False)
    yearly = g.groupby(['year', 'measure', 'sex']).size().rename('facilities').reset_index()
    grid = pd.MultiIndex.from_product([range(2019, 2026), list(LABELS), ['Women', 'Men']], names=['year', 'measure', 'sex']).to_frame(index=False)
    yearly = grid.merge(yearly, on=['year', 'measure', 'sex'], how='left').fillna({'facilities': 0})
    yearly['facilities'] = yearly.facilities.astype(int)
    tab = yearly.assign(outcome_sex=lambda d: d.measure.map(LABELS) + ' — ' + d.sex).pivot(index='year', columns='outcome_sex', values='facilities').reset_index()
    tab.columns.name = None
    tab.to_csv(OUT / 'neuro_table_1_annual_eligibility.csv', index=False)
    records = []
    for measure in LABELS:
        for sex in ['Women', 'Men']:
            x = q[q.measure.eq(measure) & q.sex.eq(sex)]
            records.append({'Outcome': LABELS[measure], 'Sex': sex, 'At least 3 identified years': int(x.identified_years.ge(3).sum()), 'All 4 identified years': int(x.identified_years.eq(4).sum())})
    period = pd.DataFrame(records)
    period.to_csv(OUT / 'neuro_table_2_period_eligibility.csv', index=False)
    return yearly, period


def clinical_panels(f, stage):
    """Describe caseload only in the same eligible establishments in both sexes."""
    z = f[f.measure.isin(['dementia_caseload', 'parkinson_caseload']) & f.age_group.isin(['60-79', '80+'])].copy()
    z = z[z.complete_identified & z.enrolled.gt(0)]
    keys = ['year', 'measure', 'estab']
    paired = z.groupby(keys).size().rename('cells').reset_index()
    paired = paired[paired.cells.eq(4)][keys]
    cells = z.merge(paired, on=keys, validate='many_to_one')
    rates = cells.groupby(['year', 'measure', 'sex', 'age_group']).agg(
        providers=('estab', 'nunique'), records=('count_complete_identified', 'sum'), enrolled=('enrolled', 'sum')).reset_index()
    rates['records_per_1000_enrolled'] = 1000 * rates.records / rates.enrolled
    rates.to_csv(OUT / 'neuro_figure_2_selected_registration.csv', index=False)
    pivot = rates.pivot(index=['year', 'measure', 'age_group'], columns='sex', values='records_per_1000_enrolled').reset_index()
    pivot['female_male_recording_ratio'] = pivot.Women / pivot.Men.where(pivot.Men.gt(0))
    pivot.to_csv(OUT / 'neuro_figure_2_sex_ratios.csv', index=False)
    target = stage[stage.measure.eq('dementia_caseload') & stage.age_group.eq('60+') & stage.complete_identified].merge(
        paired[paired.measure.eq('dementia_caseload')][['year', 'estab']], on=['year', 'estab'], validate='many_to_one')
    composition = target.groupby(['year', 'sex', 'stage']).agg(providers=('estab', 'nunique'), records=('count_complete_identified', 'sum')).reset_index()
    composition['caseload_all_stages'] = composition.groupby(['year', 'sex']).records.transform('sum')
    composition['percentage'] = 100 * composition.records / composition.caseload_all_stages
    composition.to_csv(OUT / 'neuro_figure_2_stage_composition.csv', index=False)
    # Independent identity: the three stage counts must recover the selected
    # age60+ caseload obtained by adding the two disjoint older-age bands.
    check_a = cells[cells.measure.eq('dementia_caseload')].groupby(['year', 'sex']).count_complete_identified.sum()
    check_b = composition.groupby(['year', 'sex']).records.sum()
    assert np.allclose(check_a.sort_index(), check_b.sort_index(), rtol=0, atol=0)
    rows = []
    for (year, measure), g in rates.groupby(['year', 'measure']):
        ratio = pivot[pivot.year.eq(year) & pivot.measure.eq(measure)].set_index('age_group')
        totals = g.groupby('sex')[['records', 'enrolled']].sum()
        rows.append({'Year': int(year), 'Outcome': LABELS[measure], 'Paired establishments': int(g.providers.iloc[0]),
                     'Women recorded caseload': int(totals.loc['Women', 'records']), 'Men recorded caseload': int(totals.loc['Men', 'records']),
                     'Women records per 1000 enrolled age ≥60': round(1000 * totals.loc['Women', 'records'] / totals.loc['Women', 'enrolled'], 2),
                     'Men records per 1000 enrolled age ≥60': round(1000 * totals.loc['Men', 'records'] / totals.loc['Men', 'enrolled'], 2),
                     'Female/male ratio age 60–79': round(ratio.loc['60-79', 'female_male_recording_ratio'], 3),
                     'Female/male ratio age ≥80': round(ratio.loc['80+', 'female_male_recording_ratio'], 3)})
    pd.DataFrame(rows).to_csv(OUT / 'neuro_table_4_selected_caseload.csv', index=False)
    late = composition[composition.year.between(2022, 2025)]
    tab5 = late.groupby(['sex', 'stage']).agg(establishment_snapshots=('providers', 'sum'), recorded_caseload=('records', 'sum')).reset_index()
    tab5['percentage_of_same_sex_staged_caseload'] = 100 * tab5.recorded_caseload / tab5.groupby('sex').recorded_caseload.transform('sum')
    tab5['percentage_of_same_sex_staged_caseload'] = tab5.percentage_of_same_sex_staged_caseload.round(2)
    tab5['stage'] = pd.Categorical(tab5.stage, categories=['mild', 'moderate', 'advanced'], ordered=True)
    tab5 = tab5.sort_values(['sex', 'stage'])
    tab5.columns = ['Sex', 'Recorded stage', 'Establishment snapshots 2022-2025', 'Recorded caseload snapshots', 'Percentage of same-sex staged caseload']
    tab5.to_csv(OUT / 'neuro_table_5_stage_composition.csv', index=False)
    with mpl.rc_context({'font.family': 'DejaVu Sans', 'font.size': 7.5, 'axes.titlesize': 8.1, 'axes.labelsize': 7.6,
                         'legend.fontsize': 6.3, 'xtick.labelsize': 6.5, 'ytick.labelsize': 7,
                         'axes.spines.top': False, 'axes.spines.right': False, 'pdf.fonttype': 42, 'svg.fonttype': 'none'}):
        fig, axes = plt.subplots(2, 2, figsize=(170 / 25.4, 160 / 25.4), layout='constrained')
        for ax, measure, letter in [(axes[0, 0], 'dementia_caseload', 'A'), (axes[0, 1], 'parkinson_caseload', 'B')]:
            zz = rates[rates.measure.eq(measure)]
            for sex, color, marker in [('Women', '#0072B2', 'o'), ('Men', '#D55E00', 's')]:
                for band, ls in [('60-79', '-'), ('80+', '--')]:
                    v = zz[zz.sex.eq(sex) & zz.age_group.eq(band)]
                    ax.plot(v.year, v.records, color=color, marker=marker, ls=ls, lw=1.1, ms=3, label=f'{sex}, {band}')
            nn = zz.groupby('year').providers.first()
            ax.set_xticks(nn.index, [f'{y}\nn={n}' for y, n in nn.items()], rotation=45, ha='right')
            ax.set(title=f'{letter}  '+LABELS[measure], ylabel='Identified caseload records', ylim=(0, zz.records.max() * 1.35))
            ax.legend(loc='upper left', ncol=2, frameon=False, handlelength=1.5, columnspacing=.8)
        ax = axes[1, 0]
        for measure, color in [('dementia_caseload', '#009E73'), ('parkinson_caseload', '#CC79A7')]:
            for band, ls, marker in [('60-79', '-', 'o'), ('80+', '--', '^')]:
                v = pivot[pivot.measure.eq(measure) & pivot.age_group.eq(band)]
                ax.plot(v.year, v.female_male_recording_ratio, color=color, ls=ls, marker=marker, ms=3, lw=1.1,
                        label=f'{"Dementia" if measure=="dementia_caseload" else "Parkinson"}, {band}')
        ax.axhline(1, color='#555555', ls=':', lw=.8)
        ax.set(title='C  Female/male enrolment-based ratios', ylabel='Ratio of recorded caseload per enrolled', ylim=(0, pivot.female_male_recording_ratio.max() * 1.35))
        ax.legend(loc='upper left', ncol=2, frameon=False, handlelength=1.5, columnspacing=.7)
        ax.set_xticks(range(2019, 2026), [str(y) for y in range(2019, 2026)], rotation=45)
        ax = axes[1, 1]
        colors = {'mild': '#56B4E9', 'moderate': '#E69F00', 'advanced': '#009E73'}
        for sex, shift, hatch in [('Women', -.19, ''), ('Men', .19, '//')]:
            bottom = np.zeros(7)
            for stage_name, color in colors.items():
                v = composition[composition.sex.eq(sex) & composition.stage.eq(stage_name)].set_index('year').percentage.reindex(range(2019, 2026))
                ax.bar(np.arange(7) + shift, v, bottom=bottom, width=.36, color=color, hatch=hatch, edgecolor='white', linewidth=.3,
                       label=stage_name.capitalize() if sex == 'Women' else None)
                bottom += v.to_numpy()
        ax.set(title='D  Dementia stage composition', ylabel='Percentage of selected staged caseload', ylim=(0, 126), yticks=[0, 25, 50, 75, 100])
        ax.set_xticks(range(7), [str(y) for y in range(2019, 2026)], rotation=45)
        ax.legend(loc='upper left', ncol=3, frameon=False, handlelength=1, columnspacing=.7)
        ax.text(.02, .82, 'Women left; men hatched', transform=ax.transAxes, fontsize=6.5)
        for ax in axes.flat:
            ax.grid(axis='y', alpha=.15, linewidth=.5)
            ax.set_axisbelow(True)
        stem = FIG / 'Neuro_Figure2_selected_caseload'
        for ext in ['png', 'pdf', 'svg']:
            fig.savefig(stem.with_suffix('.' + ext), dpi=600, facecolor='white')
        fig.savefig(stem.with_name(stem.name + '_preview').with_suffix('.png'), dpi=150, facecolor='white')
        plt.close(fig)
    caption = ('Neurological figure 2. Identified neurological caseload in selected paired reporting establishments, 2019–2025. '
               'A–B: December dementia and Parkinson caseload records by recorded sex and age band, summed only over establishments where both 60–79 and ≥80 counts are identified and same-year enrolment is positive in both sexes. '
               'The annual provider count n is printed under each year; these changing selected samples are not national totals or a fixed longitudinal cohort. '
               'Women are blue circles, men orange squares; solid lines denote age 60–79 and dashed lines age ≥80. '
               'C: female/male ratios of caseload records per FONASA enrolment within the same age band and paired establishment set. These descriptive ratios are not individual clinical-risk ratios and no inferential intervals are assigned. '
               'D: mild, moderate and advanced dementia shares among the same selected P6 establishment-years with all three stage rows identified; women are left, men right with hatching. '
               'Stocks repeat people between years; stage proportions do not measure individual severity progression. Selection and provider composition vary by year, and absence of a stage row remains missing. '
               'Reported sex totals and exhaustive age partitions identify some blank age cells by accounting; this is retained separately from raw numeric cells. Source tables preserve counts, denominators and provider samples.')
    info = {'id': 'neuro-2', 'path': relative(stem.with_suffix('.png')), 'caption': caption,
            'alt': 'Four panels show sex-age caseload counts with annual provider counts, within-age female/male recording ratios and staged dementia composition in paired eligible reporting establishments.',
            'formats': {ext: relative(stem.with_suffix('.' + ext)) for ext in ['png', 'pdf', 'svg']},
            'sources': ['DEIS/MINSAL REM: https://deis.minsal.cl/#datosabiertos', 'FONASA APS enrolment: https://public.tableau.com/views/ReporteInscritosCentrosAPS/ReporteAPS?:showVizHome=no']}
    return info, rates, pivot, composition


def main():
    FIG.mkdir(parents=True, exist_ok=True)
    cols = ['year', 'estab', 'measure', 'sex', 'age_group', 'observed_months', 'observed_component_months', 'component_codes_present',
            'complete_identified', 'enrolled', 'count_complete_identified', 'value_status', 'blank_target_cells',
            'raw_numeric_rows', 'accounting_identified_rows', 'unidentified_rows', 'conflict_rows']
    f = pd.read_csv(OUT / 'neuro_facility_year.csv.gz', usecols=cols)
    assert not f.duplicated(['year', 'estab', 'measure', 'sex', 'age_group']).any()
    yearly, period = eligibility(f)
    # This plot isolates reporting/measurement eligibility before any MHT
    # exposure intersection, provider exclusion, covariate or coefficient.
    a = f[f.measure.eq('dementia_entries') & f.sex.eq('Women') & f.age_group.eq('60+') & f.observed_months.gt(0)]
    coverage = a.groupby('year').observed_months.agg(n='size', median='median', lower=lambda x: x.quantile(.25), upper=lambda x: x.quantile(.75)).reset_index()
    coverage.to_csv(OUT / 'neuro_figure_1a_A05_month_coverage.csv', index=False)
    b = f[f.measure.eq('dementia_caseload') & f.sex.eq('Women') & f.age_group.eq('60+')]
    presence = b.groupby(['year', 'component_codes_present']).size().unstack(fill_value=0).reindex(columns=[0, 1, 2, 3], fill_value=0)
    presence.to_csv(OUT / 'neuro_figure_1b_P6_stage_presence.csv')
    scols = ['year', 'estab', 'measure', 'sex', 'stage', 'age_group', 'observed_component_months', 'raw_numeric_rows', 'accounting_identified_rows', 'unidentified_rows', 'conflict_rows', 'complete_identified', 'count_complete_identified']
    stage = pd.read_csv(OUT / 'neuro_stage_facility_year.csv.gz', usecols=scols)
    c = stage[stage.measure.eq('dementia_caseload') & stage.sex.eq('Women') & stage.age_group.eq('60+') & stage.observed_component_months.gt(0)]
    status = c.groupby('year')[['raw_numeric_rows', 'accounting_identified_rows', 'unidentified_rows', 'conflict_rows']].sum()
    status['present_stage_rows'] = status.sum(axis=1)
    status.to_csv(OUT / 'neuro_figure_1c_P6_accounting.csv')
    legacy = pd.read_csv(OUT / 'neuro_legacy_reconciliation.csv')
    source_qc = pd.read_csv(OUT / 'neuro_raw_presence_qc.csv')
    denominator_qc = pd.read_csv(OUT / 'neuro_denominator_source_check.csv')
    assert denominator_qc.matched_exactly.all()
    assert legacy.raw_minus_legacy.eq(0).all()
    compact = []
    for (measure, sex), g in legacy.groupby(['measure', 'sex']):
        corrections = g[g.deduplication_or_quarantine_delta.ne(0)]
        compact.append({'Outcome': LABELS[measure], 'Sex': sex, 'Checks': len(g), 'Max |raw − legacy|': g.raw_minus_legacy.abs().max(),
                        'Duplicate correction all ages': g.loc[g.age_group.eq('all_ages'), 'deduplication_or_quarantine_delta'].sum(),
                        'Duplicate correction age ≥60': g.loc[g.age_group.eq('60+'), 'deduplication_or_quarantine_delta'].sum(),
                        'Correction years': ', '.join(str(y) for y in sorted(corrections.year.unique())) or 'None'})
    pd.DataFrame(compact).to_csv(OUT / 'neuro_table_3_reconciliation_summary.csv', index=False)
    figure2, rates2, ratios2, composition2 = clinical_panels(f, stage)

    with mpl.rc_context({'font.family': 'DejaVu Sans', 'font.size': 7.8, 'axes.titlesize': 8.3, 'axes.labelsize': 7.8,
                         'legend.fontsize': 6.8, 'xtick.labelsize': 7.2, 'ytick.labelsize': 7.2,
                         'axes.spines.top': False, 'axes.spines.right': False, 'pdf.fonttype': 42, 'svg.fonttype': 'none'}):
        fig, axes = plt.subplots(2, 2, figsize=(170 / 25.4, 155 / 25.4), layout='constrained')
        ax = axes[0, 0]
        ax.errorbar(coverage.year, coverage['median'], yerr=[coverage['median'] - coverage.lower, coverage.upper - coverage['median']], fmt='o-',
                    color='#0072B2', capsize=2, lw=1.2, markersize=3.5)
        ax.set(title='A  A05 months with any dementia-stage row', ylabel='Observed months: median (IQR)', ylim=(0, 12.8), yticks=[0, 3, 6, 9, 12])
        ax.axhline(12, color='#666666', ls=':', lw=.8)
        ax.text(.04, .90, 'Women, age ≥60; reporters only', transform=ax.transAxes, va='top', fontsize=6.8)
        ax = axes[0, 1]
        bottom = np.zeros(len(presence))
        colors = ['#D9D9D9', '#E69F00', '#56B4E9', '#009E73']
        hatches = ['//', '..', 'xx', '']
        for k, label, color, hatch in zip([0, 1, 2, 3], ['No stage row', '1 stage', '2 stages', '3 stages'], colors, hatches):
            values = presence[k].to_numpy()
            ax.bar(presence.index, values, bottom=bottom, width=.73, label=label, color=color, hatch=hatch, edgecolor='white', linewidth=.35)
            bottom += values
        ax.set(title='B  December P6 stage-row presence', ylabel='Establishments in the annual frame', ylim=(0, bottom.max() * 1.13))
        ax.legend(loc='upper left', ncol=2, frameon=False, columnspacing=.7, handlelength=1.2)
        ax = axes[1, 0]
        bottom = np.zeros(len(status))
        fields = ['raw_numeric_rows', 'accounting_identified_rows', 'unidentified_rows', 'conflict_rows']
        for field, label, color, hatch in zip(fields, ['Raw numeric', 'Accounting identified', 'Unidentified', 'Conflict'],
                                             ['#0072B2', '#009E73', '#E69F00', '#CC79A7'], ['', '//', '..', 'xx']):
            values = 100 * status[field] / status.present_stage_rows
            ax.bar(status.index, values, bottom=bottom, width=.73, color=color, hatch=hatch, label=label, edgecolor='white', linewidth=.35)
            bottom += values
        ax.set(title='C  Age ≥60 values in present P6 stage rows', ylabel='Percentage of present stage rows', ylim=(0, 120), yticks=[0, 25, 50, 75, 100])
        ax.legend(loc='upper left', ncol=2, frameon=False, columnspacing=.7, handlelength=1.2)
        ax = axes[1, 1]
        pp = period[period.Outcome.ne('Dementia entries')].copy()
        xx = np.arange(len(pp))
        for shift, field, label, color, hatch in [(-.18, 'At least 3 identified years', '≥3 years', '#56B4E9', '//'), (.18, 'All 4 identified years', 'All 4 years', '#0072B2', '')]:
            bars = ax.bar(xx + shift, pp[field], width=.34, label=label, color=color, hatch=hatch, edgecolor='white', linewidth=.4)
            ax.bar_label(bars, fontsize=6.5, padding=2)
        ax.set_xticks(xx, ['Dementia\nWomen', 'Dementia\nMen', 'Parkinson\nWomen', 'Parkinson\nMen'])
        ax.set(title='D  Identified outcome years, 2022–2025', ylabel='Establishments with both age bands', ylim=(0, pp['At least 3 identified years'].max() * 1.25))
        ax.legend(loc='upper left', frameon=False, ncol=2, handlelength=1.2)
        for ax in axes.flat:
            ax.grid(axis='y', alpha=.15, linewidth=.5)
            ax.set_axisbelow(True)
        for ax in [axes[0, 0], axes[0, 1], axes[1, 0]]:
            ax.set_xticks(range(2019, 2026), [str(y) for y in range(2019, 2026)], rotation=45)
        stem = FIG / 'Neuro_Figure1_reporting_identification'
        for ext in ['png', 'pdf', 'svg']:
            fig.savefig(stem.with_suffix('.' + ext), dpi=600, facecolor='white')
        fig.savefig(stem.with_name(stem.name + '_preview').with_suffix('.png'), dpi=150, facecolor='white')
        plt.close(fig)

    def nperiod(measure, sex, field):
        row = period[period.Outcome.eq(LABELS[measure]) & period.Sex.eq(sex)].iloc[0]
        return int(row[field])
    n4w = nperiod('dementia_caseload', 'Women', 'All 4 identified years')
    n3w = nperiod('dementia_caseload', 'Women', 'At least 3 identified years')
    n4m = nperiod('dementia_caseload', 'Men', 'All 4 identified years')
    n3m = nperiod('dementia_caseload', 'Men', 'At least 3 identified years')
    p4w = nperiod('parkinson_caseload', 'Women', 'All 4 identified years')
    p3w = nperiod('parkinson_caseload', 'Women', 'At least 3 identified years')
    p4m = nperiod('parkinson_caseload', 'Men', 'All 4 identified years')
    p3m = nperiod('parkinson_caseload', 'Men', 'At least 3 identified years')
    a05 = yearly[yearly.measure.eq('dementia_entries')]
    nonzero_a05 = a05[a05.facilities.gt(0)]
    figure_path = stem.with_suffix('.png')
    caption = ('Neurological figure 1. Reporting presence and count identification in REM, 2019–2025. '
               'A: median and interquartile range of distinct months containing any A05 dementia-stage row among establishments with at least one such row; '
               'women aged ≥60 are used, but physical row presence is shared across sexes. The dotted line is 12 months, not an imputed reporting assumption. '
               'B: zero, one, two or all three December P6 dementia-stage rows present in the annual union of establishments found in selected REM rows or FONASA enrolment records. '
               'No stage row is not interpreted as zero caseload. C: classification of age ≥60 counts in present December P6 stage rows in women. '
               'Raw numeric values have all needed cells recorded; accounting identification uses a nonnegative residual from the exhaustive age partition and reported sex total. '
               'Unidentified values retain bounds, and inconsistent totals are conflicts. D: establishments with exact counts in both 60–79 and ≥80 age bands and positive same-year enrolment, '
               'for at least three or all four years in 2022–2025; all three P6 stages or the single P3 Parkinson row are required each year. '
               'Counts precede any MHT-exposure intersection, covariate restriction or association model. IQRs describe establishment dispersion, not confidence intervals. '
               'Annual entry flows and repeated December snapshots are distinct recording units and are not incidence or individual follow-up.')
    methods = [
        {'id': 'neuro-source-mapping', 'title': 'Neurological programme records and annual dictionary validation', 'paragraphs': [
            'This component rebuilt neurological REM inputs for 2019–2025 from the original selected source rows, sharing one physical extraction with the menopausal-care component. '
            'The seven target codes were A05 dementia entries 05901801–05901803, P6 dementia caseload P6222300/P6230100/P6230200 and P3 Parkinson caseload P3140200. '
            'All 49 code-year combinations were checked against their annual official A05, P3 and P6 coded templates. Col02/Col03 report men/women totals; Col04–Col37 provide alternating sex cells for 17 exhaustive age bands from 0–4 to ≥80.',
            'A05 was treated as an annual flow requiring all three stage rows in each of 12 months for a complete total. P6 was a December snapshot requiring all three stage rows; P3 required its single December Parkinson row. '
            'Repeated annual snapshots are not unique people or individual follow-up. No absent code, stage or month was turned into zero from another programme row.']},
        {'id': 'neuro-identification', 'title': 'Explicit numeric cells, accounting identification and missing records', 'paragraphs': [
            'Within a present row, the reported sex total and exhaustive nonnegative age partition were used to identify coarse age counts. Let R be the sex total minus the sum of known age cells. '
            'A requested band is exact when its cells are all numeric, R is zero, or all missing age cells lie inside that band; the latter case adds R to the known band cells. '
            'Other cases retain lower and upper bounds; negative residuals, negative cells and nonnumeric nonblank values are flagged as conflicts. No total is inferred from the other sex.',
            'Raw numeric zeros, accounting-identified zeros, blank cells and absent rows are exported separately. Complete counts require every expected component row and an identified count in every row. '
            'Identical full source rows were removed; any remaining nonidentical year/month/establishment/code duplicate would be quarantined rather than resolved with a maximum or latest value.']},
        {'id': 'neuro-denominators', 'title': 'Same-year enrolment and association-ready data', 'paragraphs': [
            'Same-year FONASA December enrolment counts were independently reconciled at facility, sex and age-band level against the raw annual source files. '
            'The original 20-year age groups in 2019–2023 change to 10-year groups from 2024. The common 60–79, ≥80 and ≥60 denominators are exact in all years; 60–69 and 70–79 denominators are exact only from 2024, without prorating earlier years. '
            'All-age enrolment includes unknown-age records with known sex, whereas age ≥60 denominators exclude unknown ages. These are annual snapshot counts, not observed person-time.',
            'The canonical table is establishment by year by recorded sex by age group by measure. It retains count identification, row/month/stage coverage, bounds, explicit-zero fields and same-year denominators. '
            'Primary eligibility checks require both 60–79 and ≥80 counts identified and positive denominators. Exposure intersection and association models are performed separately by the coordinating analysis.']},
    ]
    delta = legacy[legacy.deduplication_or_quarantine_delta.ne(0)]
    results = [{'id': 'neuro-reporting-results', 'title': 'Reporting feasibility and exact-count eligibility', 'paragraphs': [
        f'Annual A05 reporting was too sparse to support a routinely complete annual numerator. Among establishments with any dementia-stage row, the median distinct-month coverage ranged from {coverage["median"].min():g} to {coverage["median"].max():g} months. '
        f'With all three stages, both older-age bands and positive enrolment required, the annual eligibility table contains {int(nonzero_a05.facilities.sum())} eligible sex-specific facility-years in total, all in 2025; '
        'these represent one establishment in each sex, and no establishment had three complete eligible years in 2022–2025. A05 associations therefore require a separately labelled coverage-limited or positive-record analysis rather than an assumed complete annual disease rate.',
        f'For December P6 dementia caseload, {n4w:,} establishments in women and {n4m:,} in men had identified counts in both older-age bands and positive enrolment in all four years of 2022–2025. '
        f'The corresponding numbers with at least three years were {n3w:,} and {n3m:,}. These are outcome and denominator feasibility counts before intersection with menopausal-care exposure and covariates, not final model sample sizes.',
        f'For December P3 Parkinson caseload, {p4w:,} establishments in women and {p4m:,} in men met all-four-year eligibility; {p3w:,} and {p3m:,}, respectively, met at-least-three-year eligibility. '
        'Presence of an outcome row or accounting identification does not establish reporting completeness or clinical diagnostic validity.',
        f'The uncorrected source-cell sums reproduce the legacy zero-filled rem_long totals exactly for every examined year, measure, sex and all-age/age ≥60 group. '
        f'Three exact duplicate neurological P rows were removed in 2021 and no nonidentical neurological keys were quarantined. '
        'This reduces women’s dementia caseload by 3 all-age records and 2 at age ≥60, and men’s Parkinson caseload by 2 in both age scopes. '
        'These are transparent data corrections; accounting-based identification and reporting restrictions remain separate from that reconciliation.',
        'All denominator source checks matched exactly. The complete-provider sample is selected and cannot be interpreted as the complete primary-care network, national neurological prevalence, diagnostic delay or an effect of menopausal treatment.'
    ]}]
    content = {'language': 'en', 'methods': methods, 'results': results,
               'figures': [{'id': 'neuro-1', 'path': relative(figure_path), 'caption': caption,
                            'alt': 'Four panels distinguish sparse A05 monthly coverage, P6 stage-row presence, accounting identification and multi-year eligibility before MHT exposure linkage.',
                            'formats': {ext: relative(stem.with_suffix('.' + ext)) for ext in ['png', 'pdf', 'svg']},
                            'sources': ['DEIS/MINSAL REM: https://deis.minsal.cl/#datosabiertos', 'FONASA APS enrolment: https://public.tableau.com/views/ReporteInscritosCentrosAPS/ReporteAPS?:showVizHome=no']}],
               'tables': [
                   {'id': 'neuro-annual-eligibility', 'title': 'Annual neurological outcome eligibility with both older-age bands', 'csv_path': relative(OUT / 'neuro_table_1_annual_eligibility.csv'), 'landscape': True,
                    'note': 'Requires identified counts in both 60–79 and ≥80 bands and positive same-year FONASA enrolment. All three December P6 stages, the single December P3 row, or all 36 annual A05 stage-month rows must be present. Before MHT-exposure or covariate intersection.'},
                   {'id': 'neuro-period-eligibility', 'title': 'Multi-year neurological recording eligibility, 2022–2025', 'csv_path': relative(OUT / 'neuro_table_2_period_eligibility.csv'), 'landscape': False,
                    'note': 'At-least-three-year eligibility includes all-four-year eligibility. These are selected establishments with complete identified recorded counts and denominators; they are not final association-model samples or evidence of complete clinical ascertainment.'},
                   {'id': 'neuro-legacy-reconciliation', 'title': 'Neurological source-sum reconciliation and duplicate corrections', 'csv_path': relative(OUT / 'neuro_table_3_reconciliation_summary.csv'), 'landscape': True,
                    'note': 'Fourteen checks per outcome and sex cover seven years and two age scopes. Raw-minus-legacy differences are zero throughout. All-age and age ≥60 corrections overlap and must not be added. The complete 84-row audit is retained separately as neuro_legacy_reconciliation.csv; the legacy blank-as-zero rule is used solely for this source reconciliation.'},
                   {'id': 'neuro-selected-caseload', 'title': 'Caseload recording in annually paired eligible establishments', 'csv_path': relative(OUT / 'neuro_table_4_selected_caseload.csv'), 'landscape': True,
                    'note': 'Each annual outcome sample requires both older-age bands identified with positive same-year enrolment in both sexes. Counts are repeated December caseload records in selected changing providers, not national totals or unique people. Pooled age ≥60 recording rates retain that age mix; female/male ratios are additionally shown within each age band. No individual-risk or causal interpretation is assigned.'},
                   {'id': 'neuro-stage-composition', 'title': 'Recorded dementia-stage composition in paired eligible provider snapshots, 2022–2025', 'csv_path': relative(OUT / 'neuro_table_5_stage_composition.csv'), 'landscape': False,
                    'note': 'Only P6 establishment-years with all three stage rows identified in both sexes and positive denominators in both older-age bands contribute. Establishment snapshots and caseload records repeat establishments and people across years. Percentages are conditional on this selected recorded caseload and do not measure individual severity progression.'}]}
    content['figures'].append(figure2)
    latest = rates2[rates2.year.eq(2025) & rates2.measure.eq('dementia_caseload')]
    earliest = rates2[rates2.year.eq(2019) & rates2.measure.eq('dementia_caseload')]
    late_w = composition2[composition2.year.between(2022, 2025) & composition2.sex.eq('Women')].groupby('stage').records.sum()
    late_m = composition2[composition2.year.between(2022, 2025) & composition2.sex.eq('Men')].groupby('stage').records.sum()
    rr_latest = ratios2[ratios2.year.eq(2025) & ratios2.measure.eq('dementia_caseload')].set_index('age_group')
    content['results'].append({'id': 'neuro-selected-caseload-results', 'title': 'Identified caseload patterns among annually paired providers', 'paragraphs': [
        f'The annually paired P6 sample contained {int(earliest.providers.iloc[0]):,} establishments in 2019 and {int(latest.providers.iloc[0]):,} in 2025. '
        f'Within those changing selected samples, recorded dementia caseload at age≥60 totalled {int(earliest[earliest.sex.eq("Women")].records.sum()):,} records in women and {int(earliest[earliest.sex.eq("Men")].records.sum()):,} in men in 2019, '
        f'and {int(latest[latest.sex.eq("Women")].records.sum()):,} and {int(latest[latest.sex.eq("Men")].records.sum()):,}, respectively, in 2025. '
        'These counts describe identified recorded caseload among the eligible providers and cannot be interpreted as national totals or changes in a fixed cohort.',
        f'In 2025, within-age female/male dementia recording ratios per enrolment were {rr_latest.loc["60-79", "female_male_recording_ratio"]:.2f} at60–79 and {rr_latest.loc["80+", "female_male_recording_ratio"]:.2f} at≥80, using the same paired providers in both sexes. '
        'The figure and source tables retain both caseload numerators, enrolment denominators and annual provider counts. These are descriptive service-recording ratios rather than clinical disease-risk estimates.',
        f'Pooling the selected P6 snapshots in 2022–2025, advanced-stage records accounted for {100*late_w["advanced"]/late_w.sum():.1f}% of the staged caseload in women and {100*late_m["advanced"]/late_m.sum():.1f}% in men. '
        'The three-stage distribution is conditional on complete identified stage rows; repeat annual records and changing provider eligibility prevent an individual progression interpretation.'
    ]})
    for section in content['results']:
        section['paragraphs'] = [s.replace('age≥60', 'age ≥60').replace(' at60', ' at 60').replace(' at≥80', ' at ≥80') for s in section['paragraphs']]
    (OUT / 'neuro_report_content.json').write_text(json.dumps(content, ensure_ascii=False, indent=2) + '\n')
    (OUT / 'neuro_figure_captions.txt').write_text('\n\n'.join(x['caption'] for x in content['figures']) + '\n')
    manifest = {'language': 'en', 'script': relative(Path(__file__)), 'script_sha256': digest(Path(__file__)),
                'python': platform.python_version(), 'matplotlib': mpl.__version__, 'figure_width_mm': 170, 'figure_height_mm': {'neuro-1': 155, 'neuro-2': 160}, 'dpi': 600,
                'sources': [{'path': relative(OUT / name), 'sha256': digest(OUT / name)} for name in ['neuro_facility_year.csv.gz', 'neuro_stage_facility_year.csv.gz', 'neuro_legacy_reconciliation.csv', 'neuro_raw_presence_qc.csv', 'neuro_denominator_source_check.csv']],
                'reproduce': {'public_aggregate_rebuild': 'python3 scripts/access_extension/neuro_reporting_figures.py',
                              'independent_association_audit': 'python3 scripts/access_extension/neuro_association_audit.py',
                              'optional_external_raw_refresh': ['python3 scripts/access_extension/rem_extract.py', 'python3 scripts/access_extension/neuro_prepare.py'],
                              'public_mode_requires_external_disk': False,
                              'raw_mode_requires_external_disk': True},
                'tables': [{'path': x['csv_path'], 'sha256': digest(ROOT / x['csv_path'])} for x in content['tables']],
                'outputs': [{'path': relative(Path(item['formats'][ext]) if Path(item['formats'][ext]).is_absolute() else ROOT / item['formats'][ext]),
                             'sha256': digest(ROOT / item['formats'][ext])} for item in content['figures'] for ext in ['png', 'pdf', 'svg']],
                'checks': {'unique_canonical_keys': True, 'denominator_source_reconciled': True, 'raw_source_sums_reproduce_legacy': True},
                'visual_review': 'A separate visual QA receipt records the exact reviewed PNG hashes; regeneration does not itself confer visual approval.'}
    (OUT / 'neuro_figure_metadata.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'status': 'complete', 'figure': relative(figure_path), 'report': relative(OUT / 'neuro_report_content.json'),
                      'P6_women_all4': n4w, 'P6_women_at_least3': n3w, 'duplicate_correction_rows': len(delta)}))


if __name__ == '__main__':
    main()
