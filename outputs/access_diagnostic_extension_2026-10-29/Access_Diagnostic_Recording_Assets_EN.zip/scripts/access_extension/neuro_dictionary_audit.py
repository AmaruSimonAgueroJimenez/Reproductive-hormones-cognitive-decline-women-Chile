"""Verify the seven neurological REM rows against every annual official template."""
from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from pathlib import Path

import openpyxl
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
DATA = Path('/Volumes/Datos/Asesorias_Data')
OUT = ROOT / 'outputs/access_diagnostic_extension_2026-10-29/neuro'
CODES = {
    '05901801': ('A', 'A05', 'dementia_entries', 'mild'),
    '05901802': ('A', 'A05', 'dementia_entries', 'moderate'),
    '05901803': ('A', 'A05', 'dementia_entries', 'advanced'),
    'P6222300': ('P', 'P6', 'dementia_caseload', 'mild'),
    'P6230100': ('P', 'P6', 'dementia_caseload', 'moderate'),
    'P6230200': ('P', 'P6', 'dementia_caseload', 'advanced'),
    'P3140200': ('P', 'P3', 'parkinson_caseload', 'all_stages'),
}
AGE5 = [f'{a}-{a+4}' for a in range(0, 80, 5)] + ['80+']


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def norm(value) -> str:
    return ' '.join(unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode().lower().split())


def code_string(value) -> str:
    if isinstance(value, (int, float)):
        return str(int(value)).zfill(8)
    return str(value or '').strip()


def run() -> dict:
    OUT.mkdir(parents=True, exist_ok=True)
    proof, files, issues = [], [], []
    for year in range(2019, 2026):
        for serie, sheets in [('A', ['A05']), ('P', ['P3', 'P6'])]:
            folder = DATA / (f'REM/SerieA/metadata/diccionarios/{year}' if serie == 'A' else f'REM/SerieP/diccionarios/{year}')
            paths = [p for p in folder.iterdir() if p.suffix in ('.xlsx', '.xlsm') and (serie == 'P' or re.search(r'(^|[ _])SA[ _-]', p.name, re.I))]
            assert len(paths) == 1, (folder, paths)
            path = paths[0]
            files.append({'year': year, 'serie': serie, 'path': str(path), 'sha256': sha(path)})
            book = openpyxl.load_workbook(path, read_only=True, data_only=True)
            for sheet in sheets:
                rows = list(book[sheet].values)
                for i, row in enumerate(rows):
                    code = code_string(row[0])
                    if code not in CODES or CODES[code][0] != serie:
                        continue
                    mappings = {str(v).upper(): j for j, v in enumerate(row) if isinstance(v, str) and re.fullmatch(r'COL\d{2}', v.upper())}
                    if not mappings:
                        continue
                    ok = all(mappings.get(f'COL{k:02d}') == k + 2 for k in range(1, 38))
                    sex_headers = []
                    for col, label in [(4, 'hombres'), (5, 'mujeres')]:
                        found = [(j + 1, rows[j][col]) for j in range(i - 1, -1, -1) if norm(rows[j][col]) == label]
                        sex_headers.append({'cell': f'{openpyxl.utils.get_column_letter(col+1)}{found[0][0]}', 'value': found[0][1]} if found else {})
                        ok &= bool(found)
                    ages = []
                    for j, expected in enumerate(AGE5):
                        col = 6 + 2 * j
                        candidates = []
                        for k in range(i - 1, -1, -1):
                            val = rows[k][col]
                            txt = norm(val)
                            nums = re.findall(r'\d+', txt)
                            label = f'{nums[0]}-{nums[1]}' if len(nums) == 2 and (' a ' in txt or '-' in txt) else ('80+' if nums == ['80'] and ('mas' in txt or '+' in txt) else '')
                            if label:
                                candidates.append((k + 1, str(val), label))
                                break
                        ok &= bool(candidates) and candidates[0][2] == expected
                        ages.append({'column_men': f'Col{4+2*j:02d}', 'column_women': f'Col{5+2*j:02d}', 'expected_age': expected,
                                     'header_cell': f'{openpyxl.utils.get_column_letter(col+1)}{candidates[0][0]}' if candidates else None,
                                     'header_label': candidates[0][1] if candidates else None})
                    record = {'year': year, 'serie': serie, 'sheet': sheet, 'code': code, 'measure': CODES[code][2], 'stage': CODES[code][3],
                              'source_file': str(path), 'source_row': i + 1, 'source_labels': [str(v) for v in row[1:3] if v is not None],
                              'columns_1_to_37_expected_positions': bool(ok), 'sex_headers': sex_headers, 'age_headers': ages}
                    proof.append(record)
                    if not ok:
                        issues.append({'year': year, 'code': code, 'issue': 'Column or age/sex header mismatch; do not decode until resolved.'})
            book.close()
    expected = {(year, code) for year in range(2019, 2026) for code in CODES}
    actual = {(p['year'], p['code']) for p in proof}
    if actual != expected:
        issues.append({'issue': 'Missing annual rows', 'missing': sorted(expected - actual)})
    payload = {'language': 'en', 'status': 'pass' if not issues else 'requires_review', 'expected_records': len(expected), 'verified_records': len(proof),
               'files': files, 'records': proof, 'issues': issues,
               'meaning': 'A05 dementia entries are annual flows; P6 dementia and P3 Parkinson rows are caseload snapshots. Raw blanks and absent rows are not explicit zeros.'}
    (OUT / 'neuro_dictionary_mapping.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
    pd.DataFrame([{k: p[k] for k in ['year', 'serie', 'sheet', 'code', 'measure', 'stage', 'source_file', 'source_row', 'columns_1_to_37_expected_positions']} for p in proof]).to_csv(OUT / 'neuro_dictionary_inventory.csv', index=False)
    print(json.dumps({'status': payload['status'], 'verified_records': len(proof), 'issues': issues}, ensure_ascii=False))
    return payload


if __name__ == '__main__':
    run()
