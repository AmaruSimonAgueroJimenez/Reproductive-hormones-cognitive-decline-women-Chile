"""Prepare neurological REM reporting inputs, retaining zeros and missingness.

No association model is fitted. Source caches are created once by rem_extract.py.
Only establishment-level and coarser records are exported; REM contains no person IDs.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

from neuro_dictionary_audit import CODES, OUT, ROOT, run as dictionary_audit

DATA = Path(os.environ.get('ASESORIAS_DATA_ROOT', '/Volumes/Datos/Asesorias_Data'))
DERIVED = Path(os.environ.get('MF_DERIVED', str(DATA / 'derived/Reproductive-hormones-cognitive-decline-women-Chile')))
CACHE = DERIVED / 'access_extension/rem'
PRIVATE = DERIVED / 'access_extension/neuro'
YEARS = list(range(2019, 2026))
SEXES = [('Men', 0), ('Women', 1)]
GROUPS = {'all_ages': list(range(17)), '60-69': [12, 13], '70-79': [14, 15],
          '60-79': [12, 13, 14, 15], '80+': [16], '60+': [12, 13, 14, 15, 16]}
MEASURE_CODES = {
    'dementia_entries': ['05901801', '05901802', '05901803'],
    'dementia_caseload': ['P6222300', 'P6230100', 'P6230200'],
    'parkinson_caseload': ['P3140200'],
}
NATURAL_KEY = ['Mes', 'IdServicio', 'Ano', 'IdEstablecimiento', 'CodigoPrestacion', 'IdRegion', 'IdComuna']
KEY = ['year', 'estab', 'sex', 'age_group']


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def aggregate_sum(s):
    return s.sum(min_count=1)


def identify_band(ages: pd.DataFrame, total: pd.Series, indices: list[int], all_ages=False):
    """Identify a band or retain its exact nonnegative-count bounds.

    A reported sex total and the exhaustive 17 nonnegative age cells imply
    R = total - sum(known cells). A band is identified when all its cells are
    known, R is zero, or all missing cells are inside that band. Nothing about
    another code, another month, or the other sex is used.
    """
    k_all = ages.sum(axis=1)
    target = ages.iloc[:, indices]
    k = target.sum(axis=1)
    missing = ages.isna().sum(axis=1)
    missing_band = target.isna().sum(axis=1)
    residual = total - k_all
    conflict = ages.lt(0).any(axis=1) | total.lt(0) | (total.notna() & residual.lt(0))
    identified = missing_band.eq(0) | (total.notna() & residual.ge(0) & (residual.eq(0) | missing_band.eq(missing)))
    value = k.copy()
    allocate = total.notna() & residual.ge(0) & missing_band.gt(0) & missing_band.eq(missing)
    value.loc[allocate] = k[allocate] + residual[allocate]
    lo = k.copy()
    hi = k + residual
    hi.loc[total.isna()] = np.nan
    status = pd.Series(np.where(missing_band.eq(0), 'raw_numeric', 'accounting_identified'), index=ages.index)
    if all_ages:
        # The directly reported sex total is the primary all-age value.
        identified = total.notna() | missing.eq(0)
        value = total.where(total.notna(), k_all)
        lo = total.where(total.notna(), k_all)
        hi = total.where(total.notna() | missing.eq(0), np.nan)
        hi.loc[total.isna() & missing.eq(0)] = k_all
        status[:] = np.where(total.notna(), 'raw_numeric', 'accounting_identified')
    lo.loc[identified] = value[identified]
    hi.loc[identified] = value[identified]
    status.loc[~identified] = 'unidentified'
    status.loc[conflict] = 'conflict'
    value.loc[~identified | conflict] = np.nan
    lo.loc[conflict] = np.nan
    hi.loc[conflict] = np.nan
    return value, lo, hi, status, residual, missing_band


def accounting_self_check():
    # Direct band, zero residual, all missing inside band, bounded unknown,
    # missing total with a direct band, and inconsistent source total.
    a = pd.DataFrame([[2., 3., 5.], [2., np.nan, 3.], [2., np.nan, np.nan],
                      [np.nan, np.nan, 3.], [2., 3., np.nan], [8., 3., np.nan]])
    t = pd.Series([10., 5., 7., 9., np.nan, 4.])
    v, lo, hi, status, _, _ = identify_band(a, t, [1, 2])
    assert v.iloc[0] == 8 and status.iloc[0] == 'raw_numeric'
    assert v.iloc[1] == 3 and status.iloc[1] == 'accounting_identified'
    assert v.iloc[2] == 5 and status.iloc[2] == 'accounting_identified'
    assert pd.isna(v.iloc[3]) and lo.iloc[3] == 3 and hi.iloc[3] == 9
    assert pd.isna(v.iloc[4]) and status.iloc[5] == 'conflict'
    # All requested cells may be known even when the sex total is missing.
    v, _, _, status, _, _ = identify_band(a, t, [0, 1])
    assert v.iloc[4] == 5 and status.iloc[4] == 'raw_numeric'


def clean_source(year, serie):
    path = CACHE / f'raw_selected_{serie}_{year}.csv.gz'
    source = pd.read_csv(path, dtype=str, keep_default_na=False)
    # Reuse all selected-code location metadata to define the reporting frame.
    locations = source[['IdEstablecimiento', 'IdComuna', 'IdRegion']].copy()
    locations.columns = ['estab', 'comuna', 'region']
    locations = locations.apply(pd.to_numeric, errors='coerce').assign(year=year)
    z = source[source.CodigoPrestacion.isin(CODES)].copy()
    original = z.copy()
    z = z.drop_duplicates()
    duplicate_rows = len(original) - len(z)
    # A more restrictive facility/month/code key also detects service/location
    # conflicts; none is resolved with a maximum or an arbitrary latest row.
    key = ['Ano', 'Mes', 'IdEstablecimiento', 'CodigoPrestacion']
    conflict = z.duplicated(key, keep=False)
    quarantined = z[conflict].copy()
    z = z[~conflict].reset_index(drop=True)
    for f in [z, quarantined, original]:
        f['year'] = pd.to_numeric(f.Ano, errors='coerce')
        f['month'] = pd.to_numeric(f.Mes, errors='coerce')
        f['estab'] = pd.to_numeric(f.IdEstablecimiento, errors='coerce')
        f['comuna'] = pd.to_numeric(f.IdComuna, errors='coerce')
        f['code'] = f.CodigoPrestacion
    audit = {'year': year, 'serie': serie, 'cache': str(path), 'cache_sha256': sha(path),
             'neuro_raw_rows': len(original), 'exact_duplicate_rows_removed': duplicate_rows,
             'conflicting_rows_quarantined': len(quarantined), 'retained_rows': len(z)}
    return z, original, quarantined, locations, audit


def decode(rows):
    pieces = []
    for sex, offset in SEXES:
        cols = [f'Col{i+offset:02d}' for i in range(4, 38, 2)]
        raw = rows[cols].apply(lambda c: c.str.strip())
        ages = raw.apply(pd.to_numeric, errors='coerce')
        total_raw = rows[f'Col{2+offset:02d}'].str.strip()
        total = pd.to_numeric(total_raw, errors='coerce')
        invalid_all = (raw.ne('') & ages.isna()).sum(axis=1)
        for age_group, indices in GROUPS.items():
            count, lo, hi, status, residual, missing_band = identify_band(ages, total, indices, age_group == 'all_ages')
            invalid_total = total_raw.ne('') & total.isna()
            invalid = invalid_all.gt(0) | invalid_total
            count.loc[invalid] = np.nan
            lo.loc[invalid] = np.nan
            hi.loc[invalid] = np.nan
            status.loc[invalid] = 'conflict'
            band_raw = raw.iloc[:, indices]
            band_values = ages.iloc[:, indices]
            legacy_value = total.fillna(0) if age_group == 'all_ages' else band_values.fillna(0).sum(axis=1)
            q = rows[['year', 'month', 'estab', 'comuna', 'code']].copy()
            q['sex'] = sex
            q['age_group'] = age_group
            q['measure'] = q.code.map(lambda x: CODES[x][2])
            q['stage'] = q.code.map(lambda x: CODES[x][3])
            q['serie'] = q.code.map(lambda x: CODES[x][0])
            q['identified_count'] = count
            q['lower_bound'] = lo
            q['upper_bound'] = hi
            q['value_status'] = status
            q['legacy_blank_zero_value'] = legacy_value
            q['blank_target_cells'] = total_raw.eq('').astype(int) if age_group == 'all_ages' else band_raw.eq('').sum(axis=1)
            q['invalid_target_cells'] = invalid_total.astype(int) if age_group == 'all_ages' else (band_raw.ne('') & band_values.isna()).sum(axis=1)
            q['target_cells'] = 1 if age_group == 'all_ages' else len(indices)
            q['missing_age_cells'] = ages.isna().sum(axis=1)
            q['all_age_residual'] = residual
            q['sex_total_numeric'] = total.notna().astype(int)
            q['raw_numeric'] = status.eq('raw_numeric').astype(int)
            q['accounting_identified'] = status.eq('accounting_identified').astype(int)
            q['unidentified'] = status.eq('unidentified').astype(int)
            q['conflict'] = status.eq('conflict').astype(int)
            q['raw_numeric_zero'] = (status.eq('raw_numeric') & count.eq(0)).astype(int)
            q['accounting_zero'] = (status.eq('accounting_identified') & count.eq(0)).astype(int)
            pieces.append(q)
    return pd.concat(pieces, ignore_index=True)


def prepare_denominators():
    path = DERIVED / 'denominators/fonasa_centros.csv.gz'
    f = pd.read_csv(path)
    f['sex'] = f.sex.map({'Hombre': 'Men', 'Mujer': 'Women'})
    f = f[f.year.isin(YEARS) & f.estab.notna() & f.sex.notna()].copy()
    frames, audit, files = [], [], [{'path': str(path), 'sha256': sha(path)}]
    for year, g in f.groupby('year'):
        raw_path = DATA / f'FONASA/APS/Inscritos_APS_{year}12.csv'
        try:
            raw = pd.read_csv(raw_path, dtype=str)
        except UnicodeDecodeError:
            raw = pd.read_csv(raw_path, dtype=str, encoding='latin-1')
        files.append({'path': str(raw_path), 'sha256': sha(raw_path)})
        raw['sex'] = raw.SEXO.str.strip().map({'Hombres': 'Men', 'Mujeres': 'Women'})
        raw['estab'] = pd.to_numeric(raw.COD_CENTRO, errors='coerce')
        raw['n'] = pd.to_numeric(raw.TOTAL_INSCRITOS, errors='coerce')
        raw['age_lo'] = pd.to_numeric(raw.EDAD_TRAMO.str.extract(r'^(\d+)')[0], errors='coerce')
        for age_group in GROUPS:
            if age_group == 'all_ages':
                use, ru = g, raw
            elif age_group == '60+':
                use, ru = g[g.band.isin(['60-79', '80+'])], raw[raw.age_lo.ge(60)]
            elif age_group == '60-79':
                use, ru = g[g.band.eq('60-79')], raw[raw.age_lo.ge(60) & raw.age_lo.lt(80)]
            elif age_group == '80+':
                use, ru = g[g.band.eq('80+')], raw[raw.age_lo.ge(80)]
            else:
                if year < 2024:
                    continue
                start = int(age_group[:2])
                use, ru = g[g.band10.eq(start)], raw[raw.age_lo.eq(start)]
            den = use.groupby(['year', 'estab', 'sex'], as_index=False).n.sum().rename(columns={'n': 'enrolled'})
            den['age_group'] = age_group
            frames.append(den)
            a = ru[ru.sex.notna() & ru.estab.notna()].groupby(['estab', 'sex']).n.sum().rename('raw_n')
            b = den.set_index(['estab', 'sex']).enrolled.rename('derived_n')
            cmp = pd.concat([a, b], axis=1).fillna(0)
            audit.append({'year': int(year), 'age_group': age_group, 'raw_age_labels': '; '.join(sorted(ru.EDAD_TRAMO.dropna().unique())),
                          'raw_sum': float(a.sum()), 'derived_sum': float(b.sum()), 'max_abs_facility_difference': float((cmp.raw_n - cmp.derived_n).abs().max()),
                          'matched_exactly': bool(np.allclose(cmp.raw_n, cmp.derived_n, atol=0, rtol=0))})
    audit = pd.DataFrame(audit)
    assert audit.matched_exactly.all(), 'Existing FONASA denominator fails independent source reconciliation.'
    audit.to_csv(OUT / 'neuro_denominator_source_check.csv', index=False)
    return pd.concat(frames, ignore_index=True), files


def frame_locations(locations, denominators):
    loc = pd.concat(locations, ignore_index=True).drop_duplicates()
    pairs = pd.concat([loc[['year', 'estab']], denominators[['year', 'estab']]], ignore_index=True).dropna().drop_duplicates()
    records = []
    for (year, estab), g in loc.dropna(subset=['estab']).groupby(['year', 'estab']):
        cc = g.comuna.dropna().unique()
        rr = g.region.dropna().unique()
        records.append({'year': year, 'estab': estab, 'comuna': cc[0] if len(cc) == 1 else np.nan,
                        'region': rr[0] if len(rr) == 1 else np.nan,
                        'location_status': 'raw_unique' if len(cc) == 1 else 'raw_missing_or_conflicting'})
    pairs = pairs.merge(pd.DataFrame(records), on=['year', 'estab'], how='left')
    context = pd.read_csv(ROOT / 'outputs/multifuente/tables/centers_context.csv', usecols=['estab', 'comuna'])
    context = context.drop_duplicates('estab').rename(columns={'comuna': 'catalogue_comuna'})
    pairs = pairs.merge(context, on='estab', how='left')
    fallback = pairs.location_status.isna()
    pairs.loc[fallback, 'comuna'] = pairs.loc[fallback, 'catalogue_comuna']
    pairs.loc[fallback, 'location_status'] = 'catalogue_fallback_no_selected_raw_row'
    return pairs.drop(columns='catalogue_comuna')


def annual_aggregate(monthly, universe, code_set, stage):
    measure = CODES[code_set[0]][2]
    serie = CODES[code_set[0]][0]
    z = monthly[monthly.code.isin(code_set)].copy()
    if serie == 'P':
        z = z[z.month.eq(12)]
    group = z.groupby(KEY, sort=False)
    counts = group.agg(
        observed_component_months=('code', 'size'), observed_months=('month', 'nunique'),
        component_codes_present=('code', 'nunique'), identified_rows=('identified_count', 'count'),
        raw_numeric_rows=('raw_numeric', 'sum'), accounting_identified_rows=('accounting_identified', 'sum'),
        unidentified_rows=('unidentified', 'sum'), conflict_rows=('conflict', 'sum'),
        raw_numeric_zero_component_months=('raw_numeric_zero', 'sum'), accounting_zero_component_months=('accounting_zero', 'sum'),
        blank_target_cells=('blank_target_cells', 'sum'), invalid_target_cells=('invalid_target_cells', 'sum'),
        target_cells_in_present_rows=('target_cells', 'sum'), count_observed_identified=('identified_count', aggregate_sum),
        count_lower_bound=('lower_bound', aggregate_sum), count_upper_bound=('upper_bound', aggregate_sum),
        upper_bounds_available=('upper_bound', 'count'), legacy_blank_zero_sum=('legacy_blank_zero_value', 'sum'))
    month_check = z.groupby(KEY + ['month']).agg(n_codes=('code', 'nunique'), n_identified=('identified_count', 'count'),
                                                n_raw_zero=('raw_numeric_zero', 'sum'), value=('identified_count', aggregate_sum)).reset_index()
    all_present = month_check.n_codes.eq(len(code_set))
    zero_months = month_check[all_present & month_check.n_raw_zero.eq(len(code_set))]
    counts['raw_numeric_zero_months'] = zero_months.groupby(KEY).month.nunique()
    exact_zero = month_check[all_present & month_check.n_identified.eq(len(code_set)) & month_check.value.eq(0)]
    counts['identified_zero_months'] = exact_zero.groupby(KEY).month.nunique()
    counts['months_with_accounting_zero'] = z[z.accounting_zero.eq(1)].groupby(KEY).month.nunique()
    allkeys = universe[['year', 'estab']].merge(pd.DataFrame({'sex': ['Men', 'Women']}), how='cross').merge(pd.DataFrame({'age_group': list(GROUPS)}), how='cross')
    out = allkeys.merge(counts.reset_index(), on=KEY, how='left')
    metric = ['observed_component_months', 'observed_months', 'component_codes_present', 'identified_rows', 'raw_numeric_rows', 'accounting_identified_rows',
              'unidentified_rows', 'conflict_rows', 'raw_numeric_zero_component_months', 'accounting_zero_component_months', 'raw_numeric_zero_months',
              'identified_zero_months', 'months_with_accounting_zero', 'blank_target_cells', 'invalid_target_cells', 'target_cells_in_present_rows', 'upper_bounds_available']
    out[metric] = out[metric].fillna(0).astype(int)
    expected = len(code_set) * (12 if serie == 'A' else 1)
    out['expected_component_months'] = expected
    out['expected_months'] = 12 if serie == 'A' else 1
    out['expected_component_codes'] = len(code_set)
    out['absent_component_months'] = expected - out.observed_component_months
    full = out.observed_component_months.eq(expected) & out.identified_rows.eq(expected) & out.conflict_rows.eq(0)
    out['count_complete_identified'] = out.count_observed_identified.where(full)
    out.loc[out.identified_rows.ne(out.observed_component_months), 'count_observed_identified'] = np.nan
    out.loc[out.upper_bounds_available.ne(out.observed_component_months), 'count_upper_bound'] = np.nan
    out['value_status'] = np.select(
        [out.observed_component_months.eq(0), out.conflict_rows.gt(0), out.observed_component_months.ne(expected), out.identified_rows.ne(expected), out.accounting_identified_rows.gt(0)],
        ['absent_rows', 'conflict', 'partial_row_coverage', 'unidentified_cells', 'accounting_identified_complete'], default='raw_numeric_complete')
    out['complete_identified'] = full
    out['measure'] = measure
    out['stage'] = stage
    out['code_set'] = '|'.join(code_set)
    out['serie'] = serie
    out['observation_unit'] = 'annual programme-entry records' if serie == 'A' else 'December programme caseload snapshot'
    return out


def summaries(facility):
    def summarise(g):
        ok = g.complete_identified & g.enrolled.gt(0)
        count = g.loc[ok, 'count_complete_identified'].sum(min_count=1)
        den = g.loc[ok, 'enrolled'].sum(min_count=1)
        return pd.Series({'facilities_in_frame': len(g), 'facilities_with_any_target_row': int(g.observed_component_months.gt(0).sum()),
                          'facilities_complete_identified': int(g.complete_identified.sum()), 'facilities_complete_with_enrolment': int(ok.sum()),
                          'count_complete_in_matched_facilities': count, 'enrolled_in_same_complete_facilities': den,
                          'records_per_1000_in_complete_matched_facilities': 1000 * count / den if den > 0 else np.nan,
                          'recorded_count_lower_bound': g.count_lower_bound.sum(min_count=1),
                          'facilities_with_partial_row_coverage': int(g.value_status.eq('partial_row_coverage').sum()),
                          'facilities_with_unidentified_cells': int(g.value_status.eq('unidentified_cells').sum()),
                          'raw_numeric_zero_component_months': int(g.raw_numeric_zero_component_months.sum()),
                          'accounting_zero_component_months': int(g.accounting_zero_component_months.sum())})
    keys = ['year', 'measure', 'sex', 'age_group']
    annual = facility.groupby(keys, dropna=False).apply(summarise, include_groups=False).reset_index()
    municipal = facility.groupby(['comuna'] + keys, dropna=False).apply(summarise, include_groups=False).reset_index()
    annual.to_csv(OUT / 'neuro_annual.csv', index=False)
    municipal.to_csv(OUT / 'neuro_municipal_year.csv.gz', index=False)
    frequency = facility.groupby(['year', 'measure', 'sex', 'age_group', 'observed_months', 'value_status'], dropna=False).size().rename('facilities').reset_index()
    frequency.to_csv(OUT / 'neuro_reporting_frequency.csv', index=False)
    period = facility[facility.age_group.eq('60+') & facility.year.between(2022, 2025)].groupby(['estab', 'measure', 'sex']).agg(
        identified_years=('complete_identified', 'sum'), years_with_any_record=('observed_months', lambda x: int(x.gt(0).sum())),
        covered_years=('year', 'size')).reset_index()
    period.to_csv(OUT / 'neuro_facility_2022_2025_coverage.csv', index=False)
    pf = period.groupby(['measure', 'sex', 'identified_years']).size().rename('facilities').reset_index()
    pf.to_csv(OUT / 'neuro_2022_2025_coverage_frequency.csv', index=False)
    return annual


def legacy_reconciliation(monthly_raw, monthly_new):
    records = []
    legacy = pd.read_csv(DERIVED / 'rem/rem_long.csv.gz', dtype={'code': str})
    legacy = legacy[legacy.code.isin(CODES)]
    for label, codes in MEASURE_CODES.items():
        serie = CODES[codes[0]][0]
        a = monthly_raw[monthly_raw.code.isin(codes)]
        b = monthly_new[monthly_new.code.isin(codes)]
        l = legacy[legacy.code.isin(codes)]
        if serie == 'P':
            a, b, l = a[a.month.eq(12)], b[b.month.eq(12)], l[l.month.eq(12)]
        for sex, es in [('Men', 'Hombre'), ('Women', 'Mujer')]:
            for age_group, labels in [('all_ages', ['Total']), ('60+', ['60-64', '65-69', '70-74', '75-79', '80+'])]:
                aa = a[a.sex.eq(sex) & a.age_group.eq(age_group)].groupby('year').legacy_blank_zero_value.sum()
                bb = b[b.sex.eq(sex) & b.age_group.eq(age_group)].groupby('year').legacy_blank_zero_value.sum()
                ll = l[l.sex.eq(es) & l.age.isin(labels)].groupby('year').value.sum()
                for year in YEARS:
                    raw_n, clean_n, old_n = aa.get(year, 0), bb.get(year, 0), ll.get(year, 0)
                    records.append({'year': year, 'measure': label, 'sex': sex, 'age_group': age_group,
                                    'original_raw_blank_zero_sum': raw_n, 'legacy_rem_long_sum': old_n,
                                    'raw_minus_legacy': raw_n - old_n, 'deduplicated_quarantined_blank_zero_sum': clean_n,
                                    'deduplication_or_quarantine_delta': clean_n - raw_n})
    result = pd.DataFrame(records)
    result.to_csv(OUT / 'neuro_legacy_reconciliation.csv', index=False)
    return result


def main():
    started = time.time()
    OUT.mkdir(parents=True, exist_ok=True)
    PRIVATE.mkdir(parents=True, exist_ok=True)
    accounting_self_check()
    proof_path = OUT / 'neuro_dictionary_mapping.json'
    proof = json.loads(proof_path.read_text()) if proof_path.exists() else dictionary_audit()
    assert proof['status'] == 'pass' and proof['verified_records'] == 49
    monthly, original_monthly, locations, audits, quarantined = [], [], [], [], []
    for year in YEARS:
        for serie in ['A', 'P']:
            z, original, quarantine, loc, audit = clean_source(year, serie)
            audits.append(audit)
            locations.append(loc)
            monthly.append(decode(z))
            original_monthly.append(decode(original))
            quarantined.append(quarantine)
    monthly = pd.concat(monthly, ignore_index=True)
    raw_monthly = pd.concat(original_monthly, ignore_index=True)
    denom, den_sources = prepare_denominators()
    universe = frame_locations(locations, denom)
    universe.to_csv(OUT / 'neuro_facility_year_universe.csv', index=False)
    frames = [annual_aggregate(monthly, universe, codes, 'all_stages') for codes in MEASURE_CODES.values()]
    facility = pd.concat(frames, ignore_index=True)
    facility = facility.merge(universe, on=['year', 'estab'], how='left').merge(denom, on=KEY, how='left')
    facility['denominator_status'] = np.where(facility.enrolled.gt(0), 'same_year_snapshot_positive', np.where(facility.enrolled.eq(0), 'same_year_snapshot_zero', 'missing_or_age_band_unavailable'))
    facility['denominator_unit'] = 'December FONASA enrolled-person snapshot; not individual follow-up time'
    facility['count_per_1000_enrolled'] = (1000 * facility.count_complete_identified / facility.enrolled).where(facility.enrolled.gt(0))
    facility.to_csv(OUT / 'neuro_facility_year.csv.gz', index=False)
    print('Association-ready file written: ' + str(OUT / 'neuro_facility_year.csv.gz'), flush=True)
    annual = summaries(facility)
    stage_frames = [annual_aggregate(monthly, universe, [code], CODES[code][3]) for code in CODES]
    stages = pd.concat(stage_frames, ignore_index=True)
    stages.to_csv(OUT / 'neuro_stage_facility_year.csv.gz', index=False)
    monthly.to_csv(PRIVATE / 'neuro_monthly_identification.csv.gz', index=False)
    pd.concat(quarantined, ignore_index=True).to_csv(PRIVATE / 'neuro_quarantined_source_rows.csv.gz', index=False)
    legacy = legacy_reconciliation(raw_monthly, monthly)
    pd.DataFrame(audits).to_csv(OUT / 'neuro_raw_presence_qc.csv', index=False)
    row_status = monthly.groupby(['year', 'serie', 'code', 'sex', 'age_group', 'value_status']).size().rename('rows').reset_index()
    row_status.to_csv(OUT / 'neuro_monthly_value_status.csv', index=False)
    assert facility.loc[facility.complete_identified, 'count_complete_identified'].notna().all()
    assert facility.absent_component_months.ge(0).all()
    assert monthly.loc[monthly.value_status.ne('conflict'), 'lower_bound'].dropna().ge(0).all()
    metadata = {
        'language': 'en', 'created': '2026-10-29', 'runtime': {'python': platform.python_version(), 'pandas': pd.__version__, 'numpy': np.__version__},
        'elapsed_seconds': time.time() - started, 'sources': audits + den_sources,
        'dictionary_audit': str(proof_path.relative_to(ROOT)), 'dictionary_audit_sha256': sha(proof_path),
        'shared_raw_source_audit': 'outputs/access_diagnostic_extension_2026-10-29/rem/raw_source_audit.json',
        'script_sha256': sha(Path(__file__)), 'private_monthly': str(PRIVATE / 'neuro_monthly_identification.csv.gz'),
        'association_ready': str((OUT / 'neuro_facility_year.csv.gz').relative_to(ROOT)),
        'grain': 'establishment x year x sex x age_group x measure; all_stages in the association-ready file',
        'join_fields': ['estab', 'year'], 'sex_values': ['Women', 'Men'], 'age_groups': list(GROUPS),
        'observation_units': {'dementia_entries': 'A05 annual entry records summed over observed months', 'dementia_caseload': 'P6 December stock', 'parkinson_caseload': 'P3 December stock'},
        'accounting': 'For exhaustive17nonnegativeagecells, R=reported sex total minus sum of known ages. A band is exact if all target cells are numeric, R=0, or all missing ages lie within the band. Other cases retain nonnegative bounds; conflicting totals are quarantined from complete counts. No other-sex or other-month inference is used.',
        'primary_count': 'count_complete_identified requires every expected code-month row (36 for annual3-stageA05;3 for December3-stageP6;1 for P3), all row values identified and no conflict. Absent rows/months/stages remain missing, not zero.',
        'lower_bounds': 'count_lower_bound sums exact identified values and lower bounds from observed rows only. It is not a complete annual disease count and is not used automatically to form a rate.',
        'zero_fields': 'raw_numeric_zero_component_months and accounting_zero_component_months remain separate. Blank target cells and absent code-month rows are retained separately.',
        'duplicates': 'Remove identical entire source rows, then quarantine all nonidentical records sharing year/month/establishment/code. Do not select max/latest.',
        'denominators': 'Existing facility FONASA snapshot counts independently reconciled against same-year raw December files.60-79/80+/60+ are exact across2019-2025;60-69/70-79 are exact only from2024. All-age enrolment includes unknown-age records with known sex;60+ excludes unknown ages. No age prorating is used.',
        'location': 'Unique municipality from shared selected raw rows in the same facility/year; catalogue fallback only when no selected raw row exists. Conflicting raw municipalities remain unassigned.',
        'universe': 'Union of establishments in selected raw REM caches and establishments with recorded sex-specific FONASA denominators in each year; not the complete national provider network.',
        'legacy_max_raw_minus_legacy': float(legacy.raw_minus_legacy.abs().max()),
        'reproduce': ['python3 scripts/access_extension/rem_extract.py', 'python3 scripts/access_extension/neuro_dictionary_audit.py', 'python3 scripts/access_extension/neuro_prepare.py'],
        'limits': ['Recorded programme activity is not incidence or diagnostic delay.', 'Annual A05 counts and repeated December stocks are not unique-person follow-up.', 'Missing reporting cannot be excluded by an explicit zero or accounting zero.', 'Analysis of complete providers is selected; it does not establish population prevalence or treatment effects.']}
    text = json.dumps(metadata, ensure_ascii=False, indent=2)
    for a, b in [('exhaustive17nonnegativeagecells', 'exhaustive 17 nonnegative age cells'), ('annual3-stageA05', 'annual 3-stage A05'), ('December3-stageP6', 'December 3-stage P6'), ('across2019', 'across 2019'), ('from2024', 'from 2024'), ('files.60', 'files. 60')]:
        text = text.replace(a, b)
    (OUT / 'neuro_preparation_metadata.json').write_text(text + '\n')
    print(json.dumps({'status': 'complete', 'facility_rows': len(facility), 'stage_rows': len(stages), 'monthly_rows': len(monthly),
                      'raw_legacy_max_difference': metadata['legacy_max_raw_minus_legacy'], 'elapsed_seconds': metadata['elapsed_seconds']}))
    print(annual[annual.age_group.eq('60+')][['year', 'measure', 'sex', 'facilities_complete_identified', 'facilities_complete_with_enrolment']].to_string(index=False))


if __name__ == '__main__':
    main()
