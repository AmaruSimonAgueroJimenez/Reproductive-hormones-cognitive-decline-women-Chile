"""Independent public-aggregate checks, with an optional original-cell reconciliation."""
from pathlib import Path
import argparse,hashlib,json,platform,sys
import numpy as np
import pandas as pd
import matplotlib
from PIL import Image

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(Path(__file__).parent))
from rem_extract import OUT,PRIVATE,DATA
CORE={'P1030301':'care','P1060040':'mrs_assessed','P1060050':'mrs_high','P1060060':'mht'}

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def reference(path):
 path=Path(path)
 try:name=str(path.relative_to(ROOT))
 except ValueError:name=str(path)
 return {'path':name,'bytes':path.stat().st_size,'sha256':sha(path)}
def validate(with_raw=False):
 checks=[]
 def check(name,condition,detail=None):
  checks.append({'check':name,'passed':bool(condition),'detail':detail})
  assert condition,name
 w=pd.read_csv(OUT/'facility_year_hormonal_care.csv')
 n=pd.read_csv(OUT/'p1_national_recording.csv')
 s=pd.read_csv(OUT/'p1_source_status_by_year.csv')
 check('Unique facility-year primary-care observations',not w.duplicated(['year','estab']).any())
 check('All seven expected source years represented',set(w.year)==set(range(2019,2026)))
 for _,z in n.iterrows():
  frame=w[w.year.eq(z.year)];metric=z.metric
  check(f'P1 national reconciliation: {int(z.year)} {metric}',np.isclose(frame[metric].sum(min_count=1),z.all_numeric_recorded_count))
  matched=frame[frame[metric].notna()&frame.estimated_enrolled_women_45_64.gt(0)]
  check(f'Matched numerator/denominator: {int(z.year)} {metric}',np.isclose(matched[metric].sum(min_count=1),z.matched_count)&np.isclose(matched.estimated_enrolled_women_45_64.sum(),z.matched_estimated_enrolment))
  eligible=frame[frame.estimated_enrolled_women_45_64.gt(0)]
  states=s[s.year.eq(z.year)&s.metric.eq(metric)&s.universe.eq('Positive FONASA denominator')]
  check(f'Status partition: {int(z.year)} {metric}',states.facilities.sum()==len(eligible))
  check(f'Source states match numeric visibility: {int(z.year)} {metric}',frame.loc[frame[metric+'_status'].eq('explicit_zero'),metric].eq(0).all()&frame.loc[frame[metric+'_status'].isin(['absent_row','blank_cell']),metric].isna().all())
 check('No numeric infill for not-in-template 2025 histories',w.loc[w.year.lt(2025),['mrs_entry','mrs_followup','mrs_improved_low']].isna().all().all())
 r=pd.read_csv(OUT/'mrs_context_matched_ratios.csv')
 check('Published MRS paired ratios reconcile to counts',np.allclose(r.high_per100_applications,100*r.high/r.applications))
 check('Screened MRS ratios reconcile and lie within bounds',np.allclose(r.screened_high_per100,100*r.screened_high/r.screened_applications)&r.screened_high_per100.between(0,100).all())
 q=pd.read_csv(OUT/'a29_age_modality_consistency.csv')
 check('Complete diagnostic-service age sets agree with totals',q.complete_age_sum_disagrees.eq(0).all())
 check('No known partial diagnostic age sum exceeds total',q.known_partial_age_sum_exceeds_total.eq(0).all())
 q25=q[q.year.eq(2025)].set_index('metric')
 check('2025 applicable modalities distinguish structural cells',q25.loc['gyn_climacteric','applicable_mode_columns']==4 and q25.loc[['fsh_climacteric','ultrasound_climacteric'],'applicable_mode_columns'].eq(2).all())
 proof=json.loads((OUT/'dictionary_audit/annual_mapping_proof.json').read_text())
 for code in ['29101712','29101713']:
  row=next(x for x in proof['records'] if x['year']==2025 and x['code']==code)
  cells={x['value']:x for x in row['data_cells']}
  check(f'Template structural remote cells: {code}',all(cells[c].get('locked') and cells[c].get('fill_colour')==22 for c in ['COL06','COL08']))
 old=pd.read_csv(OUT/'legacy_p1_comparison.csv');changed=old[old.difference.ne(0)]
 check('Only documented exact-duplicate core corrections',len(changed)==4 and changed.year.eq(2021).all() and dict(zip(changed.metric,changed.difference))=={'care':-53,'mrs_assessed':-10,'mrs_high':-5,'mht':-2})
 content=json.loads((OUT/'rem_report_content.json').read_text())
 check('All requested English content sections and artifacts exist',content['language']=='en' and len(content['methods'])>0 and len(content['results'])>0 and len(content['figures'])==3 and all(Path(x['csv_path']).exists() for x in content['tables']))
 for figure in content['figures']:
  for path in figure['formats'].values():check('Figure format exists: '+Path(path).name,Path(path).exists())
  im=Image.open(figure['path']);dpi=im.info.get('dpi',(0,0))
  check('Figure raster has 600 dpi: '+Path(figure['path']).name,min(dpi)>599 and im.width>=4200,{'pixels':list(im.size),'dpi':list(dpi)})
 raw_checks=[]
 if with_raw:
  for year in range(2019,2026):
   d=pd.read_csv(PRIVATE/f'raw_selected_P_{year}.csv.gz',dtype=str,keep_default_na=False).drop_duplicates()
   key=list(d.columns[:5]);d=d[~d.duplicated(key,keep=False)];d=d[d.Mes.eq('12')]
   col='Col02' if year==2025 else 'Col01'
   for code,metric in CORE.items():
    value=pd.to_numeric(d.loc[d.CodigoPrestacion.eq(code),col],errors='coerce').sum(min_count=1)
    expected=n[n.year.eq(year)&n.metric.eq(metric)].all_numeric_recorded_count.iloc[0]
    check(f'Original cached source-cell P1 reconciliation: {year} {metric}',np.isclose(value,expected))
   raw_checks.append(reference(PRIVATE/f'raw_selected_P_{year}.csv.gz'))
  d=pd.read_csv(PRIVATE/'raw_selected_A_2025.csv.gz',dtype=str,keep_default_na=False).drop_duplicates();d=d[~d.duplicated(list(d.columns[:5]),keep=False)]
  a=pd.read_csv(OUT/'annual_activity_counts.csv',dtype={'code':str})
  for code in ['29101711','29101712','29101713']:
   x=a[a.year.eq(2025)&a.code.eq(code)&a.age_scope.eq('45-64')&a.context.eq('age_specific')].recorded_count.iloc[0]
   check('Original 2025 A29 age45–64 source reconciliation: '+code,np.isclose(pd.to_numeric(d.loc[d.CodigoPrestacion.eq(code),'Col03'],errors='coerce').sum(min_count=1),x))
  raw_checks.extend(reference(p) for p in sorted(PRIVATE.glob('raw_selected_A_*.csv.gz')))
 input_names=['facility_year_hormonal_care.csv','annual_activity_counts.csv','facility_year_activity_counts.csv','mrs_context_matched_ratios.csv','p1_national_recording.csv','p1_source_status_by_year.csv','p1_2025_new_rows.csv','p1_consistency_screens.csv','legacy_p1_comparison.csv','a29_age_modality_consistency.csv','dictionary_audit/annual_mapping_proof.json']
 geo=ROOT/'outputs/paper/revision_descriptiva_2026-10-28/source_data/geo'
 inputs=[reference(OUT/name) for name in input_names]+[reference(geo/name) for name in ['regions.geojson','comunas_rm.geojson']]
 scripts=[reference(p) for p in sorted((ROOT/'scripts/access_extension').glob('rem_*.py'))]+[reference(ROOT/'scripts/paper/p18_descriptive_review_figures.py')]
 outputs=[reference(p) for p in sorted(OUT.glob('table_*_en.csv'))]+[reference(Path(f['path'])) for f in content['figures']]+[reference(OUT/'rem_report_content.json')]
 payload={'passed':all(x['passed'] for x in checks),'checks':checks,'software':{'python':platform.python_version(),'pandas':pd.__version__,'numpy':np.__version__,'matplotlib':matplotlib.__version__},'public_inputs':inputs,'scripts':scripts,'public_outputs':outputs,'private_cache_hashes_checked':raw_checks,'source_dictionary_hashes':proof['files'],'source_raw_file_signatures':json.loads((OUT/'raw_source_audit.json').read_text()),'commands':{'public_only':['python3 scripts/access_extension/rem_tables_figures.py','python3 scripts/access_extension/rem_report_content.py','python3 scripts/access_extension/rem_validate.py'],'raw_refresh':['python3 scripts/access_extension/rem_dictionary_audit.py','python3 scripts/access_extension/rem_extract.py','python3 scripts/access_extension/rem_analyze.py','python3 scripts/access_extension/rem_tables_figures.py','python3 scripts/access_extension/rem_report_content.py','python3 scripts/access_extension/rem_validate.py --with-raw']},'hash_scope':'SHA-256 of public aggregate inputs, scripts, rendered PNGs, English content/tables, source dictionaries and optional selected raw-cell caches; full original raw files retain byte/mtime signatures rather than a full-file hash. Byte-identical output is expected only within the same software and font environment.'}
 target=OUT/('rem_validation_raw.json' if with_raw else 'rem_validation_public.json')
 target.write_text(json.dumps(payload,indent=2,ensure_ascii=False))
 print(json.dumps({'passed':payload['passed'],'checks':len(checks),'with_raw':with_raw,'report':str(target)},indent=2))
 return payload
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--with-raw',action='store_true');a=p.parse_args();validate(a.with_raw)
