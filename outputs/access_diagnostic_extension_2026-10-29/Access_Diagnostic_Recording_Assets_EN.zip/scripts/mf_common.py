"""Utilidades del análisis multifuente: rutas, códigos, edades, tasas y E/S.

Todos los scripts `mf*.py` y `paper/p*.py` importan este módulo.

Rutas
-----
* ASESORIAS_DATA_ROOT  raíz de los datos (por defecto /Volumes/Datos/Asesorias_Data).
* AUTISM_DATA_ROOT     carpeta con INE, SAE y encuestas (por defecto <raíz>/Autism).
* MF_DERIVED           intermedios con nivel de registro (por defecto
                       <raíz>/derived/Reproductive-hormones-cognitive-decline-women-Chile).
Los intermedios con identificadores o registros individuales nunca se escriben en el
repositorio; en `outputs/` solo quedan agregados.
"""
from __future__ import annotations

import os
import re
import sys
import time
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

REPO = Path(__file__).resolve().parents[1]
CONFIG = REPO / "config"
DATA_ROOT = Path(os.environ.get("ASESORIAS_DATA_ROOT", "/Volumes/Datos/Asesorias_Data"))
AUTISM_ROOT = Path(os.environ.get("AUTISM_DATA_ROOT", str(DATA_ROOT / "Autism")))
DERIVED = Path(os.environ.get(
    "MF_DERIVED", str(DATA_ROOT / "derived" / "Reproductive-hormones-cognitive-decline-women-Chile")))

OUT = REPO / "outputs" / "multifuente"
TAB = OUT / "tables"
FIG = OUT / "figures"
CTRL = OUT / "controls"
PAPER = REPO / "outputs" / "paper"

SRC = {
    "deaths_official": DATA_ROOT / "DEIS" / "Defunciones" / "defunciones_1990_2023_oficiales.csv",
    "deaths_prelim": DATA_ROOT / "DEIS" / "Defunciones" / "defunciones_2024_2026_preliminares_corte_2026-06-23.csv",
    "egresos": DATA_ROOT / "DEIS" / "Egresos",
    "grd": DATA_ROOT / "GRD",
    "rem_a": DATA_ROOT / "REM" / "SerieA",
    "rem_p": DATA_ROOT / "REM" / "SerieP",
    "fonasa_aps": DATA_ROOT / "FONASA" / "APS",
    "ine_comuna": AUTISM_ROOT / "Poblacion" / "INE" / "proyecciones_comuna_edad_sexo_2002_2035_base_2017.csv",
    "ine_urban": AUTISM_ROOT / "Poblacion" / "INE" / "proyecciones_comuna_area_urbana_rural_2002_2035_base_2017.csv",
    "ine_national": AUTISM_ROOT / "Poblacion" / "INE" / "Base_2024" / "estimaciones_proyecciones_nacionales_1992_2070_base_2024.xlsx",
    "sae_income": AUTISM_ROOT / "Territorio" / "SAE_2024" / "SAE_ingresos_2024.xlsx",
    "sae_multi": AUTISM_ROOT / "Territorio" / "SAE_2024" / "SAE_multidimensional_2024.xlsx",
    "estab_catalog": DATA_ROOT / "DEIS" / "metadata" / "establecimientos_deis.csv",
    "estab_vigentes": AUTISM_ROOT / "DEIS" / "Establecimientos" / "establecimientos_salud_vigentes.csv",
    "regions_shp": Path(os.environ.get("REGIONS_SHP", str(REPO.parent / "Autism-spectrum-disorder-Chile" / "data" / "Regional.shp"))),
    "comunas_shp": Path(os.environ.get("COMUNAS_SHP", str(REPO.parent / "Autism-spectrum-disorder-Chile" / "data" / "comunas.shp"))),
    "casen": AUTISM_ROOT / "Encuestas" / "CASEN_2024" / "casen_2024.dta",
    "encavi": AUTISM_ROOT / "Encuestas" / "ENCAVI_2023_2024" / "ENCAVI_2023_2024.dta",
}

SEXES = ["Mujer", "Hombre"]


# ------------------------------------------------------------------ configuración y E/S
def load_yaml(name: str) -> dict:
    with open(CONFIG / name, encoding="utf-8") as f:
        return yaml.safe_load(f)


OUTCOMES = load_yaml("neuro_outcomes.yaml")
GROUPS: dict = OUTCOMES["groups"]
CORE: list[str] = OUTCOMES["core"]
YEARS: dict = OUTCOMES["years"]


def ensure_dirs() -> None:
    for d in (TAB, FIG, CTRL, PAPER / "tables", PAPER / "figures", DERIVED):
        d.mkdir(parents=True, exist_ok=True)


def derived(sub: str) -> Path:
    p = DERIVED / sub
    p.mkdir(parents=True, exist_ok=True)
    return p


_T0 = time.time()


def log(step: str, msg: str) -> None:
    line = f"[{time.strftime('%H:%M:%S')} +{time.time() - _T0:6.1f}s] {step}: {msg}"
    print(line, flush=True)
    try:
        CTRL.mkdir(parents=True, exist_ok=True)
        with open(CTRL / "run_log.txt", "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def save(df: pd.DataFrame, name: str, where: Path = TAB, index: bool = False) -> Path:
    """Escribe CSV (sobrescribe en el lugar; no usa renombres atómicos)."""
    where.mkdir(parents=True, exist_ok=True)
    path = where / name
    df.to_csv(path, index=index)
    return path


def load(name: str, where: Path = TAB, **kw) -> pd.DataFrame | None:
    path = where / name
    return pd.read_csv(path, **kw) if path.exists() else None


def need(path: Path, step: str) -> bool:
    if not Path(path).exists():
        log(step, f"AVISO fuente ausente, se omite: {path}")
        return False
    return True


def years_arg(default: list[int]) -> list[int]:
    """Lee --years 2019 2020 ... o --years 2019-2024 de sys.argv."""
    if "--years" not in sys.argv:
        return default
    vals = sys.argv[sys.argv.index("--years") + 1:]
    out: list[int] = []
    for v in vals:
        if v.startswith("--"):
            break
        if "-" in v:
            a, b = v.split("-")
            out += list(range(int(a), int(b) + 1))
        else:
            out.append(int(v))
    return out


def flag(name: str) -> bool:
    return name in sys.argv


# ------------------------------------------------------------------ códigos CIE
def norm_code(s: pd.Series) -> pd.Series:
    """'F03.9 ' -> 'F039'; valores nulos -> ''."""
    return s.fillna("").astype(str).str.upper().str.replace(r"[^A-Z0-9]", "", regex=True)


def group_regex(codes: list[str]) -> str:
    return r"\|(?:" + "|".join(sorted({c.replace('.', '') for c in codes}, key=len, reverse=True)) + ")"


def flag_joined(joined: pd.Series, codes: list[str]) -> pd.Series:
    """`joined` = '|' + códigos normalizados unidos por '|'. True si algún código calza por prefijo."""
    return joined.str.contains(group_regex(codes), regex=True)


def flag_single(code: pd.Series, codes: list[str]) -> pd.Series:
    return code.str.startswith(tuple(c.replace('.', '') for c in codes))


def group_label(g: str, lang: str = "es") -> str:
    return GROUPS[g].get(f"label_{lang}", g)


# ------------------------------------------------------------------ edad y territorio
AGE5_85 = [f"{a}-{a+4}" for a in range(0, 85, 5)] + ["85+"]
AGE5_80 = [f"{a}-{a+4}" for a in range(0, 80, 5)] + ["80+"]
ONSET = [c["label"] for c in OUTCOMES["onset"]["classes"]]


def age5(age: pd.Series, top: int = 85) -> pd.Series:
    labels = AGE5_85 if top == 85 else AGE5_80
    bins = list(range(0, top + 1, 5)) + [300]
    return pd.cut(np.floor(pd.to_numeric(age, errors="coerce")), bins=bins, right=False, labels=labels)


def onset_class(age: pd.Series) -> pd.Series:
    bins = [-1] + [c["hi"] for c in OUTCOMES["onset"]["classes"]]
    return pd.cut(np.floor(pd.to_numeric(age, errors="coerce")), bins=bins, labels=ONSET)


def band_to_onset(band: pd.Series) -> pd.Series:
    """Tramo quinquenal ('45-49', '80+') → clase de inicio, usando el límite inferior del tramo."""
    lo = pd.to_numeric(band.astype(str).str.extract(r"(\d+)")[0], errors="coerce")
    return onset_class(lo)


def region13(comuna_code: pd.Series) -> pd.Series:
    """Región armonizada (13 regiones previas a 2007): Arica→1, Los Ríos→10, Ñuble→8.

    Funciona con códigos comunales antiguos y nuevos porque solo usa los miles.
    """
    r = pd.to_numeric(comuna_code, errors="coerce") // 1000
    return r.replace({15: 1, 14: 10, 16: 8})


REGION13_NAMES = {
    1: "Tarapacá (incl. Arica y Parinacota)", 2: "Antofagasta", 3: "Atacama", 4: "Coquimbo",
    5: "Valparaíso", 6: "O'Higgins", 7: "Maule", 8: "Biobío (incl. Ñuble)", 9: "La Araucanía",
    10: "Los Lagos (incl. Los Ríos)", 11: "Aysén", 12: "Magallanes", 13: "Metropolitana",
}


def norm_name(s) -> str:
    s = unicodedata.normalize("NFKD", str(s)).encode("ascii", "ignore").decode().upper()
    return re.sub(r"\s+", " ", re.sub(r"[^A-Z ]", " ", s)).strip()


COMUNA_ALIASES = {"AISEN": "AYSEN", "COIHAIQUE": "COYHAIQUE", "CON CON": "CONCON",
                  "CABO DE HORNOS EX NAVARINO": "CABO DE HORNOS", "PAIGUANO": "PAIHUANO",
                  "TREGUACO": "TREHUACO", "LLAY LLAY": "LLAILLAY", "O HIGGINS": "OHIGGINS"}


def comuna_lookup() -> dict[str, int]:
    """Nombre normalizado → código comunal INE (base 2017)."""
    ine = pd.read_csv(SRC["ine_comuna"], encoding="latin-1", usecols=[4, 5]).drop_duplicates()
    ine.columns = ["code", "name"]
    lk = {norm_name(n): int(c) for c, n in zip(ine.code, ine.name)}
    for a, b in COMUNA_ALIASES.items():
        if b in lk:
            lk[a] = lk[b]
    return lk


def map_comuna(names: pd.Series, lk: dict[str, int] | None = None) -> pd.Series:
    lk = lk or comuna_lookup()
    uniq = pd.Series(names.dropna().unique())
    m = {u: lk.get(COMUNA_ALIASES.get(norm_name(u), norm_name(u))) for u in uniq}
    return names.map(m)


def sex_std(s: pd.Series) -> pd.Series:
    """Armoniza sexo a 'Mujer'/'Hombre' (acepta 1/2, H/M de INE 2024, textos)."""
    t = s.astype(str).str.strip().str.upper()
    out = pd.Series(pd.NA, index=s.index, dtype="object")
    out[t.isin(["2", "2.0", "MUJER", "MUJERES", "F", "FEMENINO"])] = "Mujer"
    out[t.isin(["1", "1.0", "HOMBRE", "HOMBRES", "H", "MASCULINO"])] = "Hombre"
    return out


# ------------------------------------------------------------------ tasas
WHO_STD = {  # población estándar OMS 2000-2025 (por 100.000)
    "0-4": 8860, "5-9": 8690, "10-14": 8600, "15-19": 8470, "20-24": 8220, "25-29": 7930,
    "30-34": 7610, "35-39": 7150, "40-44": 6590, "45-49": 6040, "50-54": 5370, "55-59": 4550,
    "60-64": 3720, "65-69": 2960, "70-74": 2210, "75-79": 1520, "80-84": 910, "85+": 635,
}
WHO_STD_80 = {**{k: v for k, v in WHO_STD.items() if k not in ("80-84", "85+")}, "80+": 1545}


def poisson_ci(k, alpha: float = 0.05):
    """IC exacto (Garwood) para un conteo Poisson; acepta escalares o arreglos."""
    from scipy.stats import chi2
    k = np.asarray(k, dtype=float)
    lo = np.where(k > 0, chi2.ppf(alpha / 2, 2 * k) / 2, 0.0)
    hi = chi2.ppf(1 - alpha / 2, 2 * (k + 1)) / 2
    return lo, hi


def add_rate(df: pd.DataFrame, cases: str = "n", pop: str = "pop", per: float = 1e5,
             prefix: str = "rate") -> pd.DataFrame:
    d = df.copy()
    lo, hi = poisson_ci(d[cases].to_numpy())
    p = d[pop].to_numpy(dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        d[prefix] = d[cases] / p * per
        d[f"{prefix}_lo"] = lo / p * per
        d[f"{prefix}_hi"] = hi / p * per
    return d


def dsr(d: pd.DataFrame, cases: str = "n", pop: str = "pop", age: str = "age5",
        std: dict | None = None, per: float = 1e5) -> pd.Series:
    """Tasa estandarizada directa con IC gamma (Fay-Feuer). `d` tiene una fila por grupo de edad."""
    from scipy.stats import chi2
    std = std or WHO_STD
    x = d[d[age].astype(str).isin(std.keys()) & (d[pop] > 0)]
    w = x[age].astype(str).map(std).astype(float)
    w = w / w.sum()
    r = x[cases] / x[pop]
    est = float((w * r).sum())
    var = float((w ** 2 * x[cases] / x[pop] ** 2).sum())
    wm = float((w / x[pop]).max())
    n = float(x[cases].sum())
    if est <= 0 or var <= 0:
        return pd.Series({"n": n, "dsr": 0.0, "dsr_lo": 0.0, "dsr_hi": np.nan, "dsr_var": var * per**2})
    lo = var / (2 * est) * chi2.ppf(0.025, 2 * est ** 2 / var)
    hi = (var + wm ** 2) / (2 * (est + wm)) * chi2.ppf(0.975, 2 * (est + wm) ** 2 / (var + wm ** 2))
    return pd.Series({"n": n, "dsr": est * per, "dsr_lo": lo * per, "dsr_hi": hi * per,
                      "dsr_var": var * per ** 2})


def ratio_ci(r1, v1, r2, v2):
    """Razón de tasas r1/r2 con IC por método log (varianzas de las tasas)."""
    r1, v1, r2, v2 = (np.asarray(x, dtype=float) for x in (r1, v1, r2, v2))
    with np.errstate(divide="ignore", invalid="ignore"):
        rr = r1 / r2
        se = np.sqrt(v1 / r1 ** 2 + v2 / r2 ** 2)
        return rr, rr * np.exp(-1.96 * se), rr * np.exp(1.96 * se)


def count_ratio_ci(n1, p1, n2, p2):
    """Razón de tasas crudas (n1/p1)/(n2/p2) con IC log-normal."""
    n1, p1, n2, p2 = (np.asarray(x, dtype=float) for x in (n1, p1, n2, p2))
    with np.errstate(divide="ignore", invalid="ignore"):
        rr = (n1 / p1) / (n2 / p2)
        se = np.sqrt(1 / n1 + 1 / n2)
        return rr, rr * np.exp(-1.96 * se), rr * np.exp(1.96 * se)


def poisson_trend(d: pd.DataFrame, cases: str = "n", pop: str = "pop", year: str = "year",
                  adjust: list[str] | None = None) -> pd.Series:
    """Cambio porcentual anual (APC) por regresión de Poisson con offset y ajuste opcional.

    Usa dispersión estimada por Pearson (cuasi-Poisson) para no subestimar el IC.
    """
    import statsmodels.api as sm
    import statsmodels.formula.api as smf
    x = d[(d[pop] > 0)].copy()
    if x[cases].sum() < 10 or x[year].nunique() < 3:
        return pd.Series({"apc": np.nan, "apc_lo": np.nan, "apc_hi": np.nan, "p": np.nan})
    x["_off"] = np.log(x[pop])
    rhs = " + ".join([year] + [f"C({a})" for a in (adjust or [])])
    m = smf.glm(f"{cases} ~ {rhs}", data=x, family=sm.families.Poisson(), offset=x["_off"]).fit(scale="X2")
    b, se = m.params[year], m.bse[year]
    return pd.Series({"apc": 100 * (np.exp(b) - 1), "apc_lo": 100 * (np.exp(b - 1.96 * se) - 1),
                      "apc_hi": 100 * (np.exp(b + 1.96 * se) - 1), "p": m.pvalues[year]})


def fmt_ci(est, lo, hi, digits: int = 2) -> str:
    if pd.isna(est):
        return ""
    return f"{est:.{digits}f} ({lo:.{digits}f}-{hi:.{digits}f})"


# ------------------------------------------------------------------ población
def pop_national() -> pd.DataFrame:
    """Población nacional a mitad de año por sexo y edad simple 0-100 (INE base 2024)."""
    p = derived("denominators") / "pop_national_single.csv.gz"
    return pd.read_csv(p)


def pop_comuna() -> pd.DataFrame:
    """Población comunal por sexo y edad simple 0-80+ (INE base 2017)."""
    p = derived("denominators") / "pop_comuna_single.csv.gz"
    return pd.read_csv(p)


def pop_age5(pop: pd.DataFrame, by: list[str], top: int = 85) -> pd.DataFrame:
    x = pop.copy()
    x["age5"] = age5(x["age"], top=top).astype(str)
    return x.groupby(by + ["age5"], observed=True)["pop"].sum().reset_index()


def pop_onset(pop: pd.DataFrame, by: list[str]) -> pd.DataFrame:
    x = pop.copy()
    x["onset"] = onset_class(x["age"]).astype(str)
    return x.groupby(by + ["onset"], observed=True)["pop"].sum().reset_index()
