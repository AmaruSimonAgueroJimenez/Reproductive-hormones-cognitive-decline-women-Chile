"""Denominadores y contexto territorial.

Salidas (derived/denominators):
  pop_national_single.csv.gz  año x sexo x edad simple 0-100, INE base 2024 (30 de junio)
  pop_comuna_single.csv.gz    año x comuna x sexo x edad simple 0-80+, INE base 2017 (2002-2026)
  fonasa_aps.csv.gz           inscritos APS por año, comuna, sexo y tramo de edad (FONASA)
Salidas (outputs/multifuente/tables):
  comuna_context.csv          ruralidad, pobreza SAE 2024, mujeres 45-64 y quintiles
  denominators_summary.csv    control de totales nacionales por fuente
"""
from __future__ import annotations

import re

import numpy as np
import pandas as pd

import mf_common as c

STEP = "mf00"


def national() -> pd.DataFrame:
    d = pd.read_excel(c.SRC["ine_national"])
    d.columns = [x.strip().upper() for x in d.columns]
    f = d["FECHA"].astype(str)
    d = d[f.str.startswith("30/6/") | f.str.contains(r"-06-30")].copy()
    d["year"] = d["FECHA"].astype(str).str.extract(r"(\d{4})")[0].astype(int)
    d["sex"] = d["SEXO"].astype(str).str.strip().map({"H": "Hombre", "M": "Mujer"})
    out = d.rename(columns={"EDAD": "age", "POBLACION": "pop"})[["year", "sex", "age", "pop"]]
    out = out[(out.year >= 1992) & (out.year <= 2035)]
    out.to_csv(c.derived("denominators") / "pop_national_single.csv.gz", index=False)
    c.log(STEP, f"nacional base 2024: {len(out):,} filas, {out.year.min()}-{out.year.max()}")
    return out


def comunal() -> pd.DataFrame:
    d = pd.read_csv(c.SRC["ine_comuna"], encoding="latin-1")
    d = d.rename(columns={d.columns[4]: "comuna", d.columns[6]: "sexcode", d.columns[7]: "age"})
    ycols = [x for x in d.columns if x.startswith("Poblacion")]
    long = d.melt(id_vars=["comuna", "sexcode", "age"], value_vars=ycols, var_name="year", value_name="pop")
    long["year"] = long["year"].str.extract(r"(\d{4})")[0].astype(int)
    long = long[long.year <= 2026]
    long["sex"] = long["sexcode"].map({1: "Hombre", 2: "Mujer"})
    long["region"] = long["comuna"] // 1000
    long["region13"] = c.region13(long["comuna"])
    out = long[["year", "region", "region13", "comuna", "sex", "age", "pop"]]
    out.to_csv(c.derived("denominators") / "pop_comuna_single.csv.gz", index=False)
    c.log(STEP, f"comunal base 2017: {len(out):,} filas, {out.comuna.nunique()} comunas")
    return out


def fonasa(lk: dict) -> pd.DataFrame | None:
    frames = []
    for y in range(2019, 2026):
        p = c.SRC["fonasa_aps"] / f"Inscritos_APS_{y}12.csv"
        if not p.exists():
            continue
        try:
            d = pd.read_csv(p, dtype=str, encoding="utf-8")
        except UnicodeDecodeError:
            d = pd.read_csv(p, dtype=str, encoding="latin-1")
        d = d.rename(columns={"TRAMO": "TRAMO_FONASA"})
        d["year"] = y
        d["n"] = pd.to_numeric(d["TOTAL_INSCRITOS"], errors="coerce").fillna(0)
        d["sex"] = c.sex_std(d["SEXO"])
        d["comuna"] = c.map_comuna(d["COMUNA"], lk)
        frames.append(d.groupby(["year", "comuna", "sex", "EDAD_TRAMO", "TRAMO_FONASA"], dropna=False)["n"]
                      .sum().reset_index())
    if not frames:
        c.log(STEP, "AVISO sin archivos FONASA APS")
        return None
    out = pd.concat(frames).rename(columns={"EDAD_TRAMO": "age_band", "TRAMO_FONASA": "tramo"})
    out.to_csv(c.derived("denominators") / "fonasa_aps.csv.gz", index=False)
    miss = out[out.comuna.isna()]["n"].sum() / out["n"].sum()
    c.log(STEP, f"FONASA APS {out.year.min()}-{out.year.max()}; inscritos sin comuna asignada {miss:.2%}")
    return out


def band_bounds(txt: pd.Series) -> pd.DataFrame:
    """'40 a 59 años' -> (40, 59); '80 a más años' -> (80, 200); 'Sin información' -> NaN."""
    nums = txt.astype(str).str.findall(r"\d+")
    lo = nums.map(lambda v: int(v[0]) if len(v) >= 1 else np.nan)
    hi = nums.map(lambda v: int(v[1]) if len(v) >= 2 else (200 if len(v) == 1 else np.nan))
    return pd.DataFrame({"lo": lo, "hi": hi})


def women_45_64_fonasa(fon: pd.DataFrame, pop: pd.DataFrame, lo_t: int = 45, hi_t: int = 64) -> pd.DataFrame:
    """Mujeres 45-64 inscritas en APS. Los tramos FONASA (anchos hasta 2023, decenales desde 2024)
    se prorratean con la estructura por edad simple de la proyección INE de cada comuna y año."""
    w = pop[pop.sex == "Mujer"][["year", "comuna", "age", "pop"]]
    f = fon[fon.sex == "Mujer"].copy()
    f = pd.concat([f.reset_index(drop=True), band_bounds(f["age_band"]).reset_index(drop=True)], axis=1)
    f = f.dropna(subset=["lo", "comuna"])
    f = f.groupby(["year", "comuna", "lo", "hi"])["n"].sum().reset_index()
    rows = []
    for (lo, hi), g in f.groupby(["lo", "hi"]):
        if hi < lo_t or lo > hi_t:
            continue
        ww = w[w.age.between(lo, min(hi, 200))]
        tot = ww.groupby(["year", "comuna"])["pop"].sum()
        tgt = ww[ww.age.between(max(lo, lo_t), min(hi, hi_t))].groupby(["year", "comuna"])["pop"].sum()
        share = (tgt / tot).rename("share").reset_index()
        g = g.merge(share, on=["year", "comuna"], how="left")
        g["part"] = g["n"] * g["share"].fillna(0)
        rows.append(g[["year", "comuna", "part"]])
    out = pd.concat(rows).groupby(["year", "comuna"])["part"].sum().round().rename("women_45_64_aps")
    return out.reset_index()


def sae() -> pd.DataFrame:
    out = []
    for key, col in (("sae_income", "poverty_income"), ("sae_multi", "poverty_multi")):
        d = pd.read_excel(c.SRC[key], header=None)
        hdr = d.index[d.iloc[:, 0].astype(str).str.strip() == "Código"][0]
        d.columns = d.iloc[hdr]
        d = d.iloc[hdr + 1:]
        d = d[pd.to_numeric(d["Código"], errors="coerce").notna()]
        pcol = [x for x in d.columns if str(x).startswith("Porcentaje")][0]
        out.append(pd.DataFrame({"comuna": d["Código"].astype(int), col: pd.to_numeric(d[pcol])}))
    return out[0].merge(out[1], on="comuna", how="outer")


def urban() -> pd.DataFrame:
    d = pd.read_csv(c.SRC["ine_urban"], sep=";", encoding="latin-1")
    d = d.rename(columns={d.columns[4]: "comuna", d.columns[7]: "area"})
    d = d.groupby(["comuna", "area"])["Poblacion 2024"].sum().unstack(fill_value=0)
    return pd.DataFrame({"comuna": d.index, "rural_share": (d[2] / (d[1] + d[2])).values})


def main() -> None:
    c.ensure_dirs()
    if not c.need(c.SRC["ine_comuna"], STEP):
        return
    lk = c.comuna_lookup()
    nat = national() if c.SRC["ine_national"].exists() else None
    pop = comunal()
    fon = fonasa(lk)

    names = pd.read_csv(c.SRC["ine_comuna"], encoding="latin-1", usecols=[0, 1, 4, 5]).drop_duplicates()
    names.columns = ["region", "region_name", "comuna", "comuna_name"]
    ctx = names.copy()
    ctx["region13"] = c.region13(ctx["comuna"])
    p24 = pop[pop.year == 2024]
    ctx = ctx.merge(p24.groupby("comuna")["pop"].sum().rename("pop_2024"), on="comuna", how="left")
    w = p24[(p24.sex == "Mujer") & p24.age.between(45, 64)].groupby("comuna")["pop"].sum().rename("women_45_64_2024")
    ctx = ctx.merge(w, on="comuna", how="left")
    ctx = ctx.merge(urban(), on="comuna", how="left").merge(sae(), on="comuna", how="left")
    ctx["poverty_q"] = pd.qcut(ctx["poverty_multi"], 5, labels=["Q1 (menor)", "Q2", "Q3", "Q4", "Q5 (mayor)"])
    ctx["rural_t"] = pd.cut(ctx["rural_share"], [-0.01, 0.1, 0.4, 1.0], labels=["Urbana (<10%)", "Mixta (10-40%)", "Rural (>40%)"])
    if fon is not None:
        wf = women_45_64_fonasa(fon, pop)
        wf.to_csv(c.derived("denominators") / "fonasa_women_45_64.csv.gz", index=False)
        ctx = ctx.merge(wf[wf.year == 2024].drop(columns="year"), on="comuna", how="left")
    c.save(ctx, "comuna_context.csv")

    rows = [("INE comunal base 2017", 2024, pop[pop.year == 2024]["pop"].sum())]
    if nat is not None:
        rows.append(("INE nacional base 2024", 2024, nat[nat.year == 2024]["pop"].sum()))
    if fon is not None:
        rows.append(("FONASA APS inscritos", 2024, fon[fon.year == 2024]["n"].sum()))
    c.save(pd.DataFrame(rows, columns=["source", "year", "total"]), "denominators_summary.csv", c.CTRL)
    c.log(STEP, f"contexto comunal: {len(ctx)} comunas; pobreza SAE faltante {ctx.poverty_multi.isna().sum()}")


if __name__ == "__main__":
    main()
