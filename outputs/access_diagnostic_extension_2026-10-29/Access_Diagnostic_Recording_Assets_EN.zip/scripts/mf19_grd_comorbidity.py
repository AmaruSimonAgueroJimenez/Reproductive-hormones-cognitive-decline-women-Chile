"""GRD 2019-2024 (hospitales públicos): episodios de personas de 45 años o más con todos sus
diagnósticos, insumo de la red de comorbilidades (mf20).

Guarda en derived/grd_dx (nunca en el repositorio, porque incluye el identificador encriptado):
  grd_dx_{año}.parquet  un registro por episodio: id, año, sexo, edad, fecha de ingreso, días de
                        estada, tipo de actividad, tipo de ingreso, condición al alta, hospital,
                        diagnóstico principal y la cadena de los 35 diagnósticos normalizados
                        ('|A|B|...|', CIE-10 sin punto).
Acepta GRD_PUBLICO_{año}.csv o .csv.gz. El identificador de paciente es CIP_ENCRIPTADO hasta 2020 e
ID_BENEFICIARIO desde 2021; solo es comparable entre años desde 2021.

Uso: python scripts/mf19_grd_comorbidity.py [--years 2019-2024] [--skip-existing]
"""
from __future__ import annotations

import numpy as np
import pandas as pd

import mf_common as c

STEP = "mf19"
MIN_AGE = 45
INVALID_ID = {"", "0", "-1", "NA", "NAN", "NULL", "DESCONOCIDO", "SIN INFORMACION", "SIN INFORMACIÓN"}


def source(y: int):
    for ext in (".csv", ".csv.gz"):
        p = c.SRC["grd"] / f"GRD_PUBLICO_{y}{ext}"
        if p.exists():
            return p
    return None


def parse_dates(v: pd.Series) -> pd.Series:
    v = v.astype("string").str.strip()
    iso = pd.to_datetime(v, format="%Y-%m-%d", errors="coerce")
    return iso.fillna(pd.to_datetime(v, format="%d-%m-%Y", errors="coerce"))


def one_year(y: int) -> None:
    path = source(y)
    if path is None:
        c.log(STEP, f"AVISO sin archivo GRD {y}")
        return
    hdr = pd.read_csv(path, sep="|", nrows=0).columns
    idc = "ID_BENEFICIARIO" if "ID_BENEFICIARIO" in hdr else "CIP_ENCRIPTADO"
    dx = sorted((h for h in hdr if h.startswith("DIAGNOSTICO") and h[11:].isdigit()), key=lambda h: int(h[11:]))
    base = [idc, "SEXO", "FECHA_NACIMIENTO", "FECHA_INGRESO", "FECHAALTA", "TIPOALTA", "TIPO_ACTIVIDAD",
            "TIPO_INGRESO", "COD_HOSPITAL", "IR_29301_SEVERIDAD"]
    base = [b for b in base if b in hdr]
    out, n_all = [], 0
    for ch in pd.read_csv(path, sep="|", usecols=base + dx, dtype=str, chunksize=300_000):
        n_all += len(ch)
        birth, din, dout = parse_dates(ch["FECHA_NACIMIENTO"]), parse_dates(ch["FECHA_INGRESO"]), parse_dates(ch["FECHAALTA"])
        age = (din - birth).dt.days / 365.25
        keep = age >= MIN_AGE
        ch, age, din, dout = ch[keep], age[keep], din[keep], dout[keep]
        codes = ch[dx].fillna("").apply(lambda s: s.str.upper().str.replace(".", "", regex=False).str.strip())
        joined = pd.Series("|", index=ch.index)
        for col in dx:
            joined = joined + codes[col] + "|"
        joined = joined.str.replace(r"\|{2,}", "|", regex=True)
        r = pd.DataFrame({
            "id": ch[idc].fillna("").str.strip(),
            "year": y,
            "sex": c.sex_std(ch["SEXO"]),
            "age": age.round(2),
            "date_in": din.dt.date.astype(str),
            "los": (dout - din).dt.days,
            "activity": np.where(ch["TIPO_ACTIVIDAD"].fillna("").str.upper().str.startswith("HOSP"), "hosp", "cma"),
            "admission": ch["TIPO_INGRESO"].fillna("").str.upper().str.strip(),
            "died": ch["TIPOALTA"].fillna("").str.upper().str.startswith("FALLEC").astype(int),
            "hospital": ch["COD_HOSPITAL"].fillna("").str.strip(),
            "severity": pd.to_numeric(ch.get("IR_29301_SEVERIDAD"), errors="coerce"),
            "dx1": codes[dx[0]],
            "dx": joined,
            "n_dx": (codes != "").sum(axis=1),
        })
        r.loc[r["id"].str.upper().isin(INVALID_ID), "id"] = ""
        out.append(r)
    d = pd.concat(out, ignore_index=True)
    d.to_parquet(c.derived("grd_dx") / f"grd_dx_{y}.parquet", index=False)
    c.log(STEP, f"{y}: {n_all:,} episodios; {len(d):,} de 45 años o más; id vacío {d['id'].eq('').mean():.2%}; "
                f"diagnósticos por episodio {d.n_dx.mean():.1f}")


def main() -> None:
    c.ensure_dirs()
    lo, hi = c.YEARS["grd"]
    for y in c.years_arg(list(range(lo, hi + 1))):
        if c.flag("--skip-existing") and (c.derived("grd_dx") / f"grd_dx_{y}.parquet").exists():
            continue
        one_year(y)


if __name__ == "__main__":
    main()
