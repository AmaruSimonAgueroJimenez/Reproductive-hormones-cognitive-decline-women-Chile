"""Rebuild the executed access and diagnostic-recording report.

Default: saved public aggregates. --refresh-raw explicitly reads external sources.
Scientific and document runtimes are separate; see BUILD_INSTRUCTIONS_EN.md.
"""
from pathlib import Path
import argparse, base64, hashlib, json, os, shutil, subprocess, sys, zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts/access_extension'))
import access_report as report

def run(file,*args):
 subprocess.run([sys.executable,str(ROOT/'scripts/access_extension'/file),*args],cwd=ROOT,check=True)

def word():
 bundled=Path.home()/'.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3'
 interpreter=os.environ.get('DOCX_PYTHON',str(bundled))
 subprocess.run([interpreter,str(ROOT/'scripts/access_extension/build_access_docx.py')],cwd=ROOT,check=True)

def validate_html(data):
 from bs4 import BeautifulSoup
 soup=BeautifulSoup((ROOT/'docs/access_diagnostic_recording_extension.html').read_text(),'html.parser')
 assert soup.html.get('lang')=='en'
 from collections import Counter
 ids=Counter(element['id'] for element in soup.find_all(id=True))
 assert not [name for name,count in ids.items() if count>1], 'Duplicate HTML IDs'
 main=soup.find('main');text=main.get_text(' ',strip=True)
 def norm(t):return ' '.join(str(t).split())
 for kind in ['methods','results']:
  for s in data[kind]:
   for p in s['paragraphs']:assert norm(p) in norm(text),(kind,s['title'])
 figures=main.select('img.paper-figure');assert len(figures)==len(data['figures'])
 for actual,expected in zip(figures,data['figures']):
  assert actual['src'].startswith('data:image/png;base64,')
  assert hashlib.sha256(base64.b64decode(actual['src'].split(',',1)[1])).hexdigest()==expected['sha256']
  assert norm('Figure '+str(expected['number'])+'. '+expected['caption']) in norm(text)
 tables=main.find_all('table');assert len(tables)==len(data['tables'])
 cells=0
 for actual,expected in zip(tables,data['tables']):
  assert not Path(expected['csv_path']).is_absolute()
  rows=[[norm(c.get_text(' ',strip=True)) for c in tr.find_all(['th','td'])] for tr in actual.find_all('tr')]
  assert rows==[[norm(x) for x in expected['columns']],*[[norm(x) for x in row] for row in expected['rows']]],expected['id']
  cells+=sum(map(len,rows))
 download_links=[link.get('href','') for link in main.find_all('a') if link.get_text()=='Download source table']
 assert len(download_links)==len(data['tables'])
 assert all('/Users/' not in link and not link.startswith('file:') for link in download_links)
 assert len(soup.select('details.code-fold'))>10
 checks={'language':'en','content_sha256':data['content_sha256'],'all_substantive_paragraphs_match':True,'tables':len(tables),'verified_table_cells':cells,'exact_source_pngs':len(figures),'folded_code_cells':len(soup.select('details.code-fold'))}
 (report.OUT/'html_validation.json').write_text(json.dumps(checks,indent=2));return checks

def validate_word(data):
 from lxml import etree
 with zipfile.ZipFile(report.MAN/'Methods_Results_EN.docx') as z:
  ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
  doc=etree.fromstring(z.read('word/document.xml'))
  paras=[''.join(p.xpath('.//w:t/text()',namespaces=ns)) for p in doc.xpath('//w:body/w:p',namespaces=ns)]
  for kind in ['methods','results']:
   for s in data[kind]:
    for p in s['paragraphs']:assert p.replace('**','') in paras,s['title']
  tables=doc.xpath('//w:tbl',namespaces=ns);assert len(tables)==len(data['tables'])
  cells=0
  for t,expected in zip(tables,data['tables']):
   rows=[]
   for row in t.xpath('./w:tr',namespaces=ns):rows.append([''.join(cell.xpath('.//w:t/text()',namespaces=ns)) for cell in row.xpath('./w:tc',namespaces=ns)])
   assert rows==[expected['columns'],*expected['rows']],expected['id'];cells+=sum(map(len,rows))
  png_hashes=[hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if n.startswith('word/media/') and n.endswith('.png')]
  assert sorted(png_hashes)==sorted(f['sha256'] for f in data['figures'])
  sections=doc.xpath('//w:sectPr',namespaces=ns)
  assert all(s.xpath('./w:lnNumType/@w:restart',namespaces=ns)==['continuous'] for s in sections)
  checks={'content_sha256':data['content_sha256'],'all_substantive_paragraphs_match':True,'tables':len(tables),'verified_table_cells':cells,'exact_source_pngs':len(png_hashes),'continuous_line_numbering':True}
  (report.OUT/'word_content_validation.json').write_text(json.dumps(checks,indent=2));return checks

def manifest():
 paths=[]
 for base in [report.OUT,report.MAN,ROOT/'scripts/access_extension']:
  paths += [p for p in base.rglob('*') if p.is_file() and p.suffix not in ['.log','.pyc'] and '__pycache__' not in p.parts and not any(x.startswith('qa_') for x in p.parts) and p.name not in ['reproducibility_manifest.json','Access_Diagnostic_Recording_Assets_EN.zip']]
 paths += [ROOT/'scripts/run_access_diagnostic_extension.py',ROOT/'scripts/build_descriptive_docx.py',ROOT/'config/access_recording_extension_2026_10_29.yaml',ROOT/'docs/access_diagnostic_recording_extension.qmd',ROOT/'docs/access_diagnostic_recording_extension.html',ROOT/'docs/access_diagnostic_recording_extension_source.txt',ROOT/'docs/reproductive_life_course.css',ROOT/'_quarto.yml']
 paths += [ROOT/'scripts'/name for name in ['mf_common.py','mf00_denominators.py','mf04_rem.py','mf06_establishments.py','mf19_grd_comorbidity.py','paper/p18_descriptive_review_figures.py']]
 paths += list((ROOT/'outputs/paper/revision_descriptiva_2026-10-28/source_data/geo').glob('*.geojson'))
 paths += [ROOT/'outputs/multifuente/tables'/name for name in ['centers_context.csv','mht_national.csv','comuna_context.csv']]
 entries=[{'path':str(p.relative_to(ROOT)),'sha256':report.sha(p),'bytes':p.stat().st_size} for p in sorted(set(paths)) if p.exists()]
 (report.OUT/'reproducibility_manifest.json').write_text(json.dumps({'scope':'Public aggregates, source provenance, scripts and executed deliverables; individual records remain external','files':entries},indent=2))
 # Deliverable source package intentionally excludes original source PDFs/XLSX,
 # manuscript QA images and encrypted individual data.
 package_config='''project:
  type: website
  output-dir: _site
  render:
    - docs/access_diagnostic_recording_extension.qmd
  resources:
    - docs/access_diagnostic_recording_extension_source.txt
    - manuscript/access_diagnostic_extension_2026-10-29/*.docx
    - outputs/access_diagnostic_extension_2026-10-29/**/*.csv
    - outputs/access_diagnostic_extension_2026-10-29/**/*.svg
    - outputs/access_diagnostic_extension_2026-10-29/**/*.pdf
website:
  title: Hormonal care and neurodegenerative diagnostic recording in Chile
format:
  html:
    theme: cosmo
    lang: en
'''
 package_files=[]
 with zipfile.ZipFile(report.OUT/'Access_Diagnostic_Recording_Assets_EN.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for entry in entries:
   p=ROOT/entry['path']
   if entry['path']=='_quarto.yml':continue
   if p.name.startswith(('word_visual_qa','v3_v4_visual_body')):continue
   if p.suffix in ['.csv','.gz','.py','.json','.geojson','.yaml','.qmd','.md','.svg','.pdf','.png','.txt','.css'] and ('code_audit' not in p.parts or p.suffix in ['.json','.csv']) and p.name!='access_diagnostic_recording_extension.html':
    z.write(p,entry['path']);package_files.append(entry)
  for name,content in [('_quarto.yml',package_config),('project_site_configuration_original.yaml',(ROOT/'_quarto.yml').read_text()),('SOURCE_PACKAGE_README_EN.md','This public source package has a minimal Quarto configuration for the executed extension only. The original whole-project site configuration is preserved separately. From this folder run python3 scripts/run_access_diagnostic_extension.py --html, or add --word with the documented document runtime. Links to Part I and the earlier Part II require the complete parent project. Individual hospital data are excluded. Raw-source refresh requires the original releases and upstream caches described in outputs/access_diagnostic_extension_2026-10-29/BUILD_INSTRUCTIONS_EN.md.\n')]:
   z.writestr(name,content);package_files.append({'path':name,'sha256':hashlib.sha256(content.encode()).hexdigest(),'bytes':len(content.encode())})
  z.writestr('source_package_manifest.json',json.dumps({'scope':'Actual files in the standalone public reproduction package; original institutional data remain separately required for raw refresh','files':package_files},indent=2))
 return len(entries)

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--refresh-raw',action='store_true');p.add_argument('--word',action='store_true');p.add_argument('--html',action='store_true');p.add_argument('--verify-only',action='store_true');p.add_argument('--bind-only',action='store_true');a=p.parse_args()
 if a.verify_only:
  d=json.loads((report.OUT/'access_evidence.json').read_text())
  print(json.dumps({'html':validate_html(d),'word':validate_word(d)},indent=2));return
 if a.refresh_raw:
  if not Path('/Volumes/Datos/Asesorias_Data').is_dir():raise FileNotFoundError('External source data volume is not mounted')
  run('rem_dictionary_audit.py');run('rem_extract.py','--force');run('rem_analyze.py');run('neuro_dictionary_audit.py');run('neuro_prepare.py');run('hospital_source_scan.py','--refresh-source');run('hospital_analysis.py','--refresh-private')
 d=report.build() if a.bind_only else report.rebuild_public()
 report.write_qmd(d)
 if a.word:word();validate_word(d)
 if a.html:
  env=os.environ.copy();env['QUARTO_PYTHON']=str(report.SCIENTIFIC)
  subprocess.run(['quarto','render','docs/access_diagnostic_recording_extension.qmd'],cwd=ROOT,env=env,check=True)
  source=ROOT/'_site/docs/access_diagnostic_recording_extension.html'
  if source.exists():shutil.copy2(source,ROOT/'docs/access_diagnostic_recording_extension.html')
  d=json.loads((report.OUT/'access_evidence.json').read_text());validate_html(d)
 print(json.dumps({'content_sha256':d['content_sha256'],'methods':len(d['methods']),'results':len(d['results']),'tables':len(d['tables']),'figures':len(d['figures']),'manifest_files':manifest()},indent=2))
if __name__=='__main__':main()
